// server.ts
import "dotenv/config";
import express from "express";
import fs2 from "node:fs";
import path2 from "node:path";
import { fileURLToPath } from "node:url";

// server/cache.ts
var MemoryCache = class {
  constructor() {
    this.store = /* @__PURE__ */ new Map();
  }
  get(key) {
    const entry = this.store.get(key);
    if (!entry) return null;
    const isExpired = Date.now() > entry.expiresAt;
    return {
      value: entry.value,
      cachedAt: entry.cachedAt,
      stale: isExpired
    };
  }
  set(key, value, ttlMs) {
    this.store.set(key, {
      value,
      expiresAt: Date.now() + ttlMs,
      cachedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  clearAll() {
    this.store.clear();
  }
};
var appCache = new MemoryCache();

// server/config.ts
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
var DATA_DIR = path.resolve(process.cwd(), ".data");
var CONFIG_FILE = path.join(DATA_DIR, "admin-config.json");
var todayKey = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
var defaultConfig = {
  skillsEnabled: {
    skill01_fx: true,
    skill02_economics: true,
    skill03_radar: true,
    skill04_wise: true,
    skill05_strategy: true,
    skill06_alerts: true,
    skill07_reports: true,
    skill08_flights: true
  },
  sourcesEnabled: {
    frankfurter: true,
    bcbPtax: true,
    bcbIndicators: true,
    amadeus: true
  },
  limits: {
    aiRequestsPerHourPerVisitor: 18,
    aiRequestsPerDayGlobal: 250,
    maxConversationMessages: 16,
    maxMessageChars: 800,
    fxRequestsPerHourPerVisitor: 120,
    flightRequestsPerDayGlobal: 40,
    fxCacheTtlMinutes: 15,
    flightCacheTtlMinutes: 30
  },
  agentInstructions: "Priorize transpar\xEAncia, clareza e rigor num\xE9rico em portugu\xEAs do Brasil. Sempre informe a fonte e a data de atualiza\xE7\xE3o dos dados. Nunca invente cota\xE7\xF5es ou pre\xE7os de passagens.",
  amadeus: {
    clientId: process.env.AMADEUS_CLIENT_ID || "",
    clientSecret: process.env.AMADEUS_CLIENT_SECRET || "",
    environment: "test"
  }
};
var currentConfig = loadConfigFromDisk();
function loadConfigFromDisk() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const raw = fs.readFileSync(CONFIG_FILE, "utf-8");
      const parsed = JSON.parse(raw);
      return {
        skillsEnabled: { ...defaultConfig.skillsEnabled, ...parsed.skillsEnabled || {} },
        sourcesEnabled: { ...defaultConfig.sourcesEnabled, ...parsed.sourcesEnabled || {} },
        limits: { ...defaultConfig.limits, ...parsed.limits || {} },
        agentInstructions: parsed.agentInstructions || defaultConfig.agentInstructions,
        amadeus: {
          clientId: parsed.amadeus?.clientId || process.env.AMADEUS_CLIENT_ID || "",
          clientSecret: parsed.amadeus?.clientSecret || process.env.AMADEUS_CLIENT_SECRET || "",
          environment: parsed.amadeus?.environment === "production" ? "production" : "test"
        }
      };
    }
  } catch {
  }
  return structuredClone(defaultConfig);
}
function saveConfigToDisk(cfg) {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), "utf-8");
  } catch {
  }
}
function getAdminConfig() {
  return currentConfig;
}
function updateAdminConfig(patch) {
  currentConfig = {
    ...currentConfig,
    skillsEnabled: {
      ...currentConfig.skillsEnabled,
      ...patch.skillsEnabled || {}
    },
    sourcesEnabled: {
      ...currentConfig.sourcesEnabled,
      ...patch.sourcesEnabled || {}
    },
    limits: {
      ...currentConfig.limits,
      ...patch.limits || {}
    },
    agentInstructions: typeof patch.agentInstructions === "string" ? patch.agentInstructions.slice(0, 2e3) : currentConfig.agentInstructions,
    amadeus: {
      clientId: typeof patch.amadeus?.clientId === "string" && !patch.amadeus.clientId.includes("\u2022\u2022\u2022\u2022") ? patch.amadeus.clientId.trim() : currentConfig.amadeus.clientId,
      clientSecret: typeof patch.amadeus?.clientSecret === "string" && !patch.amadeus.clientSecret.includes("\u2022\u2022\u2022\u2022") ? patch.amadeus.clientSecret.trim() : currentConfig.amadeus.clientSecret,
      environment: patch.amadeus?.environment === "production" || patch.amadeus?.environment === "test" ? patch.amadeus.environment : currentConfig.amadeus.environment
    }
  };
  saveConfigToDisk(currentConfig);
  return currentConfig;
}
function getPublicConfigSummary() {
  return {
    skillsEnabled: currentConfig.skillsEnabled,
    limits: {
      aiRequestsPerHourPerVisitor: currentConfig.limits.aiRequestsPerHourPerVisitor,
      maxConversationMessages: currentConfig.limits.maxConversationMessages,
      maxMessageChars: currentConfig.limits.maxMessageChars
    },
    amadeusConfigured: Boolean(
      currentConfig.sourcesEnabled.amadeus && currentConfig.amadeus.clientId && currentConfig.amadeus.clientSecret
    )
  };
}
function maskSecret(value) {
  if (!value) return "";
  if (value.length <= 6) return "\u2022\u2022\u2022\u2022\u2022\u2022";
  return `${value.slice(0, 3)}\u2022\u2022\u2022\u2022${value.slice(-3)}`;
}
var usage = {
  aiCallsTotal: 0,
  aiCallsToday: 0,
  aiQuotaDate: todayKey(),
  fxCallsTotal: 0,
  fxCacheHits: 0,
  flightCallsTotal: 0,
  flightCallsToday: 0,
  flightQuotaDate: todayKey(),
  rateLimitRejections: 0
};
var errorLog = [];
function syncDateCounters() {
  const today = todayKey();
  if (usage.aiQuotaDate !== today) {
    usage.aiQuotaDate = today;
    usage.aiCallsToday = 0;
  }
  if (usage.flightQuotaDate !== today) {
    usage.flightQuotaDate = today;
    usage.flightCallsToday = 0;
  }
}
function recordAiCall() {
  syncDateCounters();
  if (usage.aiCallsToday >= currentConfig.limits.aiRequestsPerDayGlobal) {
    return { allowed: false, remainingToday: 0 };
  }
  usage.aiCallsTotal += 1;
  usage.aiCallsToday += 1;
  return {
    allowed: true,
    remainingToday: Math.max(0, currentConfig.limits.aiRequestsPerDayGlobal - usage.aiCallsToday)
  };
}
function recordFxCall(cacheHit) {
  usage.fxCallsTotal += 1;
  if (cacheHit) usage.fxCacheHits += 1;
}
function recordFlightCall() {
  syncDateCounters();
  if (usage.flightCallsToday >= currentConfig.limits.flightRequestsPerDayGlobal) {
    return { allowed: false, remainingToday: 0 };
  }
  usage.flightCallsTotal += 1;
  usage.flightCallsToday += 1;
  return {
    allowed: true,
    remainingToday: Math.max(0, currentConfig.limits.flightRequestsPerDayGlobal - usage.flightCallsToday)
  };
}
function recordRateLimitRejection() {
  usage.rateLimitRejections += 1;
}
function logTechnicalError(scope, message) {
  errorLog.unshift({
    id: crypto.randomUUID(),
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    scope,
    message: message.slice(0, 300)
  });
  if (errorLog.length > 50) {
    errorLog.length = 50;
  }
}
function getAdminMetricsAndLogs() {
  syncDateCounters();
  return {
    usage: { ...usage },
    errors: [...errorLog]
  };
}
var adminSessions = /* @__PURE__ */ new Map();
var ADMIN_SESSION_TTL_MS = 4 * 60 * 60 * 1e3;
function getExpectedAdminPasscode() {
  return process.env.ADMIN_PASSCODE?.trim() || "madrid-admin-2026";
}
function createAdminSession(passcode) {
  const expected = getExpectedAdminPasscode();
  const a = Buffer.from(passcode.trim());
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }
  const token = crypto.randomBytes(32).toString("hex");
  adminSessions.set(token, Date.now() + ADMIN_SESSION_TTL_MS);
  return token;
}
function verifyAdminToken(authHeader) {
  if (!authHeader || !authHeader.startsWith("Bearer ")) return false;
  const token = authHeader.slice(7).trim();
  const expiresAt = adminSessions.get(token);
  if (!expiresAt) return false;
  if (Date.now() > expiresAt) {
    adminSessions.delete(token);
    return false;
  }
  return true;
}

// server/geminiAssistant.ts
import { GoogleGenAI, Type } from "@google/genai";

// server/skills/economicsService.ts
async function fetchBcbSgsSeries(seriesId) {
  try {
    const res = await fetch(
      `https://api.bcb.gov.br/dados/serie/bcdata.sgs.${seriesId}/dados/ultimos/1?formato=json`,
      { signal: AbortSignal.timeout(5500) }
    );
    if (!res.ok) return null;
    const json = await res.json();
    return json?.[0] ?? null;
  } catch (err) {
    logTechnicalError(
      `skill02_bcb_sgs_${seriesId}`,
      err instanceof Error ? err.message : "Erro BCB SGS"
    );
    return null;
  }
}
async function getEconomicIntelligence() {
  const cacheKey = "economics:overview";
  const cached = appCache.get(cacheKey);
  if (cached && !cached.stale) {
    return cached.value;
  }
  const cfg = getAdminConfig();
  const indicators = [];
  if (cfg.sourcesEnabled.bcbIndicators) {
    const [selicMeta, ipcaMensal] = await Promise.all([
      fetchBcbSgsSeries(432),
      // Meta Selic definida pelo Copom (% a.a.)
      fetchBcbSgsSeries(433)
      // IPCA variação mensal (%)
    ]);
    if (selicMeta) {
      indicators.push({
        id: "bcb_selic",
        label: "Taxa Selic Meta (BCB / Copom)",
        value: `${Number(selicMeta.valor).toFixed(2)}% a.a.`,
        referenceDate: selicMeta.data,
        source: "Banco Central do Brasil (SGS s\xE9rie 432)",
        verified: true
      });
    }
    if (ipcaMensal) {
      indicators.push({
        id: "ibge_ipca",
        label: "IPCA Mensal (IBGE)",
        value: `${Number(ipcaMensal.valor).toFixed(2)}% no m\xEAs`,
        referenceDate: ipcaMensal.data,
        source: "IBGE via Banco Central do Brasil (SGS s\xE9rie 433)",
        verified: true
      });
    }
  }
  const response = {
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    indicators,
    facts: [
      "Diferencial de juros: A rela\xE7\xE3o entre a taxa Selic (Banco Central do Brasil), a taxa b\xE1sica do Banco Central Europeu (BCE) e a taxa do Federal Reserve (EUA) influencia diretamente o fluxo de capitais entre Brasil e Zona do Euro.",
      "Infla\xE7\xE3o relativa: Leituras de IPCA (IBGE) e HICP (Eurostat) alteram as expectativas para as pr\xF3ximas decis\xF5es de pol\xEDtica monet\xE1ria e o poder de compra real das moedas.",
      "Din\xE2mica externa e risco global: Indicadores dos EUA (Fed, payroll, infla\xE7\xE3o) e tens\xF5es geopol\xEDticas tendem a fortalecer moedas consideradas reserva de valor, pressionando moedas emergentes como o real."
    ],
    expectations: [
      "Expectativa de mercado: Comunicados recentes do Copom, do BCE e do Fed costumam ser precificados antecipadamente na taxa de c\xE2mbio antes mesmo das reuni\xF5es oficiais.",
      "Proje\xE7\xF5es fiscais e de atividade no Brasil e na Zona do Euro podem gerar volatilidade de curto prazo no par EUR/BRL."
    ],
    hypotheses: [
      "Cen\xE1rio de queda do EUR/BRL (hip\xF3tese): Manuten\xE7\xE3o de diferencial de juros favor\xE1vel ao Brasil combinada com desacelera\xE7\xE3o inflacion\xE1ria local e ambiente externo calmo.",
      "Cen\xE1rio de alta do EUR/BRL (hip\xF3tese): Avers\xE3o global ao risco (geopol\xEDtica ou surpresa inflacion\xE1ria nos EUA/Europa) ou redu\xE7\xE3o acelerada do diferencial de juros brasileiro."
    ],
    methodologyNote: "An\xE1lise estritamente informativa. Fatos verificados baseiam-se em dados p\xFAblicos do BCB/IBGE; expectativas e hip\xF3teses n\xE3o constituem previs\xF5es garantidas nem recomenda\xE7\xE3o de investimento."
  };
  appCache.set(cacheKey, response, 60 * 60 * 1e3);
  return response;
}

// server/skills/flightsService.ts
function sanitizeIata(code, fallback) {
  const cleaned = code.trim().toUpperCase().replace(/[^A-Z]/g, "");
  return cleaned.length === 3 ? cleaned : fallback;
}
function buildExternalSearchLinks(q) {
  const origin = sanitizeIata(q.origin, "GRU");
  const dest = sanitizeIata(q.destination, "MAD");
  const dep = q.departureDate || new Date(Date.now() + 60 * 864e5).toISOString().slice(0, 10);
  const ret = q.roundTrip && q.returnDate ? q.returnDate : "";
  const pax = Math.max(1, Math.min(9, q.passengers || 1));
  const googleQuery = q.roundTrip && ret ? `Flights from ${origin} to ${dest} on ${dep} through ${ret}` : `One-way flights from ${origin} to ${dest} on ${dep}`;
  const skyDep = dep.replace(/-/g, "").slice(2);
  const skyRet = ret ? `/${ret.replace(/-/g, "").slice(2)}` : "";
  return [
    {
      provider: "Google Flights",
      description: `Pesquisa direta ${origin} \u2192 ${dest} (${pax} passageiro${pax > 1 ? "s" : ""})`,
      url: `https://www.google.com/travel/flights?q=${encodeURIComponent(googleQuery)}`
    },
    {
      provider: "Skyscanner",
      description: q.flexibleDates ? "Comparativo com datas flex\xEDveis e filtros de bagagem" : "Comparativo multi-companhias com alertas externos",
      url: `https://www.skyscanner.com.br/transporte/passagens-aereas/${origin.toLowerCase()}/${dest.toLowerCase()}/${skyDep}${skyRet}/?adults=${pax}`
    },
    {
      provider: "Kayak",
      description: "Comparador de tarifas com hist\xF3rico e filtro de escalas",
      url: `https://www.kayak.com.br/flights/${origin}-${dest}/${dep}${ret ? `/${ret}` : ""}/${pax}adults?sort=bestflight_a`
    },
    {
      provider: "Iberia (Companhia Oficial)",
      description: "Portal oficial da Iberia para rotas Brasil \u2013 Madrid",
      url: "https://www.iberia.com/br/"
    },
    {
      provider: "LATAM Airlines",
      description: "Portal oficial LATAM para voos diretos e conex\xF5es para Madrid",
      url: "https://www.latamairlines.com/br/pt"
    },
    {
      provider: "Air Europa",
      description: "Portal oficial Air Europa com rota direta para Madrid (MAD)",
      url: "https://www.aireuropa.com/br/pt/home"
    }
  ];
}
async function getAmadeusAccessToken(clientId, clientSecret, environment) {
  const tokenCacheKey = `amadeus:token:${environment}:${clientId.slice(0, 6)}`;
  const cached = appCache.get(tokenCacheKey);
  if (cached && !cached.stale) {
    return cached.value;
  }
  const host = environment === "production" ? "https://api.amadeus.com" : "https://test.api.amadeus.com";
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret
  });
  const res = await fetch(`${host}/v1/security/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
    signal: AbortSignal.timeout(7e3)
  });
  if (!res.ok) {
    throw new Error(`Amadeus auth HTTP ${res.status}`);
  }
  const json = await res.json();
  const ttl = Math.max(60, (json.expires_in || 1500) - 60) * 1e3;
  appCache.set(tokenCacheKey, json.access_token, ttl);
  return json.access_token;
}
async function searchFlights(query) {
  const cfg = getAdminConfig();
  const origin = sanitizeIata(query.origin, "GRU");
  const destination = sanitizeIata(query.destination, "MAD");
  const externalLinks = buildExternalSearchLinks({ ...query, origin, destination });
  const hasAmadeus = Boolean(
    cfg.sourcesEnabled.amadeus && cfg.amadeus.clientId && cfg.amadeus.clientSecret
  );
  if (!hasAmadeus) {
    return {
      mode: "external_links_only",
      amadeusConfigured: false,
      offers: [],
      externalLinks,
      searchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sourceLabel: "Links diretos para portais autorizados (sem API Amadeus ativa)",
      quotaRemainingToday: Math.max(0, cfg.limits.flightRequestsPerDayGlobal),
      notice: "Nenhuma credencial Amadeus est\xE1 configurada pela administra\xE7\xE3o no momento. Para evitar pre\xE7os inventados ou desatualizados, utilize os links oficiais abaixo para consultar tarifas reais e registr\xE1-las no seu monitoramento."
    };
  }
  const cacheKey = `flights:${origin}:${destination}:${query.departureDate}:${query.returnDate || ""}:${query.passengers}:${query.directOnly ? 1 : 0}`;
  const cached = appCache.get(cacheKey);
  if (cached && !cached.stale) {
    return cached.value;
  }
  const quota = recordFlightCall();
  if (!quota.allowed) {
    return {
      mode: "external_links_only",
      amadeusConfigured: true,
      offers: [],
      externalLinks,
      searchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sourceLabel: "Quota di\xE1ria de API de voos atingida",
      quotaRemainingToday: 0,
      notice: "A quota gratuita di\xE1ria de consultas na API de voos foi atingida. Utilize os links oficiais abaixo para consultar pre\xE7os sem custos."
    };
  }
  try {
    const token = await getAmadeusAccessToken(
      cfg.amadeus.clientId,
      cfg.amadeus.clientSecret,
      cfg.amadeus.environment
    );
    const host = cfg.amadeus.environment === "production" ? "https://api.amadeus.com" : "https://test.api.amadeus.com";
    const params = new URLSearchParams({
      originLocationCode: origin,
      destinationLocationCode: destination,
      departureDate: query.departureDate,
      adults: String(Math.max(1, Math.min(9, query.passengers || 1))),
      currencyCode: "BRL",
      max: "8"
    });
    if (query.roundTrip && query.returnDate) {
      params.set("returnDate", query.returnDate);
    }
    if (query.directOnly) {
      params.set("nonStop", "true");
    }
    if (query.maxBudgetBrl && query.maxBudgetBrl > 0) {
      params.set("maxPrice", String(Math.round(query.maxBudgetBrl)));
    }
    const res = await fetch(`${host}/v2/shopping/flight-offers?${params.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(9e3)
    });
    if (!res.ok) {
      throw new Error(`Amadeus search HTTP ${res.status}`);
    }
    const data = await res.json();
    const offers = (data.data || []).map((offer) => {
      const outSegs = offer.itineraries?.[0]?.segments || [];
      const inSegs = offer.itineraries?.[1]?.segments || [];
      const total = Number(offer.price?.total || 0);
      const base = Number(offer.price?.base || 0);
      const taxes = total > 0 && base > 0 ? Number((total - base).toFixed(2)) : null;
      const airline = offer.validatingAirlineCodes?.[0] || outSegs[0]?.carrierCode || "Cia A\xE9rea";
      const bagsQty = offer.travelerPricings?.[0]?.fareDetailsBySegment?.[0]?.includedCheckedBags?.quantity ?? 0;
      const cabin = offer.travelerPricings?.[0]?.fareDetailsBySegment?.[0]?.cabin || "ECONOMY";
      return {
        id: offer.id,
        airline,
        priceTotalBrl: total,
        taxesEstimatedBrl: taxes,
        currency: offer.price?.currency || "BRL",
        stops: Math.max(0, outSegs.length - 1),
        outboundDeparture: outSegs[0]?.departure?.at || query.departureDate,
        outboundArrival: outSegs[outSegs.length - 1]?.arrival?.at || "",
        inboundDeparture: inSegs[0]?.departure?.at,
        inboundArrival: inSegs[inSegs.length - 1]?.arrival?.at,
        baggageInfo: bagsQty > 0 ? `${bagsQty} bagagem(ns) despachada(s)` : "Consulte bagagem na tarifa",
        fareConditions: `Cabine ${cabin}. Confirme regras de remarca\xE7\xE3o e reembolso na emiss\xE3o.`,
        source: `Amadeus API (${cfg.amadeus.environment})`
      };
    });
    const result = {
      mode: "amadeus_live",
      amadeusConfigured: true,
      offers,
      externalLinks,
      searchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sourceLabel: `Amadeus Flight Offers API (${cfg.amadeus.environment})`,
      quotaRemainingToday: quota.remainingToday,
      notice: offers.length > 0 ? "Tarifas consultadas via Amadeus API. Confirme disponibilidade final e regras de bagagem no site da companhia antes da compra." : "Nenhuma oferta retornada para os filtros informados na API Amadeus. Utilize os links oficiais abaixo para ampliar a busca."
    };
    appCache.set(cacheKey, result, Math.max(5, cfg.limits.flightCacheTtlMinutes) * 60 * 1e3);
    return result;
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro Amadeus";
    logTechnicalError("skill08_amadeus", msg);
    return {
      mode: "external_links_only",
      amadeusConfigured: true,
      offers: [],
      externalLinks,
      searchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      sourceLabel: "Fallback seguro para links oficiais",
      quotaRemainingToday: quota.remainingToday,
      notice: "A consulta em tempo real \xE0 API Amadeus falhou ou expirou no momento. Para garantir dados confi\xE1veis sem inventar tarifas, utilize os links diretos abaixo."
    };
  }
}

// server/skills/fxService.ts
var SUPPORTED_CURRENCIES = /* @__PURE__ */ new Set(["EUR", "BRL", "USD", "GBP", "CHF", "CAD"]);
function formatDateYMD(d) {
  return d.toISOString().slice(0, 10);
}
function formatDateMDY(d) {
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  const yyyy = d.getUTCFullYear();
  return `${mm}-${dd}-${yyyy}`;
}
function mean(values) {
  if (!values.length) return null;
  return values.reduce((acc, v) => acc + v, 0) / values.length;
}
async function fetchBcbPtax(currency) {
  const cfg = getAdminConfig();
  if (!cfg.sourcesEnabled.bcbPtax || !["EUR", "USD", "GBP", "CHF", "CAD"].includes(currency)) {
    return {
      available: false,
      buyRate: null,
      sellRate: null,
      timestamp: null,
      source: "Banco Central do Brasil (PTAX)"
    };
  }
  try {
    const end = /* @__PURE__ */ new Date();
    const start = new Date(end.getTime() - 10 * 864e5);
    const url = `https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoMoedaPeriodo(moeda=@moeda,dataInicial=@dataInicial,dataFinalCotacao=@dataFinalCotacao)?@moeda='${currency}'&@dataInicial='${formatDateMDY(start)}'&@dataFinalCotacao='${formatDateMDY(end)}'&$top=5&$orderby=dataHoraCotacao%20desc&$format=json`;
    const res = await fetch(url, { signal: AbortSignal.timeout(6500) });
    if (!res.ok) throw new Error(`BCB PTAX HTTP ${res.status}`);
    const data = await res.json();
    const latest = data.value?.[0];
    if (!latest) {
      return {
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)"
      };
    }
    return {
      available: true,
      buyRate: latest.cotacaoCompra,
      sellRate: latest.cotacaoVenda,
      timestamp: latest.dataHoraCotacao,
      source: "Banco Central do Brasil (PTAX Oficial)"
    };
  } catch (err) {
    logTechnicalError("skill01_bcb_ptax", err instanceof Error ? err.message : "Erro BCB PTAX");
    return {
      available: false,
      buyRate: null,
      sellRate: null,
      timestamp: null,
      source: "Banco Central do Brasil (PTAX)"
    };
  }
}
async function getFxOverview(rawBase = "EUR", rawTarget = "BRL") {
  const base = SUPPORTED_CURRENCIES.has(rawBase.toUpperCase()) ? rawBase.toUpperCase() : "EUR";
  const target = SUPPORTED_CURRENCIES.has(rawTarget.toUpperCase()) ? rawTarget.toUpperCase() : "BRL";
  const cfg = getAdminConfig();
  const cacheKey = `fx:${base}:${target}`;
  const ttlMs = Math.max(1, cfg.limits.fxCacheTtlMinutes) * 60 * 1e3;
  const cached = appCache.get(cacheKey);
  if (cached && !cached.stale) {
    recordFxCall(true);
    return cached.value;
  }
  recordFxCall(false);
  if (!cfg.sourcesEnabled.frankfurter) {
    return {
      available: false,
      base,
      target,
      latestRate: null,
      previousRate: null,
      absoluteChange: null,
      percentChange: null,
      observationDate: null,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      stale: false,
      source: "Frankfurter / Banco Central Europeu",
      bcbPtax: {
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)"
      },
      stats: {
        avg7d: null,
        avg30d: null,
        avg90d: null,
        min7d: null,
        max7d: null,
        min30d: null,
        max30d: null,
        min90d: null,
        max90d: null,
        best30dDate: null,
        worst30dDate: null
      },
      history90d: [],
      disclaimer: "Cota\xE7\xE3o de refer\xEAncia interbanc\xE1ria (Frankfurter/BCE). N\xE3o representa o custo final de compra de moeda pela Wise.",
      errorMessage: "Fonte Frankfurter temporariamente desativada pela administra\xE7\xE3o."
    };
  }
  try {
    const end = /* @__PURE__ */ new Date();
    const start = new Date(end.getTime() - 95 * 864e5);
    const startStr = formatDateYMD(start);
    const endStr = formatDateYMD(end);
    const [latestRes, historyRes, bcbPtax] = await Promise.all([
      fetch(`https://api.frankfurter.dev/v1/latest?base=${base}&symbols=${target}`, {
        signal: AbortSignal.timeout(7e3)
      }),
      fetch(`https://api.frankfurter.dev/v1/${startStr}..${endStr}?base=${base}&symbols=${target}`, {
        signal: AbortSignal.timeout(8e3)
      }),
      target === "BRL" ? fetchBcbPtax(base) : Promise.resolve({
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)"
      })
    ]);
    if (!latestRes.ok || !historyRes.ok) {
      throw new Error(`Frankfurter HTTP ${latestRes.status}/${historyRes.status}`);
    }
    const latestJson = await latestRes.json();
    const historyJson = await historyRes.json();
    const pointsMap = /* @__PURE__ */ new Map();
    for (const [date, obj] of Object.entries(historyJson.rates || {})) {
      if (typeof obj?.[target] === "number") {
        pointsMap.set(date, obj[target]);
      }
    }
    if (typeof latestJson.rates?.[target] === "number") {
      pointsMap.set(latestJson.date, latestJson.rates[target]);
    }
    const history90d = Array.from(pointsMap.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([date, rate]) => ({ date, rate }));
    if (history90d.length === 0) {
      throw new Error("Nenhuma observa\xE7\xE3o cambial retornada pela API Frankfurter.");
    }
    const latestPoint = history90d[history90d.length - 1];
    const prevPoint = history90d.length > 1 ? history90d[history90d.length - 2] : null;
    const latestRate = latestPoint.rate;
    const previousRate = prevPoint ? prevPoint.rate : null;
    const absoluteChange = previousRate !== null ? latestRate - previousRate : null;
    const percentChange = previousRate !== null && previousRate !== 0 ? (latestRate - previousRate) / previousRate * 100 : null;
    const cutoff7 = formatDateYMD(new Date(end.getTime() - 7 * 864e5));
    const cutoff30 = formatDateYMD(new Date(end.getTime() - 30 * 864e5));
    const pts7 = history90d.filter((p) => p.date >= cutoff7);
    const pts30 = history90d.filter((p) => p.date >= cutoff30);
    const pts90 = history90d;
    const r7 = pts7.map((p) => p.rate);
    const r30 = pts30.map((p) => p.rate);
    const r90 = pts90.map((p) => p.rate);
    const best30 = pts30.reduce((best, p) => !best || p.rate < best.rate ? p : best, null);
    const worst30 = pts30.reduce((worst, p) => !worst || p.rate > worst.rate ? p : worst, null);
    const overview = {
      available: true,
      base,
      target,
      latestRate,
      previousRate,
      absoluteChange,
      percentChange,
      observationDate: latestPoint.date,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      stale: false,
      source: "Frankfurter API (refer\xEAncia oficial Banco Central Europeu)",
      bcbPtax,
      stats: {
        avg7d: mean(r7),
        avg30d: mean(r30),
        avg90d: mean(r90),
        min7d: r7.length ? Math.min(...r7) : null,
        max7d: r7.length ? Math.max(...r7) : null,
        min30d: r30.length ? Math.min(...r30) : null,
        max30d: r30.length ? Math.max(...r30) : null,
        min90d: r90.length ? Math.min(...r90) : null,
        max90d: r90.length ? Math.max(...r90) : null,
        best30dDate: best30?.date ?? null,
        worst30dDate: worst30?.date ?? null
      },
      history90d,
      disclaimer: "Cota\xE7\xE3o de refer\xEAncia interbanc\xE1ria (Frankfurter/BCE). N\xE3o representa o custo final de compra de moeda pela Wise, que inclui taxa de servi\xE7o e IOF."
    };
    appCache.set(cacheKey, overview, ttlMs);
    return overview;
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro ao consultar Frankfurter";
    logTechnicalError("skill01_fx", msg);
    if (cached) {
      return {
        ...cached.value,
        stale: true,
        errorMessage: `API cambial momentaneamente indispon\xEDvel (${msg}). Exibindo \xFAltimo registro em cache de ${cached.cachedAt}.`
      };
    }
    return {
      available: false,
      base,
      target,
      latestRate: null,
      previousRate: null,
      absoluteChange: null,
      percentChange: null,
      observationDate: null,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      stale: false,
      source: "Frankfurter / Banco Central Europeu",
      bcbPtax: {
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)"
      },
      stats: {
        avg7d: null,
        avg30d: null,
        avg90d: null,
        min7d: null,
        max7d: null,
        min30d: null,
        max30d: null,
        min90d: null,
        max90d: null,
        best30dDate: null,
        worst30dDate: null
      },
      history90d: [],
      disclaimer: "Cota\xE7\xE3o de refer\xEAncia interbanc\xE1ria (Frankfurter/BCE). N\xE3o representa o custo final de compra de moeda pela Wise.",
      errorMessage: "N\xE3o foi poss\xEDvel obter a cota\xE7\xE3o atualizada no momento. Tente novamente em instantes."
    };
  }
}
function analyzeOpportunity(fx, targetRate) {
  if (!fx.available || fx.latestRate === null) {
    return {
      available: false,
      classification: "Dados indispon\xEDveis",
      summary: "Sem dados cambiais recentes para calcular o radar de oportunidades.",
      reasons: [],
      metrics: {
        currentRate: null,
        avg7d: null,
        avg30d: null,
        avg90d: null,
        min90d: null,
        max90d: null,
        dailyChangePct: null,
        targetRate,
        distanceToTargetPct: null
      },
      source: fx.source,
      observationDate: fx.observationDate
    };
  }
  const current = fx.latestRate;
  const { avg7d, avg30d, avg90d, min90d, max90d } = fx.stats;
  const reasons = [];
  let score = 0;
  if (avg7d !== null) {
    const diff7 = (current - avg7d) / avg7d * 100;
    if (diff7 <= -1) {
      score += 2;
      reasons.push(`Est\xE1 ${Math.abs(diff7).toFixed(2)}% abaixo da m\xE9dia de 7 dias (${avg7d.toFixed(4)}).`);
    } else if (diff7 < 0) {
      score += 1;
      reasons.push(`Est\xE1 ${Math.abs(diff7).toFixed(2)}% abaixo da m\xE9dia de 7 dias (${avg7d.toFixed(4)}).`);
    } else if (diff7 > 1) {
      score -= 1;
      reasons.push(`Est\xE1 ${diff7.toFixed(2)}% acima da m\xE9dia de 7 dias (${avg7d.toFixed(4)}).`);
    } else {
      reasons.push(`Oscila\xE7\xE3o pr\xF3xima \xE0 m\xE9dia de 7 dias (${avg7d.toFixed(4)}).`);
    }
  }
  if (avg30d !== null) {
    const diff30 = (current - avg30d) / avg30d * 100;
    if (diff30 <= -1.5) {
      score += 2;
      reasons.push(`Est\xE1 ${Math.abs(diff30).toFixed(2)}% abaixo da m\xE9dia de 30 dias (${avg30d.toFixed(4)}).`);
    } else if (diff30 < 0) {
      score += 1;
      reasons.push(`Est\xE1 ${Math.abs(diff30).toFixed(2)}% abaixo da m\xE9dia de 30 dias (${avg30d.toFixed(4)}).`);
    } else if (diff30 >= 1.5) {
      score -= 2;
      reasons.push(`Est\xE1 ${diff30.toFixed(2)}% acima da m\xE9dia de 30 dias (${avg30d.toFixed(4)}).`);
    } else {
      reasons.push(`Pr\xF3xima \xE0 m\xE9dia de 30 dias (${avg30d.toFixed(4)}).`);
    }
  }
  if (avg90d !== null) {
    const diff90 = (current - avg90d) / avg90d * 100;
    if (diff90 <= -2) {
      score += 2;
      reasons.push(`Est\xE1 ${Math.abs(diff90).toFixed(2)}% abaixo da m\xE9dia de 90 dias (${avg90d.toFixed(4)}).`);
    } else if (diff90 > 2) {
      score -= 1;
      reasons.push(`Est\xE1 ${diff90.toFixed(2)}% acima da m\xE9dia de 90 dias (${avg90d.toFixed(4)}).`);
    }
  }
  if (min90d !== null && max90d !== null && max90d > min90d) {
    const pos = (current - min90d) / (max90d - min90d);
    if (pos <= 0.25) {
      score += 1;
      reasons.push(
        `No quartil mais favor\xE1vel dos \xFAltimos 90 dias (m\xEDnima de ${min90d.toFixed(4)} e m\xE1xima de ${max90d.toFixed(4)}).`
      );
    } else if (pos >= 0.8) {
      score -= 1;
      reasons.push(
        `Pr\xF3xima da m\xE1xima dos \xFAltimos 90 dias (m\xEDnima de ${min90d.toFixed(4)} e m\xE1xima de ${max90d.toFixed(4)}).`
      );
    }
  }
  let distanceToTargetPct = null;
  if (targetRate !== null && targetRate > 0) {
    distanceToTargetPct = (current - targetRate) / targetRate * 100;
    if (current <= targetRate) {
      score += 2;
      reasons.push(
        `Atingiu ou superou sua meta configurada (${targetRate.toFixed(4)}): est\xE1 ${Math.abs(distanceToTargetPct).toFixed(2)}% abaixo do alvo.`
      );
    } else if (distanceToTargetPct <= 1.2) {
      reasons.push(
        `Faltam ${distanceToTargetPct.toFixed(2)}% para alcan\xE7ar sua meta configurada (${targetRate.toFixed(4)}).`
      );
    } else {
      score -= 1;
      reasons.push(
        `Est\xE1 ${distanceToTargetPct.toFixed(2)}% acima da sua meta configurada (${targetRate.toFixed(4)}).`
      );
    }
  }
  let classification;
  let summary;
  if (score >= 4) {
    classification = "Excelente oportunidade";
    summary = "A cota\xE7\xE3o atual est\xE1 significativamente favor\xE1vel em rela\xE7\xE3o \xE0s m\xE9dias recentes e/ou abaixo da sua meta.";
  } else if (score >= 2) {
    classification = "Boa oportunidade";
    summary = "A taxa atual est\xE1 abaixo das m\xE9dias de curto/m\xE9dio prazo, favorecendo compras parciais.";
  } else if (score >= 0) {
    classification = "Oportunidade neutra";
    summary = "Cota\xE7\xE3o em linha com o comportamento recente. Estrat\xE9gia recomendada: manter compras graduais (pre\xE7o m\xE9dio).";
  } else {
    classification = "Momento desfavor\xE1vel";
    summary = "A cota\xE7\xE3o est\xE1 pressionada acima das m\xE9dias recentes. Avalie aguardar recuos ou fracionar apenas o essencial.";
  }
  return {
    available: true,
    classification,
    summary,
    reasons,
    metrics: {
      currentRate: current,
      avg7d,
      avg30d,
      avg90d,
      min90d,
      max90d,
      dailyChangePct: fx.percentChange,
      targetRate,
      distanceToTargetPct
    },
    source: fx.source,
    observationDate: fx.observationDate
  };
}

// server/skills/strategyService.ts
function parseYmdUtc(ymd) {
  if (!ymd || !/^\d{4}-\d{2}-\d{2}$/.test(ymd)) return null;
  const [y, m, d] = ymd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return Number.isNaN(dt.getTime()) ? null : dt;
}
function buildPurchaseStrategy(input) {
  const rate = Math.max(0.01, input.currentEurBrlRate || 6);
  const now = /* @__PURE__ */ new Date();
  const todayUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const dep = parseYmdUtc(input.tripDate);
  const ret = parseYmdUtc(input.returnDate);
  const targetDate = dep || new Date(now.getTime() + 180 * 864e5);
  const diffDays = Math.max(15, Math.ceil((targetDate.getTime() - todayUtc.getTime()) / 864e5));
  const monthsUntilTrip = Math.max(1, Number((diffDays / 30).toFixed(1)));
  const daysUntilDeparture = dep ? Math.round((dep.getTime() - todayUtc.getTime()) / 864e5) : null;
  let tripDurationDays = null;
  let tripDurationMonths = null;
  let daysUntilReturn = null;
  let temporalProgressPercent = null;
  if (dep && ret && ret.getTime() >= dep.getTime()) {
    tripDurationDays = Math.max(1, Math.round((ret.getTime() - dep.getTime()) / 864e5));
    tripDurationMonths = Number((tripDurationDays / 30.4375).toFixed(1));
    daysUntilReturn = Math.round((ret.getTime() - todayUtc.getTime()) / 864e5);
    if (todayUtc.getTime() < dep.getTime()) {
      temporalProgressPercent = 0;
    } else if (todayUtc.getTime() <= ret.getTime()) {
      const elapsed = Math.max(0, Math.round((todayUtc.getTime() - dep.getTime()) / 864e5));
      temporalProgressPercent = Number(Math.min(100, elapsed / tripDurationDays * 100).toFixed(1));
    } else {
      temporalProgressPercent = 100;
    }
  }
  const totalBudgetEurFromBrl = input.totalBudgetBrl > 0 ? input.totalBudgetBrl / rate : 0;
  const estimatedTotalEurNeeded = Math.max(
    totalBudgetEurFromBrl,
    input.expectedDestinationExpensesEur || 0
  );
  const savedInEurEquivalent = (input.alreadyAccumulatedEur || 0) + (input.alreadySavedBrl || 0) / rate;
  const remainingEurToBuy = Math.max(0, estimatedTotalEurNeeded - savedInEurEquivalent);
  const estimatedRemainingBrlNeeded = remainingEurToBuy * rate;
  const requiredMonthlySavingsBrl = estimatedRemainingBrlNeeded / monthsUntilTrip;
  const safeMonthlyCapacity = Math.max(0, input.monthlyAvailableBrl || 0);
  const recommendedMonthlyPurchaseBrl = safeMonthlyCapacity > 0 ? Math.min(requiredMonthlySavingsBrl, safeMonthlyCapacity) : requiredMonthlySavingsBrl;
  const tranchesCount = Math.max(2, Math.min(12, Math.round(monthsUntilTrip * 2)));
  const suggestedTrancheEur = remainingEurToBuy > 0 ? remainingEurToBuy / tranchesCount : 0;
  const dailyBudgetEur = tripDurationDays && estimatedTotalEurNeeded > 0 ? Number((estimatedTotalEurNeeded / tripDurationDays).toFixed(2)) : null;
  let liquidityWarning = null;
  if (safeMonthlyCapacity > 0 && requiredMonthlySavingsBrl > safeMonthlyCapacity) {
    liquidityWarning = `O ritmo necess\xE1rio (R$ ${requiredMonthlySavingsBrl.toFixed(2)}/m\xEAs) supera sua disponibilidade mensal informada (R$ ${safeMonthlyCapacity.toFixed(2)}/m\xEAs). N\xE3o comprometa sua reserva de emerg\xEAncia (R$ ${input.emergencyReserveBrl.toFixed(2)}) nem despesas essenciais; considere ampliar o prazo ou ajustar o or\xE7amento no destino.`;
  } else if (input.emergencyReserveBrl <= 0) {
    liquidityWarning = "Voc\xEA n\xE3o informou uma reserva de emerg\xEAncia separada. Recomendamos manter liquidez para imprevistos antes de converter valores para viagem.";
  }
  const safetyGuidance = [
    `Preserve intacta sua reserva de emerg\xEAncia (R$ ${input.emergencyReserveBrl.toFixed(2)}) em liquidez di\xE1ria.`,
    `Divida o valor restante (\u20AC ${remainingEurToBuy.toFixed(2)}) em cerca de ${tranchesCount} compras graduais (~\u20AC ${suggestedTrancheEur.toFixed(2)} por aporte) para diluir a volatilidade cambial.`,
    "Reserve aproximadamente 70% para compras programadas regulares e 30% para aproveitar eventuais quedas no Radar de Oportunidades."
  ];
  if (tripDurationDays && dailyBudgetEur !== null) {
    safetyGuidance.push(
      `Para sua estadia de ${tripDurationDays} dia(s), a meta equivale a cerca de \u20AC ${dailyBudgetEur.toFixed(2)}/dia.`
    );
  }
  return {
    monthsUntilTrip,
    tripDurationDays,
    tripDurationMonths,
    daysUntilDeparture,
    daysUntilReturn,
    temporalProgressPercent,
    estimatedTotalEurNeeded: Number(estimatedTotalEurNeeded.toFixed(2)),
    remainingEurToBuy: Number(remainingEurToBuy.toFixed(2)),
    estimatedRemainingBrlNeeded: Number(estimatedRemainingBrlNeeded.toFixed(2)),
    requiredMonthlySavingsBrl: Number(requiredMonthlySavingsBrl.toFixed(2)),
    recommendedMonthlyPurchaseBrl: Number(recommendedMonthlyPurchaseBrl.toFixed(2)),
    tranchesCount,
    suggestedTrancheEur: Number(suggestedTrancheEur.toFixed(2)),
    dailyBudgetEur,
    liquidityWarning,
    safetyGuidance
  };
}

// server/skills/wiseCalculator.ts
function calculateWiseConversion(input) {
  const rate = Math.max(0.01, Number(input.exchangeRate) || 6);
  const feePct = Math.max(0, Number(input.platformFeePercent) || 0) / 100;
  const fixedFeeBrl = Math.max(0, Number(input.platformFixedFeeBrl) || 0);
  const iofPct = Math.max(0, Number(input.iofPercent) || 0) / 100;
  const amount = Math.max(0, Number(input.amount) || 0);
  let brlBase = 0;
  let eurReceived = 0;
  let platformFeeBrl = 0;
  let iofBrl = 0;
  let brlDebited = 0;
  if (input.mode === "buy_target") {
    eurReceived = amount;
    brlBase = eurReceived * rate;
    platformFeeBrl = brlBase * feePct + fixedFeeBrl;
    iofBrl = (brlBase + platformFeeBrl) * iofPct;
    brlDebited = brlBase + platformFeeBrl + iofBrl;
  } else {
    brlDebited = amount;
    const netBeforeIof = Math.max(0, brlDebited / (1 + iofPct) - fixedFeeBrl);
    brlBase = netBeforeIof / (1 + feePct);
    platformFeeBrl = brlBase * feePct + fixedFeeBrl;
    iofBrl = Math.max(0, brlDebited - brlBase - platformFeeBrl);
    eurReceived = brlBase / rate;
  }
  const effectiveCostPerEur = eurReceived > 0 ? brlDebited / eurReceived : 0;
  const effectiveSpreadPct = rate > 0 && effectiveCostPerEur > 0 ? (effectiveCostPerEur - rate) / rate * 100 : 0;
  return {
    isActualOperation: Boolean(input.isActualOperation),
    mode: input.mode,
    brlDebited: Number(brlDebited.toFixed(2)),
    eurReceived: Number(eurReceived.toFixed(2)),
    exchangeRateUsed: Number(rate.toFixed(4)),
    platformFeeBrl: Number(platformFeeBrl.toFixed(2)),
    iofBrl: Number(iofBrl.toFixed(2)),
    totalTaxesAndFeesBrl: Number((platformFeeBrl + iofBrl).toFixed(2)),
    effectiveCostPerEur: Number(effectiveCostPerEur.toFixed(4)),
    effectiveSpreadPct: Number(effectiveSpreadPct.toFixed(2)),
    formulaDescription: `Custo efetivo = Total debitado (R$ ${brlDebited.toFixed(2)}) / Euros recebidos (\u20AC ${eurReceived.toFixed(2)}) = R$ ${effectiveCostPerEur.toFixed(4)} por EUR.`,
    disclaimer: "Simula\xE7\xE3o independente. O Madrid Finance n\xE3o possui acesso \xE0 sua conta Wise e taxas reais podem variar no momento da ordem."
  };
}

// server/geminiAssistant.ts
var fxToolDecl = {
  name: "get_fx_rates_and_history",
  description: "Skill 01 e Skill 03: Consulta cota\xE7\xE3o atual e hist\xF3rico de 7, 30 e 90 dias (Frankfurter/BCE e BCB PTAX) e avalia o Radar de Oportunidades para um par de moedas (padr\xE3o EUR/BRL).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      base: { type: Type.STRING, description: "Moeda base, ex: EUR, USD, GBP" },
      target: { type: Type.STRING, description: "Moeda destino, ex: BRL, EUR" },
      userTargetRate: {
        type: Type.NUMBER,
        description: "Meta opcional de cota\xE7\xE3o do usu\xE1rio"
      }
    }
  }
};
var economicsToolDecl = {
  name: "get_economic_intelligence",
  description: "Skill 02: Retorna indicadores verificados (Selic BCB, IPCA IBGE) e fatores econ\xF4micos (BCE, Fed, infla\xE7\xE3o, juros, risco geopol\xEDtico) separados em fatos, expectativas e hip\xF3teses.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      focus: { type: Type.STRING, description: "Tema econ\xF4mico principal da pergunta" }
    }
  }
};
var wiseToolDecl = {
  name: "simulate_wise_conversion",
  description: "Skill 04: Calcula simula\xE7\xE3o de convers\xE3o cambial (BRL <-> EUR) com taxa de servi\xE7o da plataforma, IOF informado e custo efetivo por euro.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      mode: {
        type: Type.STRING,
        description: "buy_target (comprar X euros) ou spend_source (gastar X reais)"
      },
      amount: { type: Type.NUMBER, description: "Valor desejado em EUR ou BRL" },
      exchangeRate: {
        type: Type.NUMBER,
        description: "Cota\xE7\xE3o de refer\xEAncia ou manual. Se omitido, usa a cota\xE7\xE3o atual EUR/BRL."
      },
      platformFeePercent: {
        type: Type.NUMBER,
        description: "Taxa percentual estimada da plataforma (ex: 1.15)"
      },
      iofPercent: {
        type: Type.NUMBER,
        description: "Al\xEDquota de IOF informada em % (ex: 1.1 ou 0.38)"
      }
    },
    required: ["amount"]
  }
};
var strategyToolDecl = {
  name: "build_purchase_strategy",
  description: "Skill 05 e Skill 07: Calcula planejamento mensal, ritmo de economia, compras graduais (DCA) e resumo de progresso financeiro at\xE9 a data da viagem.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      totalBudgetBrl: { type: Type.NUMBER },
      alreadySavedBrl: { type: Type.NUMBER },
      alreadyAccumulatedEur: { type: Type.NUMBER },
      emergencyReserveBrl: { type: Type.NUMBER },
      monthlyAvailableBrl: { type: Type.NUMBER },
      tripDate: { type: Type.STRING, description: "Data de ida YYYY-MM-DD" },
      returnDate: { type: Type.STRING, description: "Data de volta opcional YYYY-MM-DD" }
    }
  }
};
var flightsToolDecl = {
  name: "search_flights_info",
  description: "Skill 08: Consulta ofertas reais de passagens (quando Amadeus estiver configurada) ou gera links oficiais verificados de busca sem inventar pre\xE7os.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      origin: { type: Type.STRING, description: "C\xF3digo IATA de origem, ex: GRU, GIG, BSB" },
      destination: { type: Type.STRING, description: "C\xF3digo IATA de destino, ex: MAD" },
      departureDate: { type: Type.STRING, description: "Data ida YYYY-MM-DD" },
      returnDate: { type: Type.STRING, description: "Data volta YYYY-MM-DD" },
      passengers: { type: Type.NUMBER },
      directOnly: { type: Type.BOOLEAN }
    },
    required: ["origin", "destination"]
  }
};
async function runMadridAssistant(history, userMessage, userContext) {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error(
      "A chave GEMINI_API_KEY n\xE3o est\xE1 configurada no servidor (Settings > Secrets)."
    );
  }
  const cfg = getAdminConfig();
  const quota = recordAiCall();
  if (!quota.allowed) {
    throw new Error(
      "Limite di\xE1rio gratuito do assistente atingido no servidor. Tente novamente mais tarde ou utilize os pain\xE9is interativos gratuitos."
    );
  }
  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build"
      }
    }
  });
  const enabledSkillsList = Object.entries(cfg.skillsEnabled).filter(([, enabled]) => enabled).map(([id]) => id);
  const activeDeclarations = [];
  if (cfg.skillsEnabled.skill01_fx || cfg.skillsEnabled.skill03_radar) {
    activeDeclarations.push(fxToolDecl);
  }
  if (cfg.skillsEnabled.skill02_economics) {
    activeDeclarations.push(economicsToolDecl);
  }
  if (cfg.skillsEnabled.skill04_wise) {
    activeDeclarations.push(wiseToolDecl);
  }
  if (cfg.skillsEnabled.skill05_strategy || cfg.skillsEnabled.skill07_reports) {
    activeDeclarations.push(strategyToolDecl);
  }
  if (cfg.skillsEnabled.skill08_flights) {
    activeDeclarations.push(flightsToolDecl);
  }
  const contextBlock = userContext.consented ? `Contexto autorizado pelo usu\xE1rio (dados locais opcionais):
- Apelido: ${userContext.nickname || "Visitante"}
- Moeda base acompanhamento: ${userContext.originCurrency || "BRL"} -> EUR
- Destino: ${userContext.destinationCountry || "Espanha (Madrid)"}
- Data prevista da viagem (ida): ${userContext.tripDate || "N\xE3o informada"}
- Data de volta da viagem: ${userContext.returnDate || "N\xE3o informada"}
- Or\xE7amento total (BRL): ${userContext.totalBudgetBrl ?? 0}
- J\xE1 economizado (BRL): ${userContext.alreadySavedBrl ?? 0}
- J\xE1 acumulado (EUR): ${userContext.alreadyAccumulatedEur ?? 0}
- Reserva de emerg\xEAncia informada (BRL): ${userContext.emergencyReserveBrl ?? 0}
- Meta de cota\xE7\xE3o configurada: ${userContext.targetRate ?? "N\xE3o definida"}
- Disponibilidade mensal informada (BRL): ${userContext.monthlyAvailableBrl ?? 0}
- Compras reais registradas: ${userContext.purchasesCount ?? 0} (Custo m\xE9dio EUR: ${userContext.averageEurCostBrl ?? "N/A"})` : "O usu\xE1rio optou por N\xC3O enviar dados financeiros pessoais neste chat. Responda com base nas perguntas e nos dados p\xFAblicos de mercado; pe\xE7a apenas informa\xE7\xF5es pontuais se indispens\xE1veis.";
  const systemInstruction = `Voc\xEA \xE9 o assistente financeiro inteligente **Madrid Finance**, focado em planejamento de viagens internacionais, acompanhamento cambial e educa\xE7\xE3o financeira.

REGRAS OBRIGAT\xD3RIAS:
1. Idioma: Portugu\xEAs do Brasil, tom elegante, claro, objetivo e did\xE1tico.
2. Especialidades ativas no momento: ${enabledSkillsList.join(", ")}. Se uma especialidade estiver desativada, informe com clareza.
3. NUNCA invente cota\xE7\xF5es, datas, taxas ou pre\xE7os de passagens a\xE9reas. Sempre utilize as ferramentas dispon\xEDveis para buscar dados reais.
4. Sempre informe a **fonte** e a **data/hora de atualiza\xE7\xE3o** dos dados citados.
5. Diferencie claramente **dados verificados** de **simula\xE7\xF5es/estimativas** e **expectativas/hip\xF3teses**.
6. Para c\xE2mbio via Frankfurter/BCE, deixe expl\xEDcito que \xE9 uma **cota\xE7\xE3o de refer\xEAncia interbanc\xE1ria** e n\xE3o representa o custo final de compra na Wise (que inclui taxa de servi\xE7o + IOF).
7. Nunca afirme ter acesso \xE0 conta Wise, conta banc\xE1ria ou cart\xE3o do usu\xE1rio.
8. Recomende compras graduais e preserva\xE7\xE3o da reserva de emerg\xEAncia; nunca sugira comprometer recursos essenciais.
9. Inclua lembrete breve de que as informa\xE7\xF5es t\xEAm car\xE1ter educativo/informativo e n\xE3o substituem aconselhamento financeiro profissional.
10. Instru\xE7\xF5es adicionais da administra\xE7\xE3o: ${cfg.agentInstructions}

${contextBlock}`;
  const trimmedHistory = history.slice(-Math.max(2, cfg.limits.maxConversationMessages - 2));
  const contents = [
    ...trimmedHistory.map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.text.slice(0, cfg.limits.maxMessageChars) }]
    })),
    {
      role: "user",
      parts: [{ text: userMessage.slice(0, cfg.limits.maxMessageChars) }]
    }
  ];
  const tools = activeDeclarations.length > 0 ? [{ functionDeclarations: activeDeclarations }] : void 0;
  const skillsUsed = /* @__PURE__ */ new Set();
  const sourcesCited = /* @__PURE__ */ new Set();
  try {
    let response = await ai.models.generateContent({
      model: "gemini-4-hydrogen",
      contents,
      config: {
        systemInstruction,
        tools
      }
    });
    let round = 0;
    while (response.functionCalls && response.functionCalls.length > 0 && round < 3) {
      round += 1;
      const modelContent = response.candidates?.[0]?.content;
      if (!modelContent) break;
      contents.push(modelContent);
      const responseParts = [];
      for (const call of response.functionCalls) {
        const name = call.name || "";
        const args = call.args || {};
        let toolOutput = {};
        if (name === "get_fx_rates_and_history") {
          skillsUsed.add("Monitoramento Cambial & Radar");
          const base = typeof args.base === "string" ? args.base : "EUR";
          const target = typeof args.target === "string" ? args.target : "BRL";
          const fx = await getFxOverview(base, target);
          const targetRate = typeof args.userTargetRate === "number" ? args.userTargetRate : userContext.consented ? userContext.targetRate ?? null : null;
          const radar = analyzeOpportunity(fx, targetRate);
          sourcesCited.add(fx.source);
          if (fx.bcbPtax.available) sourcesCited.add(fx.bcbPtax.source);
          toolOutput = {
            available: fx.available,
            pair: `${fx.base}/${fx.target}`,
            latestRate: fx.latestRate,
            previousRate: fx.previousRate,
            absoluteChange: fx.absoluteChange,
            percentChange: fx.percentChange,
            observationDate: fx.observationDate,
            stale: fx.stale,
            stats: fx.stats,
            bcbPtax: fx.bcbPtax,
            radar,
            disclaimer: fx.disclaimer,
            errorMessage: fx.errorMessage
          };
        } else if (name === "get_economic_intelligence") {
          skillsUsed.add("Intelig\xEAncia Econ\xF4mica");
          const econ = await getEconomicIntelligence();
          econ.indicators.forEach((ind) => sourcesCited.add(ind.source));
          toolOutput = econ;
        } else if (name === "simulate_wise_conversion") {
          skillsUsed.add("Calculadora Wise");
          let rateToUse = typeof args.exchangeRate === "number" ? args.exchangeRate : 0;
          if (!rateToUse) {
            const fx = await getFxOverview("EUR", "BRL");
            rateToUse = fx.latestRate || 6.1;
            sourcesCited.add(fx.source);
          }
          const sim = calculateWiseConversion({
            mode: args.mode === "spend_source" ? "spend_source" : "buy_target",
            amount: Number(args.amount) || 500,
            exchangeRate: rateToUse,
            platformFeePercent: typeof args.platformFeePercent === "number" ? args.platformFeePercent : 1.15,
            iofPercent: typeof args.iofPercent === "number" ? args.iofPercent : 1.1
          });
          toolOutput = sim;
        } else if (name === "build_purchase_strategy") {
          skillsUsed.add("Estrat\xE9gia & Relat\xF3rio");
          const fx = await getFxOverview("EUR", "BRL");
          sourcesCited.add(fx.source);
          const plan = buildPurchaseStrategy({
            totalBudgetBrl: Number(args.totalBudgetBrl) || (userContext.consented ? userContext.totalBudgetBrl || 15e3 : 15e3),
            alreadySavedBrl: Number(args.alreadySavedBrl) || (userContext.consented ? userContext.alreadySavedBrl || 0 : 0),
            alreadyAccumulatedEur: Number(args.alreadyAccumulatedEur) || (userContext.consented ? userContext.alreadyAccumulatedEur || 0 : 0),
            emergencyReserveBrl: Number(args.emergencyReserveBrl) || (userContext.consented ? userContext.emergencyReserveBrl || 0 : 0),
            monthlyAvailableBrl: Number(args.monthlyAvailableBrl) || (userContext.consented ? userContext.monthlyAvailableBrl || 0 : 0),
            tripDate: typeof args.tripDate === "string" && args.tripDate || userContext.consented && userContext.tripDate || new Date(Date.now() + 180 * 864e5).toISOString().slice(0, 10),
            returnDate: typeof args.returnDate === "string" && args.returnDate || (userContext.consented ? userContext.returnDate : void 0) || void 0,
            expectedDestinationExpensesEur: 2e3,
            currentEurBrlRate: fx.latestRate || 6.1
          });
          toolOutput = {
            currentReferenceRate: fx.latestRate,
            observationDate: fx.observationDate,
            plan
          };
        } else if (name === "search_flights_info") {
          skillsUsed.add("Monitoramento de Passagens");
          const dep = typeof args.departureDate === "string" && args.departureDate || userContext.consented && userContext.tripDate || new Date(Date.now() + 60 * 864e5).toISOString().slice(0, 10);
          const ret = typeof args.returnDate === "string" && args.returnDate || (userContext.consented && userContext.returnDate ? userContext.returnDate : void 0);
          const flights = await searchFlights({
            origin: typeof args.origin === "string" ? args.origin : "GRU",
            destination: typeof args.destination === "string" ? args.destination : "MAD",
            departureDate: dep,
            returnDate: ret,
            roundTrip: Boolean(ret),
            passengers: Number(args.passengers) || 1,
            directOnly: Boolean(args.directOnly)
          });
          sourcesCited.add(flights.sourceLabel);
          toolOutput = flights;
        }
        responseParts.push({
          functionResponse: {
            id: call.id,
            name,
            response: toolOutput
          }
        });
      }
      contents.push({
        role: "user",
        parts: responseParts
      });
      response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents,
        config: {
          systemInstruction,
          tools
        }
      });
    }
    const finalText = response.text?.trim() || "N\xE3o foi poss\xEDvel gerar uma resposta completa no momento. Tente reformular sua pergunta.";
    return {
      text: finalText,
      skillsUsed: Array.from(skillsUsed),
      sourcesCited: Array.from(sourcesCited),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      quotaRemainingToday: quota.remainingToday
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro na API Gemini";
    logTechnicalError("gemini_assistant", msg);
    if (msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED")) {
      throw new Error(
        "Quota gratuita da API Gemini temporariamente esgotada. Aguarde alguns instantes ou consulte os pain\xE9is cambiais e calculadoras diretamente."
      );
    }
    throw new Error("N\xE3o foi poss\xEDvel consultar o assistente de IA no momento.");
  }
}

// server/rateLimit.ts
var buckets = /* @__PURE__ */ new Map();
var HOUR_MS = 60 * 60 * 1e3;
function getVisitorKey(req) {
  const visitorHeader = req.header("x-visitor-id")?.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 48);
  const ip = req.ip || req.socket.remoteAddress || "anon";
  return visitorHeader ? `${ip}:${visitorHeader}` : ip;
}
function checkVisitorRateLimit(visitorKey, bucketType, maxPerHour) {
  const key = `${bucketType}:${visitorKey}`;
  const now = Date.now();
  const windowStart = now - HOUR_MS;
  const bucket = buckets.get(key) || { timestamps: [] };
  bucket.timestamps = bucket.timestamps.filter((t) => t > windowStart);
  if (bucket.timestamps.length >= maxPerHour) {
    recordRateLimitRejection();
    const oldest = bucket.timestamps[0] ?? now;
    const retryAfterSeconds = Math.max(1, Math.ceil((oldest + HOUR_MS - now) / 1e3));
    buckets.set(key, bucket);
    return { allowed: false, remaining: 0, retryAfterSeconds };
  }
  bucket.timestamps.push(now);
  buckets.set(key, bucket);
  return {
    allowed: true,
    remaining: Math.max(0, maxPerHour - bucket.timestamps.length),
    retryAfterSeconds: 0
  };
}

// server.ts
var __filename = fileURLToPath(import.meta.url);
var __dirname = path2.dirname(__filename);
function logStructuredError(message, err) {
  const details = err instanceof Error ? { errorName: err.name, errorMessage: err.message, stack: err.stack } : err !== void 0 ? { error: String(err) } : {};
  console.error(
    JSON.stringify({
      severity: "ERROR",
      service: "madrid-finance",
      message,
      ...details
    })
  );
}
function resolvePort() {
  const rawPort = process.env.PORT;
  if (rawPort === void 0 || rawPort.trim() === "") {
    return 3e3;
  }
  const parsed = Number(rawPort);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    throw new Error(`Vari\xE1vel de ambiente PORT inv\xE1lida: "${rawPort}". Esperado inteiro entre 1 e 65535.`);
  }
  return parsed;
}
process.on("uncaughtException", (err) => {
  logStructuredError("Uncaught exception during execution", err);
  process.exit(1);
});
process.on("unhandledRejection", (reason) => {
  logStructuredError("Unhandled promise rejection", reason);
  process.exit(1);
});
async function startServer() {
  const PORT = resolvePort();
  const isRunningWithTsx = process.execArgv.some((arg) => arg.includes("tsx"));
  const isBundledServer = path2.basename(__filename) === "server.js";
  const distPath = path2.resolve(__dirname, "dist");
  const distIndexPath = path2.join(distPath, "index.html");
  const isProd = isBundledServer || process.env.NODE_ENV === "production" || process.env.npm_lifecycle_event === "start" || !isRunningWithTsx && process.env.NODE_ENV !== "development" && fs2.existsSync(distIndexPath);
  console.log(
    JSON.stringify({
      severity: "INFO",
      service: "madrid-finance",
      message: "Bootstrapping server",
      nodeVersion: process.version,
      pid: process.pid,
      entryFile: path2.basename(__filename),
      mode: isProd ? "production" : "development",
      nodeEnv: process.env.NODE_ENV ?? "unset",
      portEnv: process.env.PORT ?? "unset",
      resolvedPort: PORT,
      cwd: process.cwd(),
      distDir: distPath,
      distIndexExists: fs2.existsSync(distIndexPath),
      geminiConfigured: Boolean(
        process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"
      ),
      amadeusConfigured: Boolean(process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET),
      adminPasscodeCustom: Boolean(process.env.ADMIN_PASSCODE?.trim())
    })
  );
  const app = express();
  app.use(express.json({ limit: "256kb" }));
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "madrid-finance", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  app.get("/api/public-config", (_req, res) => {
    res.json(getPublicConfigSummary());
  });
  app.get("/api/fx", async (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill01_fx) {
      return res.status(503).json({
        error: "O m\xF3dulo de Monitoramento Cambial foi temporariamente desativado pela administra\xE7\xE3o."
      });
    }
    const visitor = getVisitorKey(req);
    const limit = checkVisitorRateLimit(visitor, "fx", cfg.limits.fxRequestsPerHourPerVisitor);
    if (!limit.allowed) {
      return res.status(429).json({
        error: `Limite de consultas cambiais atingido. Tente novamente em ${limit.retryAfterSeconds}s.`
      });
    }
    const base = String(req.query.base || "EUR");
    const target = String(req.query.target || "BRL");
    const targetRateParam = req.query.targetRate ? Number(req.query.targetRate) : null;
    const targetRate = targetRateParam && Number.isFinite(targetRateParam) ? targetRateParam : null;
    const overview = await getFxOverview(base, target);
    const radar = cfg.skillsEnabled.skill03_radar ? analyzeOpportunity(overview, targetRate) : null;
    res.json({ overview, radar, rateLimitRemaining: limit.remaining });
  });
  app.get("/api/economics", async (_req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill02_economics) {
      return res.status(503).json({
        error: "O m\xF3dulo de Intelig\xEAncia Econ\xF4mica foi temporariamente desativado pela administra\xE7\xE3o."
      });
    }
    const data = await getEconomicIntelligence();
    res.json(data);
  });
  app.post("/api/wise/simulate", (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill04_wise) {
      return res.status(503).json({
        error: "A Calculadora Wise foi temporariamente desativada pela administra\xE7\xE3o."
      });
    }
    const payload = req.body;
    const result = calculateWiseConversion(payload);
    res.json(result);
  });
  app.post("/api/strategy", (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill05_strategy) {
      return res.status(503).json({
        error: "O m\xF3dulo de Estrat\xE9gia de Compras foi temporariamente desativado pela administra\xE7\xE3o."
      });
    }
    const payload = req.body;
    const plan = buildPurchaseStrategy(payload);
    res.json(plan);
  });
  app.post("/api/flights/search", async (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill08_flights) {
      return res.status(503).json({
        error: "O m\xF3dulo de Monitoramento de Passagens foi temporariamente desativado pela administra\xE7\xE3o."
      });
    }
    const payload = req.body;
    const result = await searchFlights(payload);
    res.json(result);
  });
  app.post("/api/assistant/chat", async (req, res) => {
    const cfg = getAdminConfig();
    const visitor = getVisitorKey(req);
    const limit = checkVisitorRateLimit(visitor, "ai", cfg.limits.aiRequestsPerHourPerVisitor);
    if (!limit.allowed) {
      return res.status(429).json({
        error: `Voc\xEA atingiu o limite gratuito de ${cfg.limits.aiRequestsPerHourPerVisitor} mensagens por hora. Utilize as calculadoras e gr\xE1ficos gratuitos ou aguarde ${Math.ceil(
          limit.retryAfterSeconds / 60
        )} minuto(s).`
      });
    }
    const body = req.body || {};
    const userMessage = typeof body.message === "string" ? body.message.trim() : "";
    if (!userMessage) {
      return res.status(400).json({ error: "Envie uma pergunta para o assistente." });
    }
    if (userMessage.length > cfg.limits.maxMessageChars) {
      return res.status(400).json({
        error: `A mensagem excede o limite de ${cfg.limits.maxMessageChars} caracteres.`
      });
    }
    const history = Array.isArray(body.history) ? body.history : [];
    const userContext = body.userContext || { consented: false };
    try {
      const reply = await runMadridAssistant(history, userMessage, userContext);
      res.json({ ...reply, visitorRateLimitRemaining: limit.remaining });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro ao processar consulta no assistente.";
      res.status(502).json({ error: msg });
    }
  });
  app.post("/api/admin/login", (req, res) => {
    const passcode = typeof req.body?.passcode === "string" ? req.body.passcode : "";
    const token = createAdminSession(passcode);
    if (!token) {
      return res.status(401).json({ error: "C\xF3digo de acesso administrativo inv\xE1lido." });
    }
    res.json({ token });
  });
  app.get("/api/admin/overview", (req, res) => {
    if (!verifyAdminToken(req.header("authorization"))) {
      return res.status(401).json({ error: "N\xE3o autorizado." });
    }
    const cfg = getAdminConfig();
    const metricsAndLogs = getAdminMetricsAndLogs();
    res.json({
      config: {
        ...cfg,
        amadeus: {
          clientId: maskSecret(cfg.amadeus.clientId),
          clientSecret: maskSecret(cfg.amadeus.clientSecret),
          environment: cfg.amadeus.environment,
          configured: Boolean(cfg.amadeus.clientId && cfg.amadeus.clientSecret)
        },
        geminiConfigured: Boolean(
          process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"
        )
      },
      ...metricsAndLogs
    });
  });
  app.put("/api/admin/config", (req, res) => {
    if (!verifyAdminToken(req.header("authorization"))) {
      return res.status(401).json({ error: "N\xE3o autorizado." });
    }
    const updated = updateAdminConfig(req.body || {});
    res.json({
      ok: true,
      config: {
        ...updated,
        amadeus: {
          clientId: maskSecret(updated.amadeus.clientId),
          clientSecret: maskSecret(updated.amadeus.clientSecret),
          environment: updated.amadeus.environment,
          configured: Boolean(updated.amadeus.clientId && updated.amadeus.clientSecret)
        }
      }
    });
  });
  app.post("/api/admin/clear-cache", (req, res) => {
    if (!verifyAdminToken(req.header("authorization"))) {
      return res.status(401).json({ error: "N\xE3o autorizado." });
    }
    appCache.clearAll();
    res.json({ ok: true });
  });
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Endpoint n\xE3o encontrado." });
  });
  if (!isProd) {
    console.info("[Madrid Finance] Initializing Vite dev middleware...");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    if (!fs2.existsSync(distIndexPath)) {
      throw new Error(
        `Build de produ\xE7\xE3o ausente: ${distIndexPath} n\xE3o encontrado. Execute "npm run build" antes de iniciar.`
      );
    }
    console.info("[Madrid Finance] Serving production static bundle from", distPath);
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(distIndexPath);
    });
  }
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(
      JSON.stringify({
        severity: "INFO",
        service: "madrid-finance",
        message: `Server listening on http://0.0.0.0:${PORT}`,
        mode: isProd ? "production" : "development",
        port: PORT
      })
    );
  });
  server.on("error", (err) => {
    logStructuredError("HTTP server listen error", err);
    process.exit(1);
  });
  const shutdown = (signal) => {
    console.log(
      JSON.stringify({
        severity: "INFO",
        service: "madrid-finance",
        message: `Received ${signal}, shutting down server`
      })
    );
    server.close(() => {
      process.exit(0);
    });
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}
startServer().catch((err) => {
  logStructuredError("Failed to start Madrid Finance server", err);
  process.exit(1);
});
