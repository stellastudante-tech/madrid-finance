import "dotenv/config";
import express from "express";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { appCache } from "./server/cache.ts";
import {
  createAdminSession,
  getAdminConfig,
  getAdminMetricsAndLogs,
  getPublicConfigSummary,
  maskSecret,
  updateAdminConfig,
  verifyAdminToken,
} from "./server/config.ts";
import { runMadridAssistant, type ChatTurnInput, type MinimalUserContext } from "./server/geminiAssistant.ts";
import { checkVisitorRateLimit, getVisitorKey } from "./server/rateLimit.ts";
import { getEconomicIntelligence } from "./server/skills/economicsService.ts";
import { searchFlights, type FlightSearchRequest } from "./server/skills/flightsService.ts";
import { analyzeOpportunity, getFxOverview } from "./server/skills/fxService.ts";
import { buildPurchaseStrategy, type StrategyInput } from "./server/skills/strategyService.ts";
import { calculateWiseConversion, type WiseSimulationInput } from "./server/skills/wiseCalculator.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function logStructuredError(message: string, err?: unknown) {
  const details =
    err instanceof Error
      ? { errorName: err.name, errorMessage: err.message, stack: err.stack }
      : err !== undefined
      ? { error: String(err) }
      : {};
  console.error(
    JSON.stringify({
      severity: "ERROR",
      service: "madrid-finance",
      message,
      ...details,
    })
  );
}

function resolvePort(): number {
  const rawPort = process.env.PORT;
  if (rawPort === undefined || rawPort.trim() === "") {
    return 3000;
  }
  const parsed = Number(rawPort);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    throw new Error(`Variável de ambiente PORT inválida: "${rawPort}". Esperado inteiro entre 1 e 65535.`);
  }
  return parsed;
}

process.on("uncaughtException", (err) => {
  logStructuredError("Uncaught exception during execution", err);
  process.exit(1);
});

process.on("unhandledRejection", (reason) => {
  logStructuredError("Unhandled promise rejection", reason);
  process.exit(1);
});

async function startServer() {
  const PORT = resolvePort();
  const isRunningWithTsx = process.execArgv.some((arg) => arg.includes("tsx"));
  const isBundledServer = path.basename(__filename) === "server.js";
  const distPath = path.resolve(__dirname, "dist");
  const distIndexPath = path.join(distPath, "index.html");
  const isProd =
    isBundledServer ||
    process.env.NODE_ENV === "production" ||
    process.env.npm_lifecycle_event === "start" ||
    (!isRunningWithTsx && process.env.NODE_ENV !== "development" && fs.existsSync(distIndexPath));

  console.log(
    JSON.stringify({
      severity: "INFO",
      service: "madrid-finance",
      message: "Bootstrapping server",
      nodeVersion: process.version,
      pid: process.pid,
      entryFile: path.basename(__filename),
      mode: isProd ? "production" : "development",
      nodeEnv: process.env.NODE_ENV ?? "unset",
      portEnv: process.env.PORT ?? "unset",
      resolvedPort: PORT,
      cwd: process.cwd(),
      distDir: distPath,
      distIndexExists: fs.existsSync(distIndexPath),
      geminiConfigured: Boolean(
        process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"
      ),
      amadeusConfigured: Boolean(process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET),
      adminPasscodeCustom: Boolean(process.env.ADMIN_PASSCODE?.trim()),
    })
  );

  const app = express();
  app.use(express.json({ limit: "256kb" }));

  // Health & public config summary (never exposes any secret!)
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "madrid-finance", timestamp: new Date().toISOString() });
  });

  app.get("/api/public-config", (_req, res) => {
    res.json(getPublicConfigSummary());
  });

  // Skill 01 & Skill 03: FX Overview + Opportunity Radar
  app.get("/api/fx", async (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill01_fx) {
      return res.status(503).json({
        error: "O módulo de Monitoramento Cambial foi temporariamente desativado pela administração.",
      });
    }

    const visitor = getVisitorKey(req);
    const limit = checkVisitorRateLimit(visitor, "fx", cfg.limits.fxRequestsPerHourPerVisitor);
    if (!limit.allowed) {
      return res.status(429).json({
        error: `Limite de consultas cambiais atingido. Tente novamente em ${limit.retryAfterSeconds}s.`,
      });
    }

    const base = String(req.query.base || "EUR");
    const target = String(req.query.target || "BRL");
    const targetRateParam = req.query.targetRate ? Number(req.query.targetRate) : null;
    const targetRate = targetRateParam && Number.isFinite(targetRateParam) ? targetRateParam : null;

    const overview = await getFxOverview(base, target);
    const radar = cfg.skillsEnabled.skill03_radar
      ? analyzeOpportunity(overview, targetRate)
      : null;

    res.json({ overview, radar, rateLimitRemaining: limit.remaining });
  });

  // Skill 02: Economic Intelligence
  app.get("/api/economics", async (_req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill02_economics) {
      return res.status(503).json({
        error: "O módulo de Inteligência Econômica foi temporariamente desativado pela administração.",
      });
    }
    const data = await getEconomicIntelligence();
    res.json(data);
  });

  // Skill 04: Wise Simulator
  app.post("/api/wise/simulate", (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill04_wise) {
      return res.status(503).json({
        error: "A Calculadora Wise foi temporariamente desativada pela administração.",
      });
    }
    const payload = req.body as WiseSimulationInput;
    const result = calculateWiseConversion(payload);
    res.json(result);
  });

  // Skill 05: Purchase Strategy
  app.post("/api/strategy", (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill05_strategy) {
      return res.status(503).json({
        error: "O módulo de Estratégia de Compras foi temporariamente desativado pela administração.",
      });
    }
    const payload = req.body as StrategyInput;
    const plan = buildPurchaseStrategy(payload);
    res.json(plan);
  });

  // Skill 08: Flight Monitoring
  app.post("/api/flights/search", async (req, res) => {
    const cfg = getAdminConfig();
    if (!cfg.skillsEnabled.skill08_flights) {
      return res.status(503).json({
        error: "O módulo de Monitoramento de Passagens foi temporariamente desativado pela administração.",
      });
    }
    const payload = req.body as FlightSearchRequest;
    const result = await searchFlights(payload);
    res.json(result);
  });

  // Central AI Assistant (Gemini Server-Side)
  app.post("/api/assistant/chat", async (req, res) => {
    const cfg = getAdminConfig();
    const visitor = getVisitorKey(req);
    const limit = checkVisitorRateLimit(visitor, "ai", cfg.limits.aiRequestsPerHourPerVisitor);
    if (!limit.allowed) {
      return res.status(429).json({
        error: `Você atingiu o limite gratuito de ${cfg.limits.aiRequestsPerHourPerVisitor} mensagens por hora. Utilize as calculadoras e gráficos gratuitos ou aguarde ${Math.ceil(
          limit.retryAfterSeconds / 60
        )} minuto(s).`,
      });
    }

    const body = (req.body || {}) as {
      message?: string;
      history?: ChatTurnInput[];
      userContext?: MinimalUserContext;
    };

    const userMessage = typeof body.message === "string" ? body.message.trim() : "";
    if (!userMessage) {
      return res.status(400).json({ error: "Envie uma pergunta para o assistente." });
    }
    if (userMessage.length > cfg.limits.maxMessageChars) {
      return res.status(400).json({
        error: `A mensagem excede o limite de ${cfg.limits.maxMessageChars} caracteres.`,
      });
    }

    const history = Array.isArray(body.history) ? body.history : [];
    const userContext: MinimalUserContext = body.userContext || { consented: false };

    try {
      const reply = await runMadridAssistant(history, userMessage, userContext);
      res.json({ ...reply, visitorRateLimitRemaining: limit.remaining });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro ao processar consulta no assistente.";
      res.status(502).json({ error: msg });
    }
  });

  // Protected Admin Routes
  app.post("/api/admin/login", (req, res) => {
    const passcode = typeof req.body?.passcode === "string" ? req.body.passcode : "";
    const token = createAdminSession(passcode);
    if (!token) {
      return res.status(401).json({ error: "Código de acesso administrativo inválido." });
    }
    res.json({ token });
  });

  app.get("/api/admin/overview", (req, res) => {
    if (!verifyAdminToken(req.header("authorization"))) {
      return res.status(401).json({ error: "Não autorizado." });
    }
    const cfg = getAdminConfig();
    const metricsAndLogs = getAdminMetricsAndLogs();
    res.json({
      config: {
        ...cfg,
        amadeus: {
          clientId: maskSecret(cfg.amadeus.clientId),
          clientSecret: maskSecret(cfg.amadeus.clientSecret),
          environment: cfg.amadeus.environment,
          configured: Boolean(cfg.amadeus.clientId && cfg.amadeus.clientSecret),
        },
        geminiConfigured: Boolean(
          process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY"
        ),
      },
      ...metricsAndLogs,
    });
  });

  app.put("/api/admin/config", (req, res) => {
    if (!verifyAdminToken(req.header("authorization"))) {
      return res.status(401).json({ error: "Não autorizado." });
    }
    const updated = updateAdminConfig(req.body || {});
    res.json({
      ok: true,
      config: {
        ...updated,
        amadeus: {
          clientId: maskSecret(updated.amadeus.clientId),
          clientSecret: maskSecret(updated.amadeus.clientSecret),
          environment: updated.amadeus.environment,
          configured: Boolean(updated.amadeus.clientId && updated.amadeus.clientSecret),
        },
      },
    });
  });

  app.post("/api/admin/clear-cache", (req, res) => {
    if (!verifyAdminToken(req.header("authorization"))) {
      return res.status(401).json({ error: "Não autorizado." });
    }
    appCache.clearAll();
    res.json({ ok: true });
  });

  // Return JSON 404 for unmatched /api/* routes before SPA fallback
  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Endpoint não encontrado." });
  });

  // Frontend serving: Vite dev middleware or production static build
  if (!isProd) {
    console.info("[Madrid Finance] Initializing Vite dev middleware...");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    if (!fs.existsSync(distIndexPath)) {
      throw new Error(
        `Build de produção ausente: ${distIndexPath} não encontrado. Execute "npm run build" antes de iniciar.`
      );
    }
    console.info("[Madrid Finance] Serving production static bundle from", distPath);
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(distIndexPath);
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(
      JSON.stringify({
        severity: "INFO",
        service: "madrid-finance",
        message: `Server listening on http://0.0.0.0:${PORT}`,
        mode: isProd ? "production" : "development",
        port: PORT,
      })
    );
  });

  server.on("error", (err) => {
    logStructuredError("HTTP server listen error", err);
    process.exit(1);
  });

  const shutdown = (signal: string) => {
    console.log(
      JSON.stringify({
        severity: "INFO",
        service: "madrid-finance",
        message: `Received ${signal}, shutting down server`,
      })
    );
    server.close(() => {
      process.exit(0);
    });
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

startServer().catch((err) => {
  logStructuredError("Failed to start Madrid Finance server", err);
  process.exit(1);
});
