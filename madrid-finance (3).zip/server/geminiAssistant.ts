import { GoogleGenAI, Type, type Content, type FunctionDeclaration } from "@google/genai";
import { getAdminConfig, logTechnicalError, recordAiCall } from "./config.ts";
import { getEconomicIntelligence } from "./skills/economicsService.ts";
import { searchFlights } from "./skills/flightsService.ts";
import { analyzeOpportunity, getFxOverview } from "./skills/fxService.ts";
import { buildPurchaseStrategy } from "./skills/strategyService.ts";
import { calculateWiseConversion } from "./skills/wiseCalculator.ts";

export interface ChatTurnInput {
  role: "user" | "assistant";
  text: string;
}

export interface MinimalUserContext {
  consented: boolean;
  nickname?: string;
  originCurrency?: string;
  destinationCountry?: string;
  tripDate?: string;
  returnDate?: string;
  totalBudgetBrl?: number;
  alreadySavedBrl?: number;
  alreadyAccumulatedEur?: number;
  emergencyReserveBrl?: number;
  targetRate?: number | null;
  monthlyAvailableBrl?: number;
  purchasesCount?: number;
  averageEurCostBrl?: number | null;
}

export interface AssistantReply {
  text: string;
  skillsUsed: string[];
  sourcesCited: string[];
  updatedAt: string;
  quotaRemainingToday: number;
}

const fxToolDecl: FunctionDeclaration = {
  name: "get_fx_rates_and_history",
  description:
    "Skill 01 e Skill 03: Consulta cotação atual e histórico de 7, 30 e 90 dias (Frankfurter/BCE e BCB PTAX) e avalia o Radar de Oportunidades para um par de moedas (padrão EUR/BRL).",
  parameters: {
    type: Type.OBJECT,
    properties: {
      base: { type: Type.STRING, description: "Moeda base, ex: EUR, USD, GBP" },
      target: { type: Type.STRING, description: "Moeda destino, ex: BRL, EUR" },
      userTargetRate: {
        type: Type.NUMBER,
        description: "Meta opcional de cotação do usuário",
      },
    },
  },
};

const economicsToolDecl: FunctionDeclaration = {
  name: "get_economic_intelligence",
  description:
    "Skill 02: Retorna indicadores verificados (Selic BCB, IPCA IBGE) e fatores econômicos (BCE, Fed, inflação, juros, risco geopolítico) separados em fatos, expectativas e hipóteses.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      focus: { type: Type.STRING, description: "Tema econômico principal da pergunta" },
    },
  },
};

const wiseToolDecl: FunctionDeclaration = {
  name: "simulate_wise_conversion",
  description:
    "Skill 04: Calcula simulação de conversão cambial (BRL <-> EUR) com taxa de serviço da plataforma, IOF informado e custo efetivo por euro.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      mode: {
        type: Type.STRING,
        description: "buy_target (comprar X euros) ou spend_source (gastar X reais)",
      },
      amount: { type: Type.NUMBER, description: "Valor desejado em EUR ou BRL" },
      exchangeRate: {
        type: Type.NUMBER,
        description: "Cotação de referência ou manual. Se omitido, usa a cotação atual EUR/BRL.",
      },
      platformFeePercent: {
        type: Type.NUMBER,
        description: "Taxa percentual estimada da plataforma (ex: 1.15)",
      },
      iofPercent: {
        type: Type.NUMBER,
        description: "Alíquota de IOF informada em % (ex: 1.1 ou 0.38)",
      },
    },
    required: ["amount"],
  },
};

const strategyToolDecl: FunctionDeclaration = {
  name: "build_purchase_strategy",
  description:
    "Skill 05 e Skill 07: Calcula planejamento mensal, ritmo de economia, compras graduais (DCA) e resumo de progresso financeiro até a data da viagem.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      totalBudgetBrl: { type: Type.NUMBER },
      alreadySavedBrl: { type: Type.NUMBER },
      alreadyAccumulatedEur: { type: Type.NUMBER },
      emergencyReserveBrl: { type: Type.NUMBER },
      monthlyAvailableBrl: { type: Type.NUMBER },
      tripDate: { type: Type.STRING, description: "Data de ida YYYY-MM-DD" },
      returnDate: { type: Type.STRING, description: "Data de volta opcional YYYY-MM-DD" },
    },
  },
};

const flightsToolDecl: FunctionDeclaration = {
  name: "search_flights_info",
  description:
    "Skill 08: Consulta ofertas reais de passagens (quando Amadeus estiver configurada) ou gera links oficiais verificados de busca sem inventar preços.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      origin: { type: Type.STRING, description: "Código IATA de origem, ex: GRU, GIG, BSB" },
      destination: { type: Type.STRING, description: "Código IATA de destino, ex: MAD" },
      departureDate: { type: Type.STRING, description: "Data ida YYYY-MM-DD" },
      returnDate: { type: Type.STRING, description: "Data volta YYYY-MM-DD" },
      passengers: { type: Type.NUMBER },
      directOnly: { type: Type.BOOLEAN },
    },
    required: ["origin", "destination"],
  },
};

export async function runMadridAssistant(
  history: ChatTurnInput[],
  userMessage: string,
  userContext: MinimalUserContext
): Promise<AssistantReply> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error(
      "A chave GEMINI_API_KEY não está configurada no servidor (Settings > Secrets)."
    );
  }

  const cfg = getAdminConfig();
  const quota = recordAiCall();
  if (!quota.allowed) {
    throw new Error(
      "Limite diário gratuito do assistente atingido no servidor. Tente novamente mais tarde ou utilize os painéis interativos gratuitos."
    );
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  const enabledSkillsList = Object.entries(cfg.skillsEnabled)
    .filter(([, enabled]) => enabled)
    .map(([id]) => id);

  const activeDeclarations: FunctionDeclaration[] = [];
  if (cfg.skillsEnabled.skill01_fx || cfg.skillsEnabled.skill03_radar) {
    activeDeclarations.push(fxToolDecl);
  }
  if (cfg.skillsEnabled.skill02_economics) {
    activeDeclarations.push(economicsToolDecl);
  }
  if (cfg.skillsEnabled.skill04_wise) {
    activeDeclarations.push(wiseToolDecl);
  }
  if (cfg.skillsEnabled.skill05_strategy || cfg.skillsEnabled.skill07_reports) {
    activeDeclarations.push(strategyToolDecl);
  }
  if (cfg.skillsEnabled.skill08_flights) {
    activeDeclarations.push(flightsToolDecl);
  }

  const contextBlock = userContext.consented
    ? `Contexto autorizado pelo usuário (dados locais opcionais):
- Apelido: ${userContext.nickname || "Visitante"}
- Moeda base acompanhamento: ${userContext.originCurrency || "BRL"} -> EUR
- Destino: ${userContext.destinationCountry || "Espanha (Madrid)"}
- Data prevista da viagem (ida): ${userContext.tripDate || "Não informada"}
- Data de volta da viagem: ${userContext.returnDate || "Não informada"}
- Orçamento total (BRL): ${userContext.totalBudgetBrl ?? 0}
- Já economizado (BRL): ${userContext.alreadySavedBrl ?? 0}
- Já acumulado (EUR): ${userContext.alreadyAccumulatedEur ?? 0}
- Reserva de emergência informada (BRL): ${userContext.emergencyReserveBrl ?? 0}
- Meta de cotação configurada: ${userContext.targetRate ?? "Não definida"}
- Disponibilidade mensal informada (BRL): ${userContext.monthlyAvailableBrl ?? 0}
- Compras reais registradas: ${userContext.purchasesCount ?? 0} (Custo médio EUR: ${userContext.averageEurCostBrl ?? "N/A"})`
    : "O usuário optou por NÃO enviar dados financeiros pessoais neste chat. Responda com base nas perguntas e nos dados públicos de mercado; peça apenas informações pontuais se indispensáveis.";

  const systemInstruction = `Você é o assistente financeiro inteligente **Madrid Finance**, focado em planejamento de viagens internacionais, acompanhamento cambial e educação financeira.

REGRAS OBRIGATÓRIAS:
1. Idioma: Português do Brasil, tom elegante, claro, objetivo e didático.
2. Especialidades ativas no momento: ${enabledSkillsList.join(", ")}. Se uma especialidade estiver desativada, informe com clareza.
3. NUNCA invente cotações, datas, taxas ou preços de passagens aéreas. Sempre utilize as ferramentas disponíveis para buscar dados reais.
4. Sempre informe a **fonte** e a **data/hora de atualização** dos dados citados.
5. Diferencie claramente **dados verificados** de **simulações/estimativas** e **expectativas/hipóteses**.
6. Para câmbio via Frankfurter/BCE, deixe explícito que é uma **cotação de referência interbancária** e não representa o custo final de compra na Wise (que inclui taxa de serviço + IOF).
7. Nunca afirme ter acesso à conta Wise, conta bancária ou cartão do usuário.
8. Recomende compras graduais e preservação da reserva de emergência; nunca sugira comprometer recursos essenciais.
9. Inclua lembrete breve de que as informações têm caráter educativo/informativo e não substituem aconselhamento financeiro profissional.
10. Instruções adicionais da administração: ${cfg.agentInstructions}

${contextBlock}`;

  const trimmedHistory = history.slice(-Math.max(2, cfg.limits.maxConversationMessages - 2));
  const contents: Content[] = [
    ...trimmedHistory.map((m) => ({
      role: m.role === "assistant" ? ("model" as const) : ("user" as const),
      parts: [{ text: m.text.slice(0, cfg.limits.maxMessageChars) }],
    })),
    {
      role: "user" as const,
      parts: [{ text: userMessage.slice(0, cfg.limits.maxMessageChars) }],
    },
  ];

  const tools = activeDeclarations.length > 0 ? [{ functionDeclarations: activeDeclarations }] : undefined;

  const skillsUsed = new Set<string>();
  const sourcesCited = new Set<string>();

  try {
    let response = await ai.models.generateContent({
      model: "gemini-4-hydrogen",
      contents,
      config: {
        systemInstruction,
        tools,
      },
    });

    // Handle up to 3 rounds of function calls cleanly
    let round = 0;
    while (response.functionCalls && response.functionCalls.length > 0 && round < 3) {
      round += 1;
      const modelContent = response.candidates?.[0]?.content;
      if (!modelContent) break;

      contents.push(modelContent);
      const responseParts: Array<{
        functionResponse: { id?: string; name: string; response: Record<string, unknown> };
      }> = [];

      for (const call of response.functionCalls) {
        const name = call.name || "";
        const args = (call.args || {}) as Record<string, unknown>;
        let toolOutput: Record<string, unknown> = {};

        if (name === "get_fx_rates_and_history") {
          skillsUsed.add("Monitoramento Cambial & Radar");
          const base = typeof args.base === "string" ? args.base : "EUR";
          const target = typeof args.target === "string" ? args.target : "BRL";
          const fx = await getFxOverview(base, target);
          const targetRate =
            typeof args.userTargetRate === "number"
              ? args.userTargetRate
              : userContext.consented
              ? userContext.targetRate ?? null
              : null;
          const radar = analyzeOpportunity(fx, targetRate);
          sourcesCited.add(fx.source);
          if (fx.bcbPtax.available) sourcesCited.add(fx.bcbPtax.source);
          toolOutput = {
            available: fx.available,
            pair: `${fx.base}/${fx.target}`,
            latestRate: fx.latestRate,
            previousRate: fx.previousRate,
            absoluteChange: fx.absoluteChange,
            percentChange: fx.percentChange,
            observationDate: fx.observationDate,
            stale: fx.stale,
            stats: fx.stats,
            bcbPtax: fx.bcbPtax,
            radar,
            disclaimer: fx.disclaimer,
            errorMessage: fx.errorMessage,
          };
        } else if (name === "get_economic_intelligence") {
          skillsUsed.add("Inteligência Econômica");
          const econ = await getEconomicIntelligence();
          econ.indicators.forEach((ind) => sourcesCited.add(ind.source));
          toolOutput = econ as unknown as Record<string, unknown>;
        } else if (name === "simulate_wise_conversion") {
          skillsUsed.add("Calculadora Wise");
          let rateToUse = typeof args.exchangeRate === "number" ? args.exchangeRate : 0;
          if (!rateToUse) {
            const fx = await getFxOverview("EUR", "BRL");
            rateToUse = fx.latestRate || 6.1;
            sourcesCited.add(fx.source);
          }
          const sim = calculateWiseConversion({
            mode: args.mode === "spend_source" ? "spend_source" : "buy_target",
            amount: Number(args.amount) || 500,
            exchangeRate: rateToUse,
            platformFeePercent:
              typeof args.platformFeePercent === "number" ? args.platformFeePercent : 1.15,
            iofPercent: typeof args.iofPercent === "number" ? args.iofPercent : 1.1,
          });
          toolOutput = sim as unknown as Record<string, unknown>;
        } else if (name === "build_purchase_strategy") {
          skillsUsed.add("Estratégia & Relatório");
          const fx = await getFxOverview("EUR", "BRL");
          sourcesCited.add(fx.source);
          const plan = buildPurchaseStrategy({
            totalBudgetBrl:
              Number(args.totalBudgetBrl) ||
              (userContext.consented ? userContext.totalBudgetBrl || 15000 : 15000),
            alreadySavedBrl:
              Number(args.alreadySavedBrl) ||
              (userContext.consented ? userContext.alreadySavedBrl || 0 : 0),
            alreadyAccumulatedEur:
              Number(args.alreadyAccumulatedEur) ||
              (userContext.consented ? userContext.alreadyAccumulatedEur || 0 : 0),
            emergencyReserveBrl:
              Number(args.emergencyReserveBrl) ||
              (userContext.consented ? userContext.emergencyReserveBrl || 0 : 0),
            monthlyAvailableBrl:
              Number(args.monthlyAvailableBrl) ||
              (userContext.consented ? userContext.monthlyAvailableBrl || 0 : 0),
            tripDate:
              (typeof args.tripDate === "string" && args.tripDate) ||
              (userContext.consented && userContext.tripDate) ||
              new Date(Date.now() + 180 * 86400_000).toISOString().slice(0, 10),
            returnDate:
              (typeof args.returnDate === "string" && args.returnDate) ||
              (userContext.consented ? userContext.returnDate : undefined) ||
              undefined,
            expectedDestinationExpensesEur: 2000,
            currentEurBrlRate: fx.latestRate || 6.1,
          });
          toolOutput = {
            currentReferenceRate: fx.latestRate,
            observationDate: fx.observationDate,
            plan,
          };
        } else if (name === "search_flights_info") {
          skillsUsed.add("Monitoramento de Passagens");
          const dep =
            (typeof args.departureDate === "string" && args.departureDate) ||
            (userContext.consented && userContext.tripDate) ||
            new Date(Date.now() + 60 * 86400_000).toISOString().slice(0, 10);
          const ret =
            (typeof args.returnDate === "string" && args.returnDate) ||
            (userContext.consented && userContext.returnDate ? userContext.returnDate : undefined);
          const flights = await searchFlights({
            origin: typeof args.origin === "string" ? args.origin : "GRU",
            destination: typeof args.destination === "string" ? args.destination : "MAD",
            departureDate: dep,
            returnDate: ret,
            roundTrip: Boolean(ret),
            passengers: Number(args.passengers) || 1,
            directOnly: Boolean(args.directOnly),
          });
          sourcesCited.add(flights.sourceLabel);
          toolOutput = flights as unknown as Record<string, unknown>;
        }

        responseParts.push({
          functionResponse: {
            id: call.id,
            name,
            response: toolOutput,
          },
        });
      }

      contents.push({
        role: "user",
        parts: responseParts,
      });

      response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents,
        config: {
          systemInstruction,
          tools,
        },
      });
    }

    const finalText =
      response.text?.trim() ||
      "Não foi possível gerar uma resposta completa no momento. Tente reformular sua pergunta.";

    return {
      text: finalText,
      skillsUsed: Array.from(skillsUsed),
      sourcesCited: Array.from(sourcesCited),
      updatedAt: new Date().toISOString(),
      quotaRemainingToday: quota.remainingToday,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro na API Gemini";
    logTechnicalError("gemini_assistant", msg);
    if (msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED")) {
      throw new Error(
        "Quota gratuita da API Gemini temporariamente esgotada. Aguarde alguns instantes ou consulte os painéis cambiais e calculadoras diretamente."
      );
    }
    throw new Error("Não foi possível consultar o assistente de IA no momento.");
  }
}
