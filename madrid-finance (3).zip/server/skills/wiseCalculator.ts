export interface WiseSimulationInput {
  mode: "buy_target" | "spend_source";
  amount: number;
  exchangeRate: number;
  platformFeePercent: number;
  platformFixedFeeBrl?: number;
  iofPercent: number;
  isActualOperation?: boolean;
  sourceLabel?: string;
}

export interface WiseSimulationResult {
  isActualOperation: boolean;
  mode: "buy_target" | "spend_source";
  brlDebited: number;
  eurReceived: number;
  exchangeRateUsed: number;
  platformFeeBrl: number;
  iofBrl: number;
  totalTaxesAndFeesBrl: number;
  effectiveCostPerEur: number;
  effectiveSpreadPct: number;
  formulaDescription: string;
  disclaimer: string;
}

export function calculateWiseConversion(input: WiseSimulationInput): WiseSimulationResult {
  const rate = Math.max(0.01, Number(input.exchangeRate) || 6.0);
  const feePct = Math.max(0, Number(input.platformFeePercent) || 0) / 100;
  const fixedFeeBrl = Math.max(0, Number(input.platformFixedFeeBrl) || 0);
  const iofPct = Math.max(0, Number(input.iofPercent) || 0) / 100;
  const amount = Math.max(0, Number(input.amount) || 0);

  let brlBase = 0;
  let eurReceived = 0;
  let platformFeeBrl = 0;
  let iofBrl = 0;
  let brlDebited = 0;

  if (input.mode === "buy_target") {
    // User wants to receive exact `amount` EUR
    eurReceived = amount;
    brlBase = eurReceived * rate;
    platformFeeBrl = brlBase * feePct + fixedFeeBrl;
    iofBrl = (brlBase + platformFeeBrl) * iofPct;
    brlDebited = brlBase + platformFeeBrl + iofBrl;
  } else {
    // User wants to spend exact `amount` BRL total
    brlDebited = amount;
    const netBeforeIof = Math.max(0, (brlDebited / (1 + iofPct)) - fixedFeeBrl);
    brlBase = netBeforeIof / (1 + feePct);
    platformFeeBrl = brlBase * feePct + fixedFeeBrl;
    iofBrl = Math.max(0, brlDebited - brlBase - platformFeeBrl);
    eurReceived = brlBase / rate;
  }

  const effectiveCostPerEur = eurReceived > 0 ? brlDebited / eurReceived : 0;
  const effectiveSpreadPct = rate > 0 && effectiveCostPerEur > 0 ? ((effectiveCostPerEur - rate) / rate) * 100 : 0;

  return {
    isActualOperation: Boolean(input.isActualOperation),
    mode: input.mode,
    brlDebited: Number(brlDebited.toFixed(2)),
    eurReceived: Number(eurReceived.toFixed(2)),
    exchangeRateUsed: Number(rate.toFixed(4)),
    platformFeeBrl: Number(platformFeeBrl.toFixed(2)),
    iofBrl: Number(iofBrl.toFixed(2)),
    totalTaxesAndFeesBrl: Number((platformFeeBrl + iofBrl).toFixed(2)),
    effectiveCostPerEur: Number(effectiveCostPerEur.toFixed(4)),
    effectiveSpreadPct: Number(effectiveSpreadPct.toFixed(2)),
    formulaDescription: `Custo efetivo = Total debitado (R$ ${brlDebited.toFixed(2)}) / Euros recebidos (€ ${eurReceived.toFixed(2)}) = R$ ${effectiveCostPerEur.toFixed(4)} por EUR.`,
    disclaimer:
      "Simulação independente. O Madrid Finance não possui acesso à sua conta Wise e taxas reais podem variar no momento da ordem.",
  };
}
