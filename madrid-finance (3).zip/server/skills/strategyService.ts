export interface StrategyInput {
  totalBudgetBrl: number;
  alreadySavedBrl: number;
  alreadyAccumulatedEur: number;
  emergencyReserveBrl: number;
  monthlyAvailableBrl: number;
  tripDate: string;
  returnDate?: string;
  expectedDestinationExpensesEur: number;
  currentEurBrlRate: number;
}

export interface StrategyPlan {
  monthsUntilTrip: number;
  tripDurationDays: number | null;
  tripDurationMonths: number | null;
  daysUntilDeparture: number | null;
  daysUntilReturn: number | null;
  temporalProgressPercent: number | null;
  estimatedTotalEurNeeded: number;
  remainingEurToBuy: number;
  estimatedRemainingBrlNeeded: number;
  requiredMonthlySavingsBrl: number;
  recommendedMonthlyPurchaseBrl: number;
  tranchesCount: number;
  suggestedTrancheEur: number;
  dailyBudgetEur: number | null;
  liquidityWarning: string | null;
  safetyGuidance: string[];
}

function parseYmdUtc(ymd?: string): Date | null {
  if (!ymd || !/^\d{4}-\d{2}-\d{2}$/.test(ymd)) return null;
  const [y, m, d] = ymd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return Number.isNaN(dt.getTime()) ? null : dt;
}

export function buildPurchaseStrategy(input: StrategyInput): StrategyPlan {
  const rate = Math.max(0.01, input.currentEurBrlRate || 6.0);
  const now = new Date();
  const todayUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const dep = parseYmdUtc(input.tripDate);
  const ret = parseYmdUtc(input.returnDate);

  const targetDate = dep || new Date(now.getTime() + 180 * 86400_000);
  const diffDays = Math.max(15, Math.ceil((targetDate.getTime() - todayUtc.getTime()) / 86400_000));
  const monthsUntilTrip = Math.max(1, Number((diffDays / 30).toFixed(1)));

  const daysUntilDeparture = dep ? Math.round((dep.getTime() - todayUtc.getTime()) / 86400_000) : null;
  let tripDurationDays: number | null = null;
  let tripDurationMonths: number | null = null;
  let daysUntilReturn: number | null = null;
  let temporalProgressPercent: number | null = null;

  if (dep && ret && ret.getTime() >= dep.getTime()) {
    tripDurationDays = Math.max(1, Math.round((ret.getTime() - dep.getTime()) / 86400_000));
    tripDurationMonths = Number((tripDurationDays / 30.4375).toFixed(1));
    daysUntilReturn = Math.round((ret.getTime() - todayUtc.getTime()) / 86400_000);
    if (todayUtc.getTime() < dep.getTime()) {
      temporalProgressPercent = 0;
    } else if (todayUtc.getTime() <= ret.getTime()) {
      const elapsed = Math.max(0, Math.round((todayUtc.getTime() - dep.getTime()) / 86400_000));
      temporalProgressPercent = Number(Math.min(100, (elapsed / tripDurationDays) * 100).toFixed(1));
    } else {
      temporalProgressPercent = 100;
    }
  }

  const totalBudgetEurFromBrl = input.totalBudgetBrl > 0 ? input.totalBudgetBrl / rate : 0;
  const estimatedTotalEurNeeded = Math.max(
    totalBudgetEurFromBrl,
    input.expectedDestinationExpensesEur || 0
  );

  const savedInEurEquivalent =
    (input.alreadyAccumulatedEur || 0) + (input.alreadySavedBrl || 0) / rate;
  const remainingEurToBuy = Math.max(0, estimatedTotalEurNeeded - savedInEurEquivalent);
  const estimatedRemainingBrlNeeded = remainingEurToBuy * rate;

  const requiredMonthlySavingsBrl = estimatedRemainingBrlNeeded / monthsUntilTrip;
  const safeMonthlyCapacity = Math.max(0, input.monthlyAvailableBrl || 0);
  const recommendedMonthlyPurchaseBrl =
    safeMonthlyCapacity > 0
      ? Math.min(requiredMonthlySavingsBrl, safeMonthlyCapacity)
      : requiredMonthlySavingsBrl;

  const tranchesCount = Math.max(2, Math.min(12, Math.round(monthsUntilTrip * 2)));
  const suggestedTrancheEur = remainingEurToBuy > 0 ? remainingEurToBuy / tranchesCount : 0;
  const dailyBudgetEur =
    tripDurationDays && estimatedTotalEurNeeded > 0
      ? Number((estimatedTotalEurNeeded / tripDurationDays).toFixed(2))
      : null;

  let liquidityWarning: string | null = null;
  if (safeMonthlyCapacity > 0 && requiredMonthlySavingsBrl > safeMonthlyCapacity) {
    liquidityWarning =
      `O ritmo necessário (R$ ${requiredMonthlySavingsBrl.toFixed(2)}/mês) supera sua disponibilidade mensal informada (R$ ${safeMonthlyCapacity.toFixed(2)}/mês). Não comprometa sua reserva de emergência (R$ ${input.emergencyReserveBrl.toFixed(2)}) nem despesas essenciais; considere ampliar o prazo ou ajustar o orçamento no destino.`;
  } else if (input.emergencyReserveBrl <= 0) {
    liquidityWarning =
      "Você não informou uma reserva de emergência separada. Recomendamos manter liquidez para imprevistos antes de converter valores para viagem.";
  }

  const safetyGuidance = [
    `Preserve intacta sua reserva de emergência (R$ ${input.emergencyReserveBrl.toFixed(2)}) em liquidez diária.`,
    `Divida o valor restante (€ ${remainingEurToBuy.toFixed(2)}) em cerca de ${tranchesCount} compras graduais (~€ ${suggestedTrancheEur.toFixed(2)} por aporte) para diluir a volatilidade cambial.`,
    "Reserve aproximadamente 70% para compras programadas regulares e 30% para aproveitar eventuais quedas no Radar de Oportunidades.",
  ];

  if (tripDurationDays && dailyBudgetEur !== null) {
    safetyGuidance.push(
      `Para sua estadia de ${tripDurationDays} dia(s), a meta equivale a cerca de € ${dailyBudgetEur.toFixed(2)}/dia.`
    );
  }

  return {
    monthsUntilTrip,
    tripDurationDays,
    tripDurationMonths,
    daysUntilDeparture,
    daysUntilReturn,
    temporalProgressPercent,
    estimatedTotalEurNeeded: Number(estimatedTotalEurNeeded.toFixed(2)),
    remainingEurToBuy: Number(remainingEurToBuy.toFixed(2)),
    estimatedRemainingBrlNeeded: Number(estimatedRemainingBrlNeeded.toFixed(2)),
    requiredMonthlySavingsBrl: Number(requiredMonthlySavingsBrl.toFixed(2)),
    recommendedMonthlyPurchaseBrl: Number(recommendedMonthlyPurchaseBrl.toFixed(2)),
    tranchesCount,
    suggestedTrancheEur: Number(suggestedTrancheEur.toFixed(2)),
    dailyBudgetEur,
    liquidityWarning,
    safetyGuidance,
  };
}
