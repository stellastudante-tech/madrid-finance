import { appCache } from "../cache.ts";
import { getAdminConfig, logTechnicalError } from "../config.ts";

export interface EconomicIndicator {
  id: string;
  label: string;
  value: string;
  referenceDate: string;
  source: string;
  verified: boolean;
}

export interface EconomicIntelligenceResponse {
  updatedAt: string;
  indicators: EconomicIndicator[];
  facts: string[];
  expectations: string[];
  hypotheses: string[];
  methodologyNote: string;
}

async function fetchBcbSgsSeries(seriesId: number): Promise<{ valor: string; data: string } | null> {
  try {
    const res = await fetch(
      `https://api.bcb.gov.br/dados/serie/bcdata.sgs.${seriesId}/dados/ultimos/1?formato=json`,
      { signal: AbortSignal.timeout(5500) }
    );
    if (!res.ok) return null;
    const json = (await res.json()) as Array<{ data: string; valor: string }>;
    return json?.[0] ?? null;
  } catch (err) {
    logTechnicalError(
      `skill02_bcb_sgs_${seriesId}`,
      err instanceof Error ? err.message : "Erro BCB SGS"
    );
    return null;
  }
}

export async function getEconomicIntelligence(): Promise<EconomicIntelligenceResponse> {
  const cacheKey = "economics:overview";
  const cached = appCache.get<EconomicIntelligenceResponse>(cacheKey);
  if (cached && !cached.stale) {
    return cached.value;
  }

  const cfg = getAdminConfig();
  const indicators: EconomicIndicator[] = [];

  if (cfg.sourcesEnabled.bcbIndicators) {
    const [selicMeta, ipcaMensal] = await Promise.all([
      fetchBcbSgsSeries(432), // Meta Selic definida pelo Copom (% a.a.)
      fetchBcbSgsSeries(433), // IPCA variação mensal (%)
    ]);

    if (selicMeta) {
      indicators.push({
        id: "bcb_selic",
        label: "Taxa Selic Meta (BCB / Copom)",
        value: `${Number(selicMeta.valor).toFixed(2)}% a.a.`,
        referenceDate: selicMeta.data,
        source: "Banco Central do Brasil (SGS série 432)",
        verified: true,
      });
    }

    if (ipcaMensal) {
      indicators.push({
        id: "ibge_ipca",
        label: "IPCA Mensal (IBGE)",
        value: `${Number(ipcaMensal.valor).toFixed(2)}% no mês`,
        referenceDate: ipcaMensal.data,
        source: "IBGE via Banco Central do Brasil (SGS série 433)",
        verified: true,
      });
    }
  }

  const response: EconomicIntelligenceResponse = {
    updatedAt: new Date().toISOString(),
    indicators,
    facts: [
      "Diferencial de juros: A relação entre a taxa Selic (Banco Central do Brasil), a taxa básica do Banco Central Europeu (BCE) e a taxa do Federal Reserve (EUA) influencia diretamente o fluxo de capitais entre Brasil e Zona do Euro.",
      "Inflação relativa: Leituras de IPCA (IBGE) e HICP (Eurostat) alteram as expectativas para as próximas decisões de política monetária e o poder de compra real das moedas.",
      "Dinâmica externa e risco global: Indicadores dos EUA (Fed, payroll, inflação) e tensões geopolíticas tendem a fortalecer moedas consideradas reserva de valor, pressionando moedas emergentes como o real.",
    ],
    expectations: [
      "Expectativa de mercado: Comunicados recentes do Copom, do BCE e do Fed costumam ser precificados antecipadamente na taxa de câmbio antes mesmo das reuniões oficiais.",
      "Projeções fiscais e de atividade no Brasil e na Zona do Euro podem gerar volatilidade de curto prazo no par EUR/BRL.",
    ],
    hypotheses: [
      "Cenário de queda do EUR/BRL (hipótese): Manutenção de diferencial de juros favorável ao Brasil combinada com desaceleração inflacionária local e ambiente externo calmo.",
      "Cenário de alta do EUR/BRL (hipótese): Aversão global ao risco (geopolítica ou surpresa inflacionária nos EUA/Europa) ou redução acelerada do diferencial de juros brasileiro.",
    ],
    methodologyNote:
      "Análise estritamente informativa. Fatos verificados baseiam-se em dados públicos do BCB/IBGE; expectativas e hipóteses não constituem previsões garantidas nem recomendação de investimento.",
  };

  appCache.set(cacheKey, response, 60 * 60 * 1000);
  return response;
}
