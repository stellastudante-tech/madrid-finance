import { appCache } from "../cache.ts";
import { getAdminConfig, logTechnicalError, recordFlightCall } from "../config.ts";

export interface FlightSearchRequest {
  origin: string;
  destination: string;
  departureDate: string;
  returnDate?: string;
  flexibleDates?: boolean;
  roundTrip: boolean;
  passengers: number;
  airline?: string;
  directOnly?: boolean;
  baggageIncluded?: boolean;
  maxBudgetBrl?: number;
  paymentMethod?: string;
}

export interface FlightOfferItem {
  id: string;
  airline: string;
  priceTotalBrl: number;
  taxesEstimatedBrl: number | null;
  currency: string;
  stops: number;
  outboundDeparture: string;
  outboundArrival: string;
  inboundDeparture?: string;
  inboundArrival?: string;
  baggageInfo: string;
  fareConditions: string;
  source: string;
}

export interface FlightPortalLink {
  provider: string;
  description: string;
  url: string;
}

export interface FlightSearchResponse {
  mode: "amadeus_live" | "external_links_only";
  amadeusConfigured: boolean;
  offers: FlightOfferItem[];
  externalLinks: FlightPortalLink[];
  searchedAt: string;
  sourceLabel: string;
  quotaRemainingToday: number;
  notice: string;
}

function sanitizeIata(code: string, fallback: string): string {
  const cleaned = code.trim().toUpperCase().replace(/[^A-Z]/g, "");
  return cleaned.length === 3 ? cleaned : fallback;
}

function buildExternalSearchLinks(q: FlightSearchRequest): FlightPortalLink[] {
  const origin = sanitizeIata(q.origin, "GRU");
  const dest = sanitizeIata(q.destination, "MAD");
  const dep = q.departureDate || new Date(Date.now() + 60 * 86400_000).toISOString().slice(0, 10);
  const ret = q.roundTrip && q.returnDate ? q.returnDate : "";
  const pax = Math.max(1, Math.min(9, q.passengers || 1));

  const googleQuery =
    q.roundTrip && ret
      ? `Flights from ${origin} to ${dest} on ${dep} through ${ret}`
      : `One-way flights from ${origin} to ${dest} on ${dep}`;

  const skyDep = dep.replace(/-/g, "").slice(2);
  const skyRet = ret ? `/${ret.replace(/-/g, "").slice(2)}` : "";

  return [
    {
      provider: "Google Flights",
      description: `Pesquisa direta ${origin} → ${dest} (${pax} passageiro${pax > 1 ? "s" : ""})`,
      url: `https://www.google.com/travel/flights?q=${encodeURIComponent(googleQuery)}`,
    },
    {
      provider: "Skyscanner",
      description: q.flexibleDates
        ? "Comparativo com datas flexíveis e filtros de bagagem"
        : "Comparativo multi-companhias com alertas externos",
      url: `https://www.skyscanner.com.br/transporte/passagens-aereas/${origin.toLowerCase()}/${dest.toLowerCase()}/${skyDep}${skyRet}/?adults=${pax}`,
    },
    {
      provider: "Kayak",
      description: "Comparador de tarifas com histórico e filtro de escalas",
      url: `https://www.kayak.com.br/flights/${origin}-${dest}/${dep}${ret ? `/${ret}` : ""}/${pax}adults?sort=bestflight_a`,
    },
    {
      provider: "Iberia (Companhia Oficial)",
      description: "Portal oficial da Iberia para rotas Brasil – Madrid",
      url: "https://www.iberia.com/br/",
    },
    {
      provider: "LATAM Airlines",
      description: "Portal oficial LATAM para voos diretos e conexões para Madrid",
      url: "https://www.latamairlines.com/br/pt",
    },
    {
      provider: "Air Europa",
      description: "Portal oficial Air Europa com rota direta para Madrid (MAD)",
      url: "https://www.aireuropa.com/br/pt/home",
    },
  ];
}

async function getAmadeusAccessToken(
  clientId: string,
  clientSecret: string,
  environment: "test" | "production"
): Promise<string> {
  const tokenCacheKey = `amadeus:token:${environment}:${clientId.slice(0, 6)}`;
  const cached = appCache.get<string>(tokenCacheKey);
  if (cached && !cached.stale) {
    return cached.value;
  }

  const host = environment === "production" ? "https://api.amadeus.com" : "https://test.api.amadeus.com";
  const body = new URLSearchParams({
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
  });

  const res = await fetch(`${host}/v1/security/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
    signal: AbortSignal.timeout(7000),
  });

  if (!res.ok) {
    throw new Error(`Amadeus auth HTTP ${res.status}`);
  }

  const json = (await res.json()) as { access_token: string; expires_in?: number };
  const ttl = Math.max(60, (json.expires_in || 1500) - 60) * 1000;
  appCache.set(tokenCacheKey, json.access_token, ttl);
  return json.access_token;
}

export async function searchFlights(query: FlightSearchRequest): Promise<FlightSearchResponse> {
  const cfg = getAdminConfig();
  const origin = sanitizeIata(query.origin, "GRU");
  const destination = sanitizeIata(query.destination, "MAD");
  const externalLinks = buildExternalSearchLinks({ ...query, origin, destination });

  const hasAmadeus = Boolean(
    cfg.sourcesEnabled.amadeus && cfg.amadeus.clientId && cfg.amadeus.clientSecret
  );

  if (!hasAmadeus) {
    return {
      mode: "external_links_only",
      amadeusConfigured: false,
      offers: [],
      externalLinks,
      searchedAt: new Date().toISOString(),
      sourceLabel: "Links diretos para portais autorizados (sem API Amadeus ativa)",
      quotaRemainingToday: Math.max(0, cfg.limits.flightRequestsPerDayGlobal),
      notice:
        "Nenhuma credencial Amadeus está configurada pela administração no momento. Para evitar preços inventados ou desatualizados, utilize os links oficiais abaixo para consultar tarifas reais e registrá-las no seu monitoramento.",
    };
  }

  const cacheKey = `flights:${origin}:${destination}:${query.departureDate}:${query.returnDate || ""}:${query.passengers}:${query.directOnly ? 1 : 0}`;
  const cached = appCache.get<FlightSearchResponse>(cacheKey);
  if (cached && !cached.stale) {
    return cached.value;
  }

  const quota = recordFlightCall();
  if (!quota.allowed) {
    return {
      mode: "external_links_only",
      amadeusConfigured: true,
      offers: [],
      externalLinks,
      searchedAt: new Date().toISOString(),
      sourceLabel: "Quota diária de API de voos atingida",
      quotaRemainingToday: 0,
      notice:
        "A quota gratuita diária de consultas na API de voos foi atingida. Utilize os links oficiais abaixo para consultar preços sem custos.",
    };
  }

  try {
    const token = await getAmadeusAccessToken(
      cfg.amadeus.clientId,
      cfg.amadeus.clientSecret,
      cfg.amadeus.environment
    );
    const host =
      cfg.amadeus.environment === "production"
        ? "https://api.amadeus.com"
        : "https://test.api.amadeus.com";

    const params = new URLSearchParams({
      originLocationCode: origin,
      destinationLocationCode: destination,
      departureDate: query.departureDate,
      adults: String(Math.max(1, Math.min(9, query.passengers || 1))),
      currencyCode: "BRL",
      max: "8",
    });

    if (query.roundTrip && query.returnDate) {
      params.set("returnDate", query.returnDate);
    }
    if (query.directOnly) {
      params.set("nonStop", "true");
    }
    if (query.maxBudgetBrl && query.maxBudgetBrl > 0) {
      params.set("maxPrice", String(Math.round(query.maxBudgetBrl)));
    }

    const res = await fetch(`${host}/v2/shopping/flight-offers?${params.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(9000),
    });

    if (!res.ok) {
      throw new Error(`Amadeus search HTTP ${res.status}`);
    }

    const data = (await res.json()) as {
      data?: Array<{
        id: string;
        validatingAirlineCodes?: string[];
        price?: { total?: string; base?: string; currency?: string };
        itineraries?: Array<{
          segments?: Array<{
            carrierCode?: string;
            departure?: { iataCode?: string; at?: string };
            arrival?: { iataCode?: string; at?: string };
          }>;
        }>;
        travelerPricings?: Array<{
          fareDetailsBySegment?: Array<{
            includedCheckedBags?: { quantity?: number };
            cabin?: string;
          }>;
        }>;
      }>;
    };

    const offers: FlightOfferItem[] = (data.data || []).map((offer) => {
      const outSegs = offer.itineraries?.[0]?.segments || [];
      const inSegs = offer.itineraries?.[1]?.segments || [];
      const total = Number(offer.price?.total || 0);
      const base = Number(offer.price?.base || 0);
      const taxes = total > 0 && base > 0 ? Number((total - base).toFixed(2)) : null;
      const airline = offer.validatingAirlineCodes?.[0] || outSegs[0]?.carrierCode || "Cia Aérea";
      const bagsQty =
        offer.travelerPricings?.[0]?.fareDetailsBySegment?.[0]?.includedCheckedBags?.quantity ?? 0;
      const cabin =
        offer.travelerPricings?.[0]?.fareDetailsBySegment?.[0]?.cabin || "ECONOMY";

      return {
        id: offer.id,
        airline,
        priceTotalBrl: total,
        taxesEstimatedBrl: taxes,
        currency: offer.price?.currency || "BRL",
        stops: Math.max(0, outSegs.length - 1),
        outboundDeparture: outSegs[0]?.departure?.at || query.departureDate,
        outboundArrival: outSegs[outSegs.length - 1]?.arrival?.at || "",
        inboundDeparture: inSegs[0]?.departure?.at,
        inboundArrival: inSegs[inSegs.length - 1]?.arrival?.at,
        baggageInfo: bagsQty > 0 ? `${bagsQty} bagagem(ns) despachada(s)` : "Consulte bagagem na tarifa",
        fareConditions: `Cabine ${cabin}. Confirme regras de remarcação e reembolso na emissão.`,
        source: `Amadeus API (${cfg.amadeus.environment})`,
      };
    });

    const result: FlightSearchResponse = {
      mode: "amadeus_live",
      amadeusConfigured: true,
      offers,
      externalLinks,
      searchedAt: new Date().toISOString(),
      sourceLabel: `Amadeus Flight Offers API (${cfg.amadeus.environment})`,
      quotaRemainingToday: quota.remainingToday,
      notice:
        offers.length > 0
          ? "Tarifas consultadas via Amadeus API. Confirme disponibilidade final e regras de bagagem no site da companhia antes da compra."
          : "Nenhuma oferta retornada para os filtros informados na API Amadeus. Utilize os links oficiais abaixo para ampliar a busca.",
    };

    appCache.set(cacheKey, result, Math.max(5, cfg.limits.flightCacheTtlMinutes) * 60 * 1000);
    return result;
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro Amadeus";
    logTechnicalError("skill08_amadeus", msg);
    return {
      mode: "external_links_only",
      amadeusConfigured: true,
      offers: [],
      externalLinks,
      searchedAt: new Date().toISOString(),
      sourceLabel: "Fallback seguro para links oficiais",
      quotaRemainingToday: quota.remainingToday,
      notice:
        "A consulta em tempo real à API Amadeus falhou ou expirou no momento. Para garantir dados confiáveis sem inventar tarifas, utilize os links diretos abaixo.",
    };
  }
}
