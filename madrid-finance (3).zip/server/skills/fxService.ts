import { appCache } from "../cache.ts";
import { getAdminConfig, logTechnicalError, recordFxCall } from "../config.ts";

export interface FxPoint {
  date: string;
  rate: number;
}

export interface FxOverview {
  available: boolean;
  base: string;
  target: string;
  latestRate: number | null;
  previousRate: number | null;
  absoluteChange: number | null;
  percentChange: number | null;
  observationDate: string | null;
  fetchedAt: string;
  stale: boolean;
  source: string;
  bcbPtax: {
    available: boolean;
    buyRate: number | null;
    sellRate: number | null;
    timestamp: string | null;
    source: string;
  };
  stats: {
    avg7d: number | null;
    avg30d: number | null;
    avg90d: number | null;
    min7d: number | null;
    max7d: number | null;
    min30d: number | null;
    max30d: number | null;
    min90d: number | null;
    max90d: number | null;
    best30dDate: string | null;
    worst30dDate: string | null;
  };
  history90d: FxPoint[];
  disclaimer: string;
  errorMessage?: string;
}

export type OpportunityClassification =
  | "Excelente oportunidade"
  | "Boa oportunidade"
  | "Oportunidade neutra"
  | "Momento desfavorável";

export interface OpportunityAnalysis {
  available: boolean;
  classification: OpportunityClassification | "Dados indisponíveis";
  summary: string;
  reasons: string[];
  metrics: {
    currentRate: number | null;
    avg7d: number | null;
    avg30d: number | null;
    avg90d: number | null;
    min90d: number | null;
    max90d: number | null;
    dailyChangePct: number | null;
    targetRate: number | null;
    distanceToTargetPct: number | null;
  };
  source: string;
  observationDate: string | null;
}

const SUPPORTED_CURRENCIES = new Set(["EUR", "BRL", "USD", "GBP", "CHF", "CAD"]);

function formatDateYMD(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function formatDateMDY(d: Date): string {
  const mm = String(d.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(d.getUTCDate()).padStart(2, "0");
  const yyyy = d.getUTCFullYear();
  return `${mm}-${dd}-${yyyy}`;
}

function mean(values: number[]): number | null {
  if (!values.length) return null;
  return values.reduce((acc, v) => acc + v, 0) / values.length;
}

async function fetchBcbPtax(currency: string): Promise<FxOverview["bcbPtax"]> {
  const cfg = getAdminConfig();
  if (!cfg.sourcesEnabled.bcbPtax || !["EUR", "USD", "GBP", "CHF", "CAD"].includes(currency)) {
    return {
      available: false,
      buyRate: null,
      sellRate: null,
      timestamp: null,
      source: "Banco Central do Brasil (PTAX)",
    };
  }

  try {
    const end = new Date();
    const start = new Date(end.getTime() - 10 * 86400_000);
    const url =
      `https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/` +
      `CotacaoMoedaPeriodo(moeda=@moeda,dataInicial=@dataInicial,dataFinalCotacao=@dataFinalCotacao)` +
      `?@moeda='${currency}'&@dataInicial='${formatDateMDY(start)}'&@dataFinalCotacao='${formatDateMDY(end)}'&$top=5&$orderby=dataHoraCotacao%20desc&$format=json`;

    const res = await fetch(url, { signal: AbortSignal.timeout(6500) });
    if (!res.ok) throw new Error(`BCB PTAX HTTP ${res.status}`);
    const data = (await res.json()) as {
      value?: Array<{ cotacaoCompra: number; cotacaoVenda: number; dataHoraCotacao: string }>;
    };
    const latest = data.value?.[0];
    if (!latest) {
      return {
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)",
      };
    }
    return {
      available: true,
      buyRate: latest.cotacaoCompra,
      sellRate: latest.cotacaoVenda,
      timestamp: latest.dataHoraCotacao,
      source: "Banco Central do Brasil (PTAX Oficial)",
    };
  } catch (err) {
    logTechnicalError("skill01_bcb_ptax", err instanceof Error ? err.message : "Erro BCB PTAX");
    return {
      available: false,
      buyRate: null,
      sellRate: null,
      timestamp: null,
      source: "Banco Central do Brasil (PTAX)",
    };
  }
}

export async function getFxOverview(rawBase = "EUR", rawTarget = "BRL"): Promise<FxOverview> {
  const base = SUPPORTED_CURRENCIES.has(rawBase.toUpperCase()) ? rawBase.toUpperCase() : "EUR";
  const target = SUPPORTED_CURRENCIES.has(rawTarget.toUpperCase()) ? rawTarget.toUpperCase() : "BRL";
  const cfg = getAdminConfig();
  const cacheKey = `fx:${base}:${target}`;
  const ttlMs = Math.max(1, cfg.limits.fxCacheTtlMinutes) * 60 * 1000;

  const cached = appCache.get<FxOverview>(cacheKey);
  if (cached && !cached.stale) {
    recordFxCall(true);
    return cached.value;
  }

  recordFxCall(false);

  if (!cfg.sourcesEnabled.frankfurter) {
    return {
      available: false,
      base,
      target,
      latestRate: null,
      previousRate: null,
      absoluteChange: null,
      percentChange: null,
      observationDate: null,
      fetchedAt: new Date().toISOString(),
      stale: false,
      source: "Frankfurter / Banco Central Europeu",
      bcbPtax: {
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)",
      },
      stats: {
        avg7d: null,
        avg30d: null,
        avg90d: null,
        min7d: null,
        max7d: null,
        min30d: null,
        max30d: null,
        min90d: null,
        max90d: null,
        best30dDate: null,
        worst30dDate: null,
      },
      history90d: [],
      disclaimer:
        "Cotação de referência interbancária (Frankfurter/BCE). Não representa o custo final de compra de moeda pela Wise.",
      errorMessage: "Fonte Frankfurter temporariamente desativada pela administração.",
    };
  }

  try {
    const end = new Date();
    const start = new Date(end.getTime() - 95 * 86400_000);
    const startStr = formatDateYMD(start);
    const endStr = formatDateYMD(end);

    const [latestRes, historyRes, bcbPtax] = await Promise.all([
      fetch(`https://api.frankfurter.dev/v1/latest?base=${base}&symbols=${target}`, {
        signal: AbortSignal.timeout(7000),
      }),
      fetch(`https://api.frankfurter.dev/v1/${startStr}..${endStr}?base=${base}&symbols=${target}`, {
        signal: AbortSignal.timeout(8000),
      }),
      target === "BRL"
        ? fetchBcbPtax(base)
        : Promise.resolve({
            available: false,
            buyRate: null,
            sellRate: null,
            timestamp: null,
            source: "Banco Central do Brasil (PTAX)",
          }),
    ]);

    if (!latestRes.ok || !historyRes.ok) {
      throw new Error(`Frankfurter HTTP ${latestRes.status}/${historyRes.status}`);
    }

    const latestJson = (await latestRes.json()) as {
      date: string;
      rates: Record<string, number>;
    };
    const historyJson = (await historyRes.json()) as {
      rates: Record<string, Record<string, number>>;
    };

    const pointsMap = new Map<string, number>();
    for (const [date, obj] of Object.entries(historyJson.rates || {})) {
      if (typeof obj?.[target] === "number") {
        pointsMap.set(date, obj[target]);
      }
    }
    if (typeof latestJson.rates?.[target] === "number") {
      pointsMap.set(latestJson.date, latestJson.rates[target]);
    }

    const history90d: FxPoint[] = Array.from(pointsMap.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, rate]) => ({ date, rate }));

    if (history90d.length === 0) {
      throw new Error("Nenhuma observação cambial retornada pela API Frankfurter.");
    }

    const latestPoint = history90d[history90d.length - 1];
    const prevPoint = history90d.length > 1 ? history90d[history90d.length - 2] : null;
    const latestRate = latestPoint.rate;
    const previousRate = prevPoint ? prevPoint.rate : null;
    const absoluteChange = previousRate !== null ? latestRate - previousRate : null;
    const percentChange =
      previousRate !== null && previousRate !== 0 ? ((latestRate - previousRate) / previousRate) * 100 : null;

    const cutoff7 = formatDateYMD(new Date(end.getTime() - 7 * 86400_000));
    const cutoff30 = formatDateYMD(new Date(end.getTime() - 30 * 86400_000));

    const pts7 = history90d.filter((p) => p.date >= cutoff7);
    const pts30 = history90d.filter((p) => p.date >= cutoff30);
    const pts90 = history90d;

    const r7 = pts7.map((p) => p.rate);
    const r30 = pts30.map((p) => p.rate);
    const r90 = pts90.map((p) => p.rate);

    const best30 = pts30.reduce<FxPoint | null>((best, p) => (!best || p.rate < best.rate ? p : best), null);
    const worst30 = pts30.reduce<FxPoint | null>((worst, p) => (!worst || p.rate > worst.rate ? p : worst), null);

    const overview: FxOverview = {
      available: true,
      base,
      target,
      latestRate,
      previousRate,
      absoluteChange,
      percentChange,
      observationDate: latestPoint.date,
      fetchedAt: new Date().toISOString(),
      stale: false,
      source: "Frankfurter API (referência oficial Banco Central Europeu)",
      bcbPtax,
      stats: {
        avg7d: mean(r7),
        avg30d: mean(r30),
        avg90d: mean(r90),
        min7d: r7.length ? Math.min(...r7) : null,
        max7d: r7.length ? Math.max(...r7) : null,
        min30d: r30.length ? Math.min(...r30) : null,
        max30d: r30.length ? Math.max(...r30) : null,
        min90d: r90.length ? Math.min(...r90) : null,
        max90d: r90.length ? Math.max(...r90) : null,
        best30dDate: best30?.date ?? null,
        worst30dDate: worst30?.date ?? null,
      },
      history90d,
      disclaimer:
        "Cotação de referência interbancária (Frankfurter/BCE). Não representa o custo final de compra de moeda pela Wise, que inclui taxa de serviço e IOF.",
    };

    appCache.set(cacheKey, overview, ttlMs);
    return overview;
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Erro ao consultar Frankfurter";
    logTechnicalError("skill01_fx", msg);

    if (cached) {
      return {
        ...cached.value,
        stale: true,
        errorMessage: `API cambial momentaneamente indisponível (${msg}). Exibindo último registro em cache de ${cached.cachedAt}.`,
      };
    }

    return {
      available: false,
      base,
      target,
      latestRate: null,
      previousRate: null,
      absoluteChange: null,
      percentChange: null,
      observationDate: null,
      fetchedAt: new Date().toISOString(),
      stale: false,
      source: "Frankfurter / Banco Central Europeu",
      bcbPtax: {
        available: false,
        buyRate: null,
        sellRate: null,
        timestamp: null,
        source: "Banco Central do Brasil (PTAX)",
      },
      stats: {
        avg7d: null,
        avg30d: null,
        avg90d: null,
        min7d: null,
        max7d: null,
        min30d: null,
        max30d: null,
        min90d: null,
        max90d: null,
        best30dDate: null,
        worst30dDate: null,
      },
      history90d: [],
      disclaimer:
        "Cotação de referência interbancária (Frankfurter/BCE). Não representa o custo final de compra de moeda pela Wise.",
      errorMessage: "Não foi possível obter a cotação atualizada no momento. Tente novamente em instantes.",
    };
  }
}

export function analyzeOpportunity(fx: FxOverview, targetRate: number | null): OpportunityAnalysis {
  if (!fx.available || fx.latestRate === null) {
    return {
      available: false,
      classification: "Dados indisponíveis",
      summary: "Sem dados cambiais recentes para calcular o radar de oportunidades.",
      reasons: [],
      metrics: {
        currentRate: null,
        avg7d: null,
        avg30d: null,
        avg90d: null,
        min90d: null,
        max90d: null,
        dailyChangePct: null,
        targetRate,
        distanceToTargetPct: null,
      },
      source: fx.source,
      observationDate: fx.observationDate,
    };
  }

  const current = fx.latestRate;
  const { avg7d, avg30d, avg90d, min90d, max90d } = fx.stats;
  const reasons: string[] = [];
  let score = 0;

  if (avg7d !== null) {
    const diff7 = ((current - avg7d) / avg7d) * 100;
    if (diff7 <= -1.0) {
      score += 2;
      reasons.push(`Está ${Math.abs(diff7).toFixed(2)}% abaixo da média de 7 dias (${avg7d.toFixed(4)}).`);
    } else if (diff7 < 0) {
      score += 1;
      reasons.push(`Está ${Math.abs(diff7).toFixed(2)}% abaixo da média de 7 dias (${avg7d.toFixed(4)}).`);
    } else if (diff7 > 1.0) {
      score -= 1;
      reasons.push(`Está ${diff7.toFixed(2)}% acima da média de 7 dias (${avg7d.toFixed(4)}).`);
    } else {
      reasons.push(`Oscilação próxima à média de 7 dias (${avg7d.toFixed(4)}).`);
    }
  }

  if (avg30d !== null) {
    const diff30 = ((current - avg30d) / avg30d) * 100;
    if (diff30 <= -1.5) {
      score += 2;
      reasons.push(`Está ${Math.abs(diff30).toFixed(2)}% abaixo da média de 30 dias (${avg30d.toFixed(4)}).`);
    } else if (diff30 < 0) {
      score += 1;
      reasons.push(`Está ${Math.abs(diff30).toFixed(2)}% abaixo da média de 30 dias (${avg30d.toFixed(4)}).`);
    } else if (diff30 >= 1.5) {
      score -= 2;
      reasons.push(`Está ${diff30.toFixed(2)}% acima da média de 30 dias (${avg30d.toFixed(4)}).`);
    } else {
      reasons.push(`Próxima à média de 30 dias (${avg30d.toFixed(4)}).`);
    }
  }

  if (avg90d !== null) {
    const diff90 = ((current - avg90d) / avg90d) * 100;
    if (diff90 <= -2.0) {
      score += 2;
      reasons.push(`Está ${Math.abs(diff90).toFixed(2)}% abaixo da média de 90 dias (${avg90d.toFixed(4)}).`);
    } else if (diff90 > 2.0) {
      score -= 1;
      reasons.push(`Está ${diff90.toFixed(2)}% acima da média de 90 dias (${avg90d.toFixed(4)}).`);
    }
  }

  if (min90d !== null && max90d !== null && max90d > min90d) {
    const pos = (current - min90d) / (max90d - min90d);
    if (pos <= 0.25) {
      score += 1;
      reasons.push(
        `No quartil mais favorável dos últimos 90 dias (mínima de ${min90d.toFixed(4)} e máxima de ${max90d.toFixed(4)}).`
      );
    } else if (pos >= 0.8) {
      score -= 1;
      reasons.push(
        `Próxima da máxima dos últimos 90 dias (mínima de ${min90d.toFixed(4)} e máxima de ${max90d.toFixed(4)}).`
      );
    }
  }

  let distanceToTargetPct: number | null = null;
  if (targetRate !== null && targetRate > 0) {
    distanceToTargetPct = ((current - targetRate) / targetRate) * 100;
    if (current <= targetRate) {
      score += 2;
      reasons.push(
        `Atingiu ou superou sua meta configurada (${targetRate.toFixed(4)}): está ${Math.abs(distanceToTargetPct).toFixed(2)}% abaixo do alvo.`
      );
    } else if (distanceToTargetPct <= 1.2) {
      reasons.push(
        `Faltam ${distanceToTargetPct.toFixed(2)}% para alcançar sua meta configurada (${targetRate.toFixed(4)}).`
      );
    } else {
      score -= 1;
      reasons.push(
        `Está ${distanceToTargetPct.toFixed(2)}% acima da sua meta configurada (${targetRate.toFixed(4)}).`
      );
    }
  }

  let classification: OpportunityClassification;
  let summary: string;

  if (score >= 4) {
    classification = "Excelente oportunidade";
    summary =
      "A cotação atual está significativamente favorável em relação às médias recentes e/ou abaixo da sua meta.";
  } else if (score >= 2) {
    classification = "Boa oportunidade";
    summary = "A taxa atual está abaixo das médias de curto/médio prazo, favorecendo compras parciais.";
  } else if (score >= 0) {
    classification = "Oportunidade neutra";
    summary =
      "Cotação em linha com o comportamento recente. Estratégia recomendada: manter compras graduais (preço médio).";
  } else {
    classification = "Momento desfavorável";
    summary =
      "A cotação está pressionada acima das médias recentes. Avalie aguardar recuos ou fracionar apenas o essencial.";
  }

  return {
    available: true,
    classification,
    summary,
    reasons,
    metrics: {
      currentRate: current,
      avg7d,
      avg30d,
      avg90d,
      min90d,
      max90d,
      dailyChangePct: fx.percentChange,
      targetRate,
      distanceToTargetPct,
    },
    source: fx.source,
    observationDate: fx.observationDate,
  };
}
