import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export type SkillId =
  | "skill01_fx"
  | "skill02_economics"
  | "skill03_radar"
  | "skill04_wise"
  | "skill05_strategy"
  | "skill06_alerts"
  | "skill07_reports"
  | "skill08_flights";

export interface AdminConfig {
  skillsEnabled: Record<SkillId, boolean>;
  sourcesEnabled: {
    frankfurter: boolean;
    bcbPtax: boolean;
    bcbIndicators: boolean;
    amadeus: boolean;
  };
  limits: {
    aiRequestsPerHourPerVisitor: number;
    aiRequestsPerDayGlobal: number;
    maxConversationMessages: number;
    maxMessageChars: number;
    fxRequestsPerHourPerVisitor: number;
    flightRequestsPerDayGlobal: number;
    fxCacheTtlMinutes: number;
    flightCacheTtlMinutes: number;
  };
  agentInstructions: string;
  amadeus: {
    clientId: string;
    clientSecret: string;
    environment: "test" | "production";
  };
}

export interface TechnicalErrorEntry {
  id: string;
  timestamp: string;
  scope: string;
  message: string;
}

export interface UsageMetrics {
  aiCallsTotal: number;
  aiCallsToday: number;
  aiQuotaDate: string;
  fxCallsTotal: number;
  fxCacheHits: number;
  flightCallsTotal: number;
  flightCallsToday: number;
  flightQuotaDate: string;
  rateLimitRejections: number;
}

const DATA_DIR = path.resolve(process.cwd(), ".data");
const CONFIG_FILE = path.join(DATA_DIR, "admin-config.json");

const todayKey = () => new Date().toISOString().slice(0, 10);

const defaultConfig: AdminConfig = {
  skillsEnabled: {
    skill01_fx: true,
    skill02_economics: true,
    skill03_radar: true,
    skill04_wise: true,
    skill05_strategy: true,
    skill06_alerts: true,
    skill07_reports: true,
    skill08_flights: true,
  },
  sourcesEnabled: {
    frankfurter: true,
    bcbPtax: true,
    bcbIndicators: true,
    amadeus: true,
  },
  limits: {
    aiRequestsPerHourPerVisitor: 18,
    aiRequestsPerDayGlobal: 250,
    maxConversationMessages: 16,
    maxMessageChars: 800,
    fxRequestsPerHourPerVisitor: 120,
    flightRequestsPerDayGlobal: 40,
    fxCacheTtlMinutes: 15,
    flightCacheTtlMinutes: 30,
  },
  agentInstructions:
    "Priorize transparência, clareza e rigor numérico em português do Brasil. Sempre informe a fonte e a data de atualização dos dados. Nunca invente cotações ou preços de passagens.",
  amadeus: {
    clientId: process.env.AMADEUS_CLIENT_ID || "",
    clientSecret: process.env.AMADEUS_CLIENT_SECRET || "",
    environment: "test",
  },
};

let currentConfig: AdminConfig = loadConfigFromDisk();

function loadConfigFromDisk(): AdminConfig {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const raw = fs.readFileSync(CONFIG_FILE, "utf-8");
      const parsed = JSON.parse(raw) as Partial<AdminConfig>;
      return {
        skillsEnabled: { ...defaultConfig.skillsEnabled, ...(parsed.skillsEnabled || {}) },
        sourcesEnabled: { ...defaultConfig.sourcesEnabled, ...(parsed.sourcesEnabled || {}) },
        limits: { ...defaultConfig.limits, ...(parsed.limits || {}) },
        agentInstructions: parsed.agentInstructions || defaultConfig.agentInstructions,
        amadeus: {
          clientId: parsed.amadeus?.clientId || process.env.AMADEUS_CLIENT_ID || "",
          clientSecret: parsed.amadeus?.clientSecret || process.env.AMADEUS_CLIENT_SECRET || "",
          environment: parsed.amadeus?.environment === "production" ? "production" : "test",
        },
      };
    }
  } catch {
    // Ignore read errors and fall back to defaults
  }
  return structuredClone(defaultConfig);
}

function saveConfigToDisk(cfg: AdminConfig): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), "utf-8");
  } catch {
    // Non-fatal in read-only environments
  }
}

export function getAdminConfig(): AdminConfig {
  return currentConfig;
}

export function updateAdminConfig(patch: Partial<AdminConfig>): AdminConfig {
  currentConfig = {
    ...currentConfig,
    skillsEnabled: {
      ...currentConfig.skillsEnabled,
      ...(patch.skillsEnabled || {}),
    },
    sourcesEnabled: {
      ...currentConfig.sourcesEnabled,
      ...(patch.sourcesEnabled || {}),
    },
    limits: {
      ...currentConfig.limits,
      ...(patch.limits || {}),
    },
    agentInstructions:
      typeof patch.agentInstructions === "string"
        ? patch.agentInstructions.slice(0, 2000)
        : currentConfig.agentInstructions,
    amadeus: {
      clientId:
        typeof patch.amadeus?.clientId === "string" && !patch.amadeus.clientId.includes("••••")
          ? patch.amadeus.clientId.trim()
          : currentConfig.amadeus.clientId,
      clientSecret:
        typeof patch.amadeus?.clientSecret === "string" && !patch.amadeus.clientSecret.includes("••••")
          ? patch.amadeus.clientSecret.trim()
          : currentConfig.amadeus.clientSecret,
      environment:
        patch.amadeus?.environment === "production" || patch.amadeus?.environment === "test"
          ? patch.amadeus.environment
          : currentConfig.amadeus.environment,
    },
  };
  saveConfigToDisk(currentConfig);
  return currentConfig;
}

export function getPublicConfigSummary() {
  return {
    skillsEnabled: currentConfig.skillsEnabled,
    limits: {
      aiRequestsPerHourPerVisitor: currentConfig.limits.aiRequestsPerHourPerVisitor,
      maxConversationMessages: currentConfig.limits.maxConversationMessages,
      maxMessageChars: currentConfig.limits.maxMessageChars,
    },
    amadeusConfigured: Boolean(
      currentConfig.sourcesEnabled.amadeus &&
        currentConfig.amadeus.clientId &&
        currentConfig.amadeus.clientSecret
    ),
  };
}

export function maskSecret(value: string): string {
  if (!value) return "";
  if (value.length <= 6) return "••••••";
  return `${value.slice(0, 3)}••••${value.slice(-3)}`;
}

// Usage & technical error telemetry (no financial data or PII ever logged)
const usage: UsageMetrics = {
  aiCallsTotal: 0,
  aiCallsToday: 0,
  aiQuotaDate: todayKey(),
  fxCallsTotal: 0,
  fxCacheHits: 0,
  flightCallsTotal: 0,
  flightCallsToday: 0,
  flightQuotaDate: todayKey(),
  rateLimitRejections: 0,
};

const errorLog: TechnicalErrorEntry[] = [];

function syncDateCounters() {
  const today = todayKey();
  if (usage.aiQuotaDate !== today) {
    usage.aiQuotaDate = today;
    usage.aiCallsToday = 0;
  }
  if (usage.flightQuotaDate !== today) {
    usage.flightQuotaDate = today;
    usage.flightCallsToday = 0;
  }
}

export function recordAiCall(): { allowed: boolean; remainingToday: number } {
  syncDateCounters();
  if (usage.aiCallsToday >= currentConfig.limits.aiRequestsPerDayGlobal) {
    return { allowed: false, remainingToday: 0 };
  }
  usage.aiCallsTotal += 1;
  usage.aiCallsToday += 1;
  return {
    allowed: true,
    remainingToday: Math.max(0, currentConfig.limits.aiRequestsPerDayGlobal - usage.aiCallsToday),
  };
}

export function recordFxCall(cacheHit: boolean) {
  usage.fxCallsTotal += 1;
  if (cacheHit) usage.fxCacheHits += 1;
}

export function recordFlightCall(): { allowed: boolean; remainingToday: number } {
  syncDateCounters();
  if (usage.flightCallsToday >= currentConfig.limits.flightRequestsPerDayGlobal) {
    return { allowed: false, remainingToday: 0 };
  }
  usage.flightCallsTotal += 1;
  usage.flightCallsToday += 1;
  return {
    allowed: true,
    remainingToday: Math.max(0, currentConfig.limits.flightRequestsPerDayGlobal - usage.flightCallsToday),
  };
}

export function recordRateLimitRejection() {
  usage.rateLimitRejections += 1;
}

export function logTechnicalError(scope: string, message: string) {
  errorLog.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    scope,
    message: message.slice(0, 300),
  });
  if (errorLog.length > 50) {
    errorLog.length = 50;
  }
}

export function getAdminMetricsAndLogs() {
  syncDateCounters();
  return {
    usage: { ...usage },
    errors: [...errorLog],
  };
}

// Admin session tokens (server-only)
const adminSessions = new Map<string, number>();
const ADMIN_SESSION_TTL_MS = 4 * 60 * 60 * 1000;

export function getExpectedAdminPasscode(): string {
  return process.env.ADMIN_PASSCODE?.trim() || "madrid-admin-2026";
}

export function createAdminSession(passcode: string): string | null {
  const expected = getExpectedAdminPasscode();
  const a = Buffer.from(passcode.trim());
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }
  const token = crypto.randomBytes(32).toString("hex");
  adminSessions.set(token, Date.now() + ADMIN_SESSION_TTL_MS);
  return token;
}

export function verifyAdminToken(authHeader?: string): boolean {
  if (!authHeader || !authHeader.startsWith("Bearer ")) return false;
  const token = authHeader.slice(7).trim();
  const expiresAt = adminSessions.get(token);
  if (!expiresAt) return false;
  if (Date.now() > expiresAt) {
    adminSessions.delete(token);
    return false;
  }
  return true;
}
