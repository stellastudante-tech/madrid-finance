interface CacheItem<T> {
  value: T;
  expiresAt: number;
  cachedAt: string;
}

class MemoryCache {
  private store = new Map<string, CacheItem<unknown>>();

  get<T>(key: string): { value: T; cachedAt: string; stale: boolean } | null {
    const entry = this.store.get(key) as CacheItem<T> | undefined;
    if (!entry) return null;
    const isExpired = Date.now() > entry.expiresAt;
    return {
      value: entry.value,
      cachedAt: entry.cachedAt,
      stale: isExpired,
    };
  }

  set<T>(key: string, value: T, ttlMs: number): void {
    this.store.set(key, {
      value,
      expiresAt: Date.now() + ttlMs,
      cachedAt: new Date().toISOString(),
    });
  }

  clearAll(): void {
    this.store.clear();
  }
}

export const appCache = new MemoryCache();
