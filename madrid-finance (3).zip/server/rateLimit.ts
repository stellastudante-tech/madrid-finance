import type { Request } from "express";
import { recordRateLimitRejection } from "./config.ts";

interface Bucket {
  timestamps: number[];
}

const buckets = new Map<string, Bucket>();
const HOUR_MS = 60 * 60 * 1000;

export function getVisitorKey(req: Request): string {
  const visitorHeader = req.header("x-visitor-id")?.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 48);
  const ip = req.ip || req.socket.remoteAddress || "anon";
  return visitorHeader ? `${ip}:${visitorHeader}` : ip;
}

export function checkVisitorRateLimit(
  visitorKey: string,
  bucketType: "ai" | "fx",
  maxPerHour: number
): { allowed: boolean; remaining: number; retryAfterSeconds: number } {
  const key = `${bucketType}:${visitorKey}`;
  const now = Date.now();
  const windowStart = now - HOUR_MS;

  const bucket = buckets.get(key) || { timestamps: [] };
  bucket.timestamps = bucket.timestamps.filter((t) => t > windowStart);

  if (bucket.timestamps.length >= maxPerHour) {
    recordRateLimitRejection();
    const oldest = bucket.timestamps[0] ?? now;
    const retryAfterSeconds = Math.max(1, Math.ceil((oldest + HOUR_MS - now) / 1000));
    buckets.set(key, bucket);
    return { allowed: false, remaining: 0, retryAfterSeconds };
  }

  bucket.timestamps.push(now);
  buckets.set(key, bucket);
  return {
    allowed: true,
    remaining: Math.max(0, maxPerHour - bucket.timestamps.length),
    retryAfterSeconds: 0,
  };
}
