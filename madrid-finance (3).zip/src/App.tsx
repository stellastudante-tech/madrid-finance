import { useCallback, useEffect, useMemo, useState } from "react";
import { Menu, X } from "lucide-react";
import { AdminSection } from "./components/AdminSection";
import { AssistantSection } from "./components/AssistantSection";
import { FlightsSection } from "./components/FlightsSection";
import { FxDashboardSection } from "./components/FxDashboardSection";
import { OverviewSection } from "./components/OverviewSection";
import { PlanningAlertsSection } from "./components/PlanningAlertsSection";
import { ReportsSection } from "./components/ReportsSection";
import { SettingsPrivacySection } from "./components/SettingsPrivacySection";
import { WiseCalculatorSection } from "./components/WiseCalculatorSection";
import type {
  ChatMessage,
  EconomicIntelligenceResponse,
  FlightAlertRule,
  FxAlertRule,
  FxOverview,
  ManualFlightQuote,
  NavSection,
  OpportunityAnalysis,
  PublicConfigSummary,
  PurchaseEntry,
  UserProfile,
} from "./types/madrid";
import { evaluateFxAlerts } from "./utils/calculations";
import {
  clearAllLocalData,
  getOrCreateVisitorId,
  loadAiConsent,
  loadChatHistory,
  loadFlightAlerts,
  loadFxAlerts,
  loadManualFlights,
  loadProfile,
  loadPurchases,
  saveAiConsent,
  saveChatHistory,
  saveFlightAlerts,
  saveFxAlerts,
  saveManualFlights,
  saveProfile,
  savePurchases,
} from "./utils/storage";

const NAV_ITEMS: Array<{ id: NavSection; label: string }> = [
  { id: "overview", label: "Visão Geral" },
  { id: "fx", label: "Câmbio" },
  { id: "wise", label: "Calculadora" },
  { id: "planning", label: "Planejamento" },
  { id: "flights", label: "Passagens" },
  { id: "reports", label: "Relatórios" },
];

export default function App() {
  const [section, setSection] = useState<NavSection>("overview");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Isolated per-browser LocalStorage state
  const [profile, setProfile] = useState<UserProfile>(() => loadProfile());
  const [purchases, setPurchases] = useState<PurchaseEntry[]>(() => loadPurchases());
  const [fxAlerts, setFxAlerts] = useState<FxAlertRule[]>(() => loadFxAlerts());
  const [flightAlerts, setFlightAlerts] = useState<FlightAlertRule[]>(() => loadFlightAlerts());
  const [manualFlights, setManualFlights] = useState<ManualFlightQuote[]>(() => loadManualFlights());
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => loadChatHistory());
  const [aiConsent, setAiConsent] = useState<boolean>(() => loadAiConsent());

  // Server data states
  const [fx, setFx] = useState<FxOverview | null>(null);
  const [fxLoading, setFxLoading] = useState<boolean>(true);
  const [radar, setRadar] = useState<OpportunityAnalysis | null>(null);
  const [economics, setEconomics] = useState<EconomicIntelligenceResponse | null>(null);
  const [publicConfig, setPublicConfig] = useState<PublicConfigSummary | null>(null);

  const fetchFxData = useCallback(
    async (base: string, target: string, targetRate: number | null) => {
      setFxLoading(true);
      try {
        const params = new URLSearchParams({ base, target });
        if (targetRate && targetRate > 0) {
          params.set("targetRate", String(targetRate));
        }
        const res = await fetch(`/api/fx?${params.toString()}`, {
          headers: { "x-visitor-id": getOrCreateVisitorId() },
        });
        if (res.ok) {
          const data = (await res.json()) as {
            overview: FxOverview;
            radar: OpportunityAnalysis | null;
          };
          setFx(data.overview);
          setRadar(data.radar);
        }
      } catch {
        // Keep last state gracefully
      } finally {
        setFxLoading(false);
      }
    },
    []
  );

  const fetchEconomicsAndConfig = useCallback(async () => {
    try {
      const [econRes, cfgRes] = await Promise.all([
        fetch("/api/economics"),
        fetch("/api/public-config"),
      ]);
      if (econRes.ok) {
        setEconomics((await econRes.json()) as EconomicIntelligenceResponse);
      }
      if (cfgRes.ok) {
        setPublicConfig((await cfgRes.json()) as PublicConfigSummary);
      }
    } catch {
      // Non-fatal
    }
  }, []);

  useEffect(() => {
    void fetchFxData(
      profile.trackedPairBase || "EUR",
      profile.trackedPairTarget || "BRL",
      profile.targetRate
    );
    void fetchEconomicsAndConfig();
  }, [fetchFxData, fetchEconomicsAndConfig, profile.trackedPairBase, profile.trackedPairTarget, profile.targetRate]);

  // Evaluate active FX alerts whenever FX data updates
  const triggeredAlerts = useMemo(() => evaluateFxAlerts(fxAlerts, fx), [fxAlerts, fx]);

  useEffect(() => {
    if (
      triggeredAlerts.length > 0 &&
      typeof window !== "undefined" &&
      "Notification" in window &&
      Notification.permission === "granted"
    ) {
      const wantsNotif = fxAlerts.some(
        (r) => r.active && r.browserNotification && triggeredAlerts.some((t) => t.ruleId === r.id)
      );
      if (wantsNotif) {
        new Notification(triggeredAlerts[0].title, {
          body: triggeredAlerts[0].description,
        });
      }
    }
  }, [triggeredAlerts, fxAlerts]);

  const handleUpdateProfile = (next: UserProfile) => {
    setProfile(next);
    saveProfile(next);
  };

  const handleAddPurchase = (entry: PurchaseEntry) => {
    const next = [entry, ...purchases];
    setPurchases(next);
    savePurchases(next);
  };

  const handleDeletePurchase = (id: string) => {
    const next = purchases.filter((p) => p.id !== id);
    setPurchases(next);
    savePurchases(next);
  };

  const handleSaveFxAlerts = (next: FxAlertRule[]) => {
    setFxAlerts(next);
    saveFxAlerts(next);
  };

  const handleSaveFlightAlerts = (next: FlightAlertRule[]) => {
    setFlightAlerts(next);
    saveFlightAlerts(next);
  };

  const handleSaveManualFlights = (next: ManualFlightQuote[]) => {
    setManualFlights(next);
    saveManualFlights(next);
  };

  const handleUpdateChatHistory = (next: ChatMessage[]) => {
    setChatHistory(next);
    saveChatHistory(next);
  };

  const handleUpdateAiConsent = (consented: boolean) => {
    setAiConsent(consented);
    saveAiConsent(consented);
  };

  const handleClearAllLocalData = () => {
    clearAllLocalData();
    const freshProfile = loadProfile();
    setProfile(freshProfile);
    setPurchases([]);
    setFxAlerts([]);
    setFlightAlerts([]);
    setManualFlights([]);
    setChatHistory([]);
    setAiConsent(false);
  };

  const navigate = (next: NavSection) => {
    setSection(next);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F8FA] text-[#0F172A]">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-xs">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-4 py-3.5 sm:px-6 lg:px-8">
          {/* Zone 1: Single-line brand wordmark */}
          <button
            type="button"
            onClick={() => navigate("overview")}
            className="font-display text-lg font-semibold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Madrid Finance
          </button>

          {/* Zone 2: Clean single-line text nav links */}
          <nav className="hidden lg:flex items-center gap-6" aria-label="Navegação principal">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => navigate(item.id)}
                className={`text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  section === item.id
                    ? "text-[#1D4ED8] underline underline-offset-8 decoration-2"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1 primary CTA + mobile menu toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate("assistant")}
              className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Assistente IA
            </button>
            <button
              type="button"
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 lg:hidden cursor-pointer"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <nav
            className="border-t border-slate-200 bg-white px-4 py-3 lg:hidden"
            aria-label="Navegação mobile"
          >
            <div className="flex flex-col space-y-1">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigate(item.id)}
                  className={`rounded-lg px-3 py-2.5 text-left text-sm font-medium ${
                    section === item.id
                      ? "bg-[#1D4ED8]/10 text-[#1D4ED8]"
                      : "text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => navigate("settings")}
                className={`rounded-lg px-3 py-2.5 text-left text-sm font-medium ${
                  section === "settings"
                    ? "bg-[#1D4ED8]/10 text-[#1D4ED8]"
                    : "text-slate-700 hover:bg-slate-50"
                }`}
              >
                Configurações & Privacidade
              </button>
            </div>
          </nav>
        )}
      </header>

      {/* Main Content Container */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8 sm:px-6 lg:px-8">
        {section === "overview" && (
          <OverviewSection
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            fx={fx}
            fxLoading={fxLoading}
            radar={radar}
            purchases={purchases}
            triggeredAlerts={triggeredAlerts}
            onNavigate={navigate}
          />
        )}

        {section === "assistant" && (
          <AssistantSection
            profile={profile}
            purchases={purchases}
            fx={fx}
            chatHistory={chatHistory}
            onUpdateChatHistory={handleUpdateChatHistory}
            aiConsent={aiConsent}
            onUpdateAiConsent={handleUpdateAiConsent}
            maxChars={publicConfig?.limits.maxMessageChars || 800}
          />
        )}

        {section === "fx" && (
          <FxDashboardSection
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            fx={fx}
            fxLoading={fxLoading}
            radar={radar}
            economics={economics}
            onRefreshFx={fetchFxData}
          />
        )}

        {section === "wise" && (
          <WiseCalculatorSection fx={fx} onAddPurchase={handleAddPurchase} />
        )}

        {section === "planning" && (
          <PlanningAlertsSection
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            fx={fx}
            fxAlerts={fxAlerts}
            onSaveFxAlerts={handleSaveFxAlerts}
            triggeredAlerts={triggeredAlerts}
          />
        )}

        {section === "flights" && (
          <FlightsSection
            profile={profile}
            flightAlerts={flightAlerts}
            onSaveFlightAlerts={handleSaveFlightAlerts}
            manualFlights={manualFlights}
            onSaveManualFlights={handleSaveManualFlights}
          />
        )}

        {section === "reports" && (
          <ReportsSection
            profile={profile}
            purchases={purchases}
            onDeletePurchase={handleDeletePurchase}
            fx={fx}
          />
        )}

        {section === "settings" && (
          <SettingsPrivacySection
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            aiConsent={aiConsent}
            onUpdateAiConsent={handleUpdateAiConsent}
            onClearAllData={handleClearAllLocalData}
          />
        )}

        {section === "admin" && (
          <AdminSection onConfigUpdated={() => void fetchEconomicsAndConfig()} />
        )}
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <div className="space-y-1">
            <p className="font-medium text-slate-700">
              Madrid Finance — Planeje sua viagem com inteligência
            </p>
            <p>
              Conteúdo informativo e educacional; não substitui aconselhamento financeiro
              profissional. Dados pessoais isolados no LocalStorage do seu navegador.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4 shrink-0">
            <button
              type="button"
              onClick={() => navigate("settings")}
              className="text-slate-600 hover:text-slate-900 hover:underline cursor-pointer"
            >
              Configurações & Privacidade
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => navigate("admin")}
              className="text-slate-500 hover:text-slate-900 hover:underline cursor-pointer"
            >
              Administração
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
