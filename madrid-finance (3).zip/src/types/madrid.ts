export type NavSection =
  | "overview"
  | "assistant"
  | "fx"
  | "wise"
  | "planning"
  | "flights"
  | "reports"
  | "settings"
  | "admin";

export interface UserProfile {
  onboardingCompleted: boolean;
  nickname: string;
  originCountry: string;
  originCurrency: string;
  destinationCountry: string;
  tripDate: string;
  returnDate?: string;
  totalBudgetBrl: number;
  alreadySavedBrl: number;
  alreadyAccumulatedEur: number;
  emergencyReserveBrl: number;
  monthlyAvailableBrl: number;
  expectedDestinationExpensesEur: number;
  financialGoal: string;
  trackedPairBase: string;
  trackedPairTarget: string;
  checkFrequency: "diaria" | "semanal" | "tempo_real";
  targetRate: number | null;
}

export interface PurchaseEntry {
  id: string;
  date: string;
  eurBought: number;
  brlSpent: number;
  exchangeRate: number;
  feesAndIofBrl: number;
  effectiveCostPerEur: number;
  platform: string;
  note: string;
}

export interface FxAlertRule {
  id: string;
  pair: string;
  type: "target_below" | "drop_percent" | "rise_percent";
  threshold: number;
  frequency: "diaria" | "semanal";
  browserNotification: boolean;
  active: boolean;
  createdAt: string;
}

export interface TriggeredAlert {
  ruleId: string;
  title: string;
  description: string;
  severity: "opportunity" | "warning";
  triggeredAt: string;
}

export interface FlightAlertRule {
  id: string;
  origin: string;
  destination: string;
  departureDate: string;
  returnDate: string;
  maxBudgetBrl: number;
  passengers: number;
  active: boolean;
  createdAt: string;
}

export interface ManualFlightQuote {
  id: string;
  airline: string;
  route: string;
  totalBrl: number;
  taxesBrl: number;
  baggage: string;
  stops: number;
  schedule: string;
  conditions: string;
  observedDate: string;
  sourcePortal: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: string;
  skillsUsed?: string[];
  sourcesCited?: string[];
}

export interface FxPoint {
  date: string;
  rate: number;
}

export interface FxOverview {
  available: boolean;
  base: string;
  target: string;
  latestRate: number | null;
  previousRate: number | null;
  absoluteChange: number | null;
  percentChange: number | null;
  observationDate: string | null;
  fetchedAt: string;
  stale: boolean;
  source: string;
  bcbPtax: {
    available: boolean;
    buyRate: number | null;
    sellRate: number | null;
    timestamp: string | null;
    source: string;
  };
  stats: {
    avg7d: number | null;
    avg30d: number | null;
    avg90d: number | null;
    min7d: number | null;
    max7d: number | null;
    min30d: number | null;
    max30d: number | null;
    min90d: number | null;
    max90d: number | null;
    best30dDate: string | null;
    worst30dDate: string | null;
  };
  history90d: FxPoint[];
  disclaimer: string;
  errorMessage?: string;
}

export interface OpportunityAnalysis {
  available: boolean;
  classification:
    | "Excelente oportunidade"
    | "Boa oportunidade"
    | "Oportunidade neutra"
    | "Momento desfavorável"
    | "Dados indisponíveis";
  summary: string;
  reasons: string[];
  metrics: {
    currentRate: number | null;
    avg7d: number | null;
    avg30d: number | null;
    avg90d: number | null;
    min90d: number | null;
    max90d: number | null;
    dailyChangePct: number | null;
    targetRate: number | null;
    distanceToTargetPct: number | null;
  };
  source: string;
  observationDate: string | null;
}

export interface EconomicIntelligenceResponse {
  updatedAt: string;
  indicators: Array<{
    id: string;
    label: string;
    value: string;
    referenceDate: string;
    source: string;
    verified: boolean;
  }>;
  facts: string[];
  expectations: string[];
  hypotheses: string[];
  methodologyNote: string;
}

export interface FlightSearchResponse {
  mode: "amadeus_live" | "external_links_only";
  amadeusConfigured: boolean;
  offers: Array<{
    id: string;
    airline: string;
    priceTotalBrl: number;
    taxesEstimatedBrl: number | null;
    currency: string;
    stops: number;
    outboundDeparture: string;
    outboundArrival: string;
    inboundDeparture?: string;
    inboundArrival?: string;
    baggageInfo: string;
    fareConditions: string;
    source: string;
  }>;
  externalLinks: Array<{
    provider: string;
    description: string;
    url: string;
  }>;
  searchedAt: string;
  sourceLabel: string;
  quotaRemainingToday: number;
  notice: string;
}

export interface PublicConfigSummary {
  skillsEnabled: Record<string, boolean>;
  limits: {
    aiRequestsPerHourPerVisitor: number;
    maxConversationMessages: number;
    maxMessageChars: number;
  };
  amadeusConfigured: boolean;
}
