import type {
  ChatMessage,
  FlightAlertRule,
  FxAlertRule,
  ManualFlightQuote,
  PurchaseEntry,
  UserProfile,
} from "../types/madrid";

const KEYS = {
  visitorId: "madrid_finance_v1_visitor_id",
  profile: "madrid_finance_v1_profile",
  purchases: "madrid_finance_v1_purchases",
  fxAlerts: "madrid_finance_v1_fx_alerts",
  flightAlerts: "madrid_finance_v1_flight_alerts",
  manualFlights: "madrid_finance_v1_manual_flights",
  chatHistory: "madrid_finance_v1_chat_history",
  aiConsent: "madrid_finance_v1_ai_consent",
};

export function getDefaultProfile(): UserProfile {
  const futureDate = new Date(Date.now() + 180 * 86400_000).toISOString().slice(0, 10);
  return {
    onboardingCompleted: false,
    nickname: "",
    originCountry: "Brasil",
    originCurrency: "BRL",
    destinationCountry: "Espanha (Madrid)",
    tripDate: futureDate,
    returnDate: "",
    totalBudgetBrl: 18000,
    alreadySavedBrl: 3500,
    alreadyAccumulatedEur: 400,
    emergencyReserveBrl: 12000,
    monthlyAvailableBrl: 1800,
    expectedDestinationExpensesEur: 2200,
    financialGoal: "Acumular reserva em euros para viagem a Madrid com compras graduais",
    trackedPairBase: "EUR",
    trackedPairTarget: "BRL",
    checkFrequency: "diaria",
    targetRate: 6.1,
  };
}

export function getOrCreateVisitorId(): string {
  try {
    let id = localStorage.getItem(KEYS.visitorId);
    if (!id) {
      id = `mf_${crypto.randomUUID().slice(0, 12)}`;
      localStorage.setItem(KEYS.visitorId, id);
    }
    return id;
  } catch {
    return "mf_anon";
  }
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

export function loadProfile(): UserProfile {
  return { ...getDefaultProfile(), ...readJson<Partial<UserProfile>>(KEYS.profile, {}) };
}

export function saveProfile(profile: UserProfile): void {
  writeJson(KEYS.profile, profile);
}

export function loadPurchases(): PurchaseEntry[] {
  return readJson<PurchaseEntry[]>(KEYS.purchases, []);
}

export function savePurchases(items: PurchaseEntry[]): void {
  writeJson(KEYS.purchases, items);
}

export function loadFxAlerts(): FxAlertRule[] {
  return readJson<FxAlertRule[]>(KEYS.fxAlerts, []);
}

export function saveFxAlerts(items: FxAlertRule[]): void {
  writeJson(KEYS.fxAlerts, items);
}

export function loadFlightAlerts(): FlightAlertRule[] {
  return readJson<FlightAlertRule[]>(KEYS.flightAlerts, []);
}

export function saveFlightAlerts(items: FlightAlertRule[]): void {
  writeJson(KEYS.flightAlerts, items);
}

export function loadManualFlights(): ManualFlightQuote[] {
  return readJson<ManualFlightQuote[]>(KEYS.manualFlights, []);
}

export function saveManualFlights(items: ManualFlightQuote[]): void {
  writeJson(KEYS.manualFlights, items);
}

export function loadChatHistory(): ChatMessage[] {
  return readJson<ChatMessage[]>(KEYS.chatHistory, []);
}

export function saveChatHistory(items: ChatMessage[]): void {
  writeJson(KEYS.chatHistory, items.slice(-24));
}

export function loadAiConsent(): boolean {
  return readJson<boolean>(KEYS.aiConsent, false);
}

export function saveAiConsent(consented: boolean): void {
  writeJson(KEYS.aiConsent, consented);
}

export function clearAllLocalData(): void {
  try {
    Object.values(KEYS).forEach((k) => localStorage.removeItem(k));
  } catch {
    // Ignore
  }
}
