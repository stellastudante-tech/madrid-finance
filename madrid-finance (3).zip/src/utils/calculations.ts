import type { FxAlertRule, FxOverview, PurchaseEntry, TriggeredAlert, UserProfile } from "../types/madrid";

export interface WiseClientCalculation {
  brlDebited: number;
  eurReceived: number;
  exchangeRateUsed: number;
  platformFeeBrl: number;
  iofBrl: number;
  totalFeesBrl: number;
  effectiveCostPerEur: number;
  spreadPct: number;
}

export function computeWiseLocal(params: {
  mode: "buy_target" | "spend_source";
  amount: number;
  exchangeRate: number;
  platformFeePercent: number;
  fixedFeeBrl: number;
  iofPercent: number;
}): WiseClientCalculation {
  const rate = Math.max(0.01, params.exchangeRate || 6.0);
  const feePct = Math.max(0, params.platformFeePercent || 0) / 100;
  const fixed = Math.max(0, params.fixedFeeBrl || 0);
  const iofPct = Math.max(0, params.iofPercent || 0) / 100;
  const amount = Math.max(0, params.amount || 0);

  let brlBase = 0;
  let eurReceived = 0;
  let platformFeeBrl = 0;
  let iofBrl = 0;
  let brlDebited = 0;

  if (params.mode === "buy_target") {
    eurReceived = amount;
    brlBase = eurReceived * rate;
    platformFeeBrl = brlBase * feePct + fixed;
    iofBrl = (brlBase + platformFeeBrl) * iofPct;
    brlDebited = brlBase + platformFeeBrl + iofBrl;
  } else {
    brlDebited = amount;
    const netBeforeIof = Math.max(0, brlDebited / (1 + iofPct) - fixed);
    brlBase = netBeforeIof / (1 + feePct);
    platformFeeBrl = brlBase * feePct + fixed;
    iofBrl = Math.max(0, brlDebited - brlBase - platformFeeBrl);
    eurReceived = brlBase / rate;
  }

  const effectiveCostPerEur = eurReceived > 0 ? brlDebited / eurReceived : 0;
  const spreadPct = rate > 0 && effectiveCostPerEur > 0 ? ((effectiveCostPerEur - rate) / rate) * 100 : 0;

  return {
    brlDebited,
    eurReceived,
    exchangeRateUsed: rate,
    platformFeeBrl,
    iofBrl,
    totalFeesBrl: platformFeeBrl + iofBrl,
    effectiveCostPerEur,
    spreadPct,
  };
}

export function evaluateFxAlerts(rules: FxAlertRule[], fx: FxOverview | null): TriggeredAlert[] {
  if (!fx || !fx.available || fx.latestRate === null) return [];
  const triggered: TriggeredAlert[] = [];

  for (const rule of rules) {
    if (!rule.active) continue;
    if (rule.type === "target_below" && fx.latestRate <= rule.threshold) {
      triggered.push({
        ruleId: rule.id,
        title: `Meta atingida em ${fx.base}/${fx.target}`,
        description: `Cotação atual (${fx.latestRate.toFixed(4)}) está abaixo ou igual ao seu alvo de ${rule.threshold.toFixed(4)}.`,
        severity: "opportunity",
        triggeredAt: fx.observationDate || fx.fetchedAt,
      });
    } else if (
      rule.type === "drop_percent" &&
      fx.percentChange !== null &&
      fx.percentChange <= -Math.abs(rule.threshold)
    ) {
      triggered.push({
        ruleId: rule.id,
        title: `Queda relevante em ${fx.base}/${fx.target}`,
        description: `Recuo de ${Math.abs(fx.percentChange).toFixed(2)}% frente à observação anterior (alerta configurado: -${Math.abs(rule.threshold).toFixed(2)}%).`,
        severity: "opportunity",
        triggeredAt: fx.observationDate || fx.fetchedAt,
      });
    } else if (
      rule.type === "rise_percent" &&
      fx.percentChange !== null &&
      fx.percentChange >= Math.abs(rule.threshold)
    ) {
      triggered.push({
        ruleId: rule.id,
        title: `Alta relevante em ${fx.base}/${fx.target}`,
        description: `Alta de ${fx.percentChange.toFixed(2)}% frente à observação anterior (alerta configurado: +${Math.abs(rule.threshold).toFixed(2)}%).`,
        severity: "warning",
        triggeredAt: fx.observationDate || fx.fetchedAt,
      });
    }
  }

  return triggered;
}

export interface TripTimeline {
  hasDepartureDate: boolean;
  hasReturnDate: boolean;
  isValidRange: boolean;
  durationDays: number | null;
  durationMonths: number | null;
  daysUntilDeparture: number | null;
  daysUntilReturn: number | null;
  tripStatus: "not_scheduled" | "upcoming" | "in_progress" | "completed" | "invalid_range";
  temporalProgressPercent: number | null;
}

function parseYmdUtc(ymd?: string): Date | null {
  if (!ymd || !/^\d{4}-\d{2}-\d{2}$/.test(ymd)) return null;
  const [y, m, d] = ymd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return Number.isNaN(dt.getTime()) ? null : dt;
}

export function computeTripTimeline(tripDate?: string, returnDate?: string): TripTimeline {
  const dep = parseYmdUtc(tripDate);
  const ret = parseYmdUtc(returnDate);

  if (!dep) {
    return {
      hasDepartureDate: false,
      hasReturnDate: Boolean(ret),
      isValidRange: false,
      durationDays: null,
      durationMonths: null,
      daysUntilDeparture: null,
      daysUntilReturn: null,
      tripStatus: "not_scheduled",
      temporalProgressPercent: null,
    };
  }

  const now = new Date();
  const todayUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const MS_DAY = 86400_000;

  const daysUntilDeparture = Math.round((dep.getTime() - todayUtc.getTime()) / MS_DAY);

  if (!ret) {
    return {
      hasDepartureDate: true,
      hasReturnDate: false,
      isValidRange: true,
      durationDays: null,
      durationMonths: null,
      daysUntilDeparture,
      daysUntilReturn: null,
      tripStatus: daysUntilDeparture > 0 ? "upcoming" : "in_progress",
      temporalProgressPercent: null,
    };
  }

  if (ret.getTime() < dep.getTime()) {
    return {
      hasDepartureDate: true,
      hasReturnDate: true,
      isValidRange: false,
      durationDays: null,
      durationMonths: null,
      daysUntilDeparture,
      daysUntilReturn: Math.round((ret.getTime() - todayUtc.getTime()) / MS_DAY),
      tripStatus: "invalid_range",
      temporalProgressPercent: null,
    };
  }

  const durationDays = Math.max(1, Math.round((ret.getTime() - dep.getTime()) / MS_DAY));
  const durationMonths = Number((durationDays / 30.4375).toFixed(1));
  const daysUntilReturn = Math.round((ret.getTime() - todayUtc.getTime()) / MS_DAY);

  let tripStatus: TripTimeline["tripStatus"] = "upcoming";
  let temporalProgressPercent: number | null = null;

  if (todayUtc.getTime() < dep.getTime()) {
    tripStatus = "upcoming";
    temporalProgressPercent = 0;
  } else if (todayUtc.getTime() <= ret.getTime()) {
    tripStatus = "in_progress";
    const elapsedDays = Math.max(0, Math.round((todayUtc.getTime() - dep.getTime()) / MS_DAY));
    temporalProgressPercent = Number(
      Math.min(100, Math.max(0, (elapsedDays / durationDays) * 100)).toFixed(1)
    );
  } else {
    tripStatus = "completed";
    temporalProgressPercent = 100;
  }

  return {
    hasDepartureDate: true,
    hasReturnDate: true,
    isValidRange: true,
    durationDays,
    durationMonths,
    daysUntilDeparture,
    daysUntilReturn,
    tripStatus,
    temporalProgressPercent,
  };
}

export interface FinancialReportSummary {
  totalEurFromPurchases: number;
  totalBrlFromPurchases: number;
  weightedAverageEurCost: number | null;
  totalAccumulatedEur: number;
  estimatedGoalEur: number;
  remainingEurNeeded: number;
  remainingBrlEstimated: number;
  progressPercent: number;
  timeline: TripTimeline;
  recommendations: string[];
}

export function buildFinancialReport(
  profile: UserProfile,
  purchases: PurchaseEntry[],
  fx: FxOverview | null
): FinancialReportSummary {
  const rate = fx?.latestRate || 6.1;
  const timeline = computeTripTimeline(profile.tripDate, profile.returnDate);
  const totalEurFromPurchases = purchases.reduce((sum, p) => sum + p.eurBought, 0);
  const totalBrlFromPurchases = purchases.reduce((sum, p) => sum + p.brlSpent, 0);
  const weightedAverageEurCost =
    totalEurFromPurchases > 0 ? totalBrlFromPurchases / totalEurFromPurchases : null;

  const totalAccumulatedEur = profile.alreadyAccumulatedEur + totalEurFromPurchases;
  const budgetGoalEur = profile.totalBudgetBrl > 0 ? profile.totalBudgetBrl / rate : 0;
  const estimatedGoalEur = Math.max(budgetGoalEur, profile.expectedDestinationExpensesEur || 0);

  const savedBrlInEur = profile.alreadySavedBrl / rate;
  const effectiveAccumulatedEur = totalAccumulatedEur + savedBrlInEur;
  const remainingEurNeeded = Math.max(0, estimatedGoalEur - effectiveAccumulatedEur);
  const remainingBrlEstimated = remainingEurNeeded * rate;
  const progressPercent =
    estimatedGoalEur > 0 ? Math.min(100, (effectiveAccumulatedEur / estimatedGoalEur) * 100) : 0;

  const recommendations: string[] = [];
  if (purchases.length === 0) {
    recommendations.push(
      "Registre sua primeira compra ou simulação real na Calculadora Wise para acompanhar o custo médio efetivo em euro."
    );
  } else if (weightedAverageEurCost !== null && fx?.latestRate) {
    if (fx.latestRate < weightedAverageEurCost) {
      recommendations.push(
        `A cotação de referência atual (${fx.latestRate.toFixed(4)}) está abaixo do seu custo médio histórico (${weightedAverageEurCost.toFixed(4)}). Um novo aporte gradual pode reduzir seu preço médio.`
      );
    } else {
      recommendations.push(
        `Seu custo médio acumulado (${weightedAverageEurCost.toFixed(4)}) está abaixo da cotação de referência atual (${fx.latestRate.toFixed(4)}). Mantenha aportes moderados apenas conforme o cronograma.`
      );
    }
  }

  if (timeline.hasReturnDate && timeline.isValidRange && timeline.durationDays) {
    const dailyEurBudget =
      estimatedGoalEur > 0 ? estimatedGoalEur / timeline.durationDays : null;
    if (timeline.tripStatus === "in_progress" && timeline.daysUntilReturn !== null) {
      recommendations.push(
        `Viagem em andamento (${timeline.temporalProgressPercent?.toFixed(1)}% do período decorrido · ${timeline.daysUntilReturn} dia(s) até o retorno). Acompanhe o ritmo de gastos para preservar sua margem até a volta.`
      );
    } else if (dailyEurBudget !== null && timeline.daysUntilDeparture !== null && timeline.daysUntilDeparture > 0) {
      recommendations.push(
        `Para uma estadia de ${timeline.durationDays} dia(s) (${timeline.durationMonths} mês/meses), sua meta equivale a cerca de € ${dailyEurBudget.toFixed(2)}/dia. Faltam ${timeline.daysUntilDeparture} dia(s) para o embarque.`
      );
    }
  }

  if (remainingEurNeeded > 0) {
    recommendations.push(
      `Restam aproximadamente € ${remainingEurNeeded.toFixed(2)} (estimativa de R$ ${remainingBrlEstimated.toFixed(2)} na referência atual) para completar sua meta planejada.`
    );
  } else {
    recommendations.push(
      "Você já atingiu ou superou o valor estimado da meta da viagem. Priorize proteger o poder de compra e manter sua reserva de emergência em reais."
    );
  }

  if (profile.emergencyReserveBrl <= 0) {
    recommendations.push(
      "Defina sua reserva de emergência nas Configurações Pessoais para garantir que aportes da viagem não afetem sua segurança financeira."
    );
  }

  return {
    totalEurFromPurchases,
    totalBrlFromPurchases,
    weightedAverageEurCost,
    totalAccumulatedEur,
    estimatedGoalEur,
    remainingEurNeeded,
    remainingBrlEstimated,
    progressPercent,
    timeline,
    recommendations,
  };
}

export function exportReportToCsv(
  profile: UserProfile,
  purchases: PurchaseEntry[],
  report: FinancialReportSummary,
  fx: FxOverview | null
): void {
  const escapeCsv = (val: string | number) => {
    const str = String(val ?? "");
    if (/[",\n;]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const lines: string[] = [];
  lines.push("RELATORIO FINANCEIRO MADRID FINANCE");
  lines.push(`Gerado em,${escapeCsv(new Date().toLocaleString("pt-BR"))}`);
  lines.push(`Viajante,${escapeCsv(profile.nickname || "Visitante")}`);
  lines.push(`Destino,${escapeCsv(profile.destinationCountry)}`);
  lines.push(`Data prevista de ida,${escapeCsv(profile.tripDate || "Nao informada")}`);
  lines.push(`Data prevista de volta,${escapeCsv(profile.returnDate || "Nao informada")}`);
  if (report.timeline.hasReturnDate && report.timeline.isValidRange && report.timeline.durationDays !== null) {
    lines.push(`Duracao da viagem,${report.timeline.durationDays} dias (${report.timeline.durationMonths} meses)`);
    lines.push(`Dias ate o embarque,${report.timeline.daysUntilDeparture ?? "N/A"}`);
    lines.push(`Dias ate o retorno,${report.timeline.daysUntilReturn ?? "N/A"}`);
    lines.push(`Progresso temporal da viagem,${report.timeline.temporalProgressPercent ?? 0}%`);
  }
  lines.push(
    `Cotacao de referencia (${fx?.base || "EUR"}/${fx?.target || "BRL"}),${
      fx?.latestRate ? fx.latestRate.toFixed(4) : "Indisponivel"
    }`
  );
  lines.push(`Fonte cambial,${escapeCsv(fx?.source || "Frankfurter")}`);
  lines.push(`Meta estimada (EUR),${report.estimatedGoalEur.toFixed(2)}`);
  lines.push(`Acumulado em EUR (historico + saldo),${report.totalAccumulatedEur.toFixed(2)}`);
  lines.push(
    `Custo medio ponderado (BRL/EUR),${
      report.weightedAverageEurCost ? report.weightedAverageEurCost.toFixed(4) : "N/A"
    }`
  );
  lines.push(`Progresso financeiro (%),${report.progressPercent.toFixed(1)}%`);
  lines.push("");
  lines.push("HISTORICO DE COMPRAS REGISTRADAS");
  lines.push(
    "Data,Plataforma,EUR Comprados,BRL Gastos,Taxa Cambio,Taxas + IOF (BRL),Custo Efetivo (BRL/EUR),Observacao"
  );

  for (const p of purchases) {
    lines.push(
      [
        p.date,
        p.platform,
        p.eurBought.toFixed(2),
        p.brlSpent.toFixed(2),
        p.exchangeRate.toFixed(4),
        p.feesAndIofBrl.toFixed(2),
        p.effectiveCostPerEur.toFixed(4),
        p.note,
      ]
        .map(escapeCsv)
        .join(",")
    );
  }

  const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `madrid-finance-relatorio-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
