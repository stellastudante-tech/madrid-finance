import { useState } from "react";
import { Bell, ExternalLink, Info, Plane, Plus, Search, Trash2 } from "lucide-react";
import type {
  FlightAlertRule,
  FlightSearchResponse,
  ManualFlightQuote,
  UserProfile,
} from "../types/madrid";
import { getOrCreateVisitorId } from "../utils/storage";

interface FlightsSectionProps {
  profile: UserProfile;
  flightAlerts: FlightAlertRule[];
  onSaveFlightAlerts: (next: FlightAlertRule[]) => void;
  manualFlights: ManualFlightQuote[];
  onSaveManualFlights: (next: ManualFlightQuote[]) => void;
}

export function FlightsSection({
  profile,
  flightAlerts,
  onSaveFlightAlerts,
  manualFlights,
  onSaveManualFlights,
}: FlightsSectionProps) {
  const defaultDep =
    profile.tripDate || new Date(Date.now() + 60 * 86400_000).toISOString().slice(0, 10);
  const initialReturn = profile.returnDate || "";

  const [origin, setOrigin] = useState("GRU");
  const [destination, setDestination] = useState("MAD");
  const [departureDate, setDepartureDate] = useState(defaultDep);
  const [returnDate, setReturnDate] = useState(initialReturn);
  const [roundTrip, setRoundTrip] = useState(Boolean(initialReturn));
  const [flexibleDates, setFlexibleDates] = useState(true);
  const [passengers, setPassengers] = useState(1);
  const [airline, setAirline] = useState("");
  const [directOnly, setDirectOnly] = useState(false);
  const [baggageIncluded, setBaggageIncluded] = useState(true);
  const [maxBudgetBrl, setMaxBudgetBrl] = useState(5500);
  const [paymentMethod, setPaymentMethod] = useState("Cartão parcelado");

  const [loading, setLoading] = useState(false);
  const [searchResult, setSearchResult] = useState<FlightSearchResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Manual quote comparison entry
  const [manualAirline, setManualAirline] = useState("Iberia");
  const [manualTotalBrl, setManualTotalBrl] = useState<number>(4850);
  const [manualTaxesBrl, setManualTaxesBrl] = useState<number>(620);
  const [manualBaggage, setManualBaggage] = useState("1 mala 23kg");
  const [manualStops, setManualStops] = useState(0);
  const [manualSchedule, setManualSchedule] = useState("19:40 - 10:20 (+1)");
  const [manualConditions, setManualConditions] = useState("Remarcação com taxa; bagagem incluída");
  const [manualPortal, setManualPortal] = useState("Site oficial Iberia");

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch("/api/flights/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-visitor-id": getOrCreateVisitorId(),
        },
        body: JSON.stringify({
          origin,
          destination,
          departureDate,
          returnDate: roundTrip ? returnDate : undefined,
          flexibleDates,
          roundTrip,
          passengers,
          airline,
          directOnly,
          baggageIncluded,
          maxBudgetBrl,
          paymentMethod,
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        setErrorMsg(json.error || "Não foi possível consultar voos no momento.");
      } else {
        setSearchResult(json as FlightSearchResponse);
      }
    } catch {
      setErrorMsg("Erro de rede ao consultar o módulo de passagens.");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFlightAlert = () => {
    const rule: FlightAlertRule = {
      id: crypto.randomUUID(),
      origin: origin.toUpperCase(),
      destination: destination.toUpperCase(),
      departureDate,
      returnDate: roundTrip ? returnDate : "",
      maxBudgetBrl,
      passengers,
      active: true,
      createdAt: new Date().toISOString(),
    };
    onSaveFlightAlerts([rule, ...flightAlerts]);
  };

  const handleAddManualQuote = (e: React.FormEvent) => {
    e.preventDefault();
    const item: ManualFlightQuote = {
      id: crypto.randomUUID(),
      airline: manualAirline.trim() || "Cia Aérea",
      route: `${origin.toUpperCase()} → ${destination.toUpperCase()}`,
      totalBrl: Number(manualTotalBrl) || 0,
      taxesBrl: Number(manualTaxesBrl) || 0,
      baggage: manualBaggage,
      stops: Number(manualStops) || 0,
      schedule: manualSchedule,
      conditions: manualConditions,
      observedDate: new Date().toISOString().slice(0, 10),
      sourcePortal: manualPortal,
    };
    onSaveManualFlights([item, ...manualFlights]);
  };

  const avgManualPrice =
    manualFlights.length > 0
      ? manualFlights.reduce((acc, q) => acc + q.totalBrl, 0) / manualFlights.length
      : null;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl font-semibold text-slate-900">
          Monitoramento de Passagens Aéreas
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Pesquise rotas com datas flexíveis, compare tarifas reais observadas e configure alertas de
          orçamento.
        </p>
      </div>

      {/* Search Form */}
      <form
        onSubmit={handleSearch}
        className="space-y-5 rounded-xl border border-slate-200 bg-white p-6"
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Origem (IATA)</span>
            <input
              type="text"
              maxLength={3}
              value={origin}
              onChange={(e) => setOrigin(e.target.value.toUpperCase())}
              placeholder="GRU"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm uppercase text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Destino (IATA)</span>
            <input
              type="text"
              maxLength={3}
              value={destination}
              onChange={(e) => setDestination(e.target.value.toUpperCase())}
              placeholder="MAD"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm uppercase text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Data de ida</span>
            <input
              type="date"
              value={departureDate}
              onChange={(e) => setDepartureDate(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Data de volta {profile.returnDate ? "(do perfil)" : "(opcional)"}</span>
            <input
              type="date"
              min={departureDate || undefined}
              disabled={!roundTrip}
              value={returnDate}
              onChange={(e) => setReturnDate(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 disabled:bg-slate-50 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Passageiros</span>
            <input
              type="number"
              min="1"
              max="9"
              value={passengers}
              onChange={(e) => setPassengers(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Companhia preferida (opcional)</span>
            <input
              type="text"
              value={airline}
              onChange={(e) => setAirline(e.target.value)}
              placeholder="Ex: Iberia, LATAM, Air Europa"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Orçamento máximo (R$)</span>
            <input
              type="number"
              min="500"
              step="100"
              value={maxBudgetBrl}
              onChange={(e) => setMaxBudgetBrl(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Forma de pagamento</span>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            >
              <option value="Cartão parcelado">Cartão parcelado</option>
              <option value="Pix / À vista">Pix / À vista</option>
              <option value="Milhas + Taxas">Milhas + Taxas</option>
            </select>
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-6 border-t border-slate-200 pt-4 text-xs text-slate-700">
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={roundTrip}
              onChange={(e) => setRoundTrip(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
            />
            <span>Ida e volta</span>
          </label>
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={flexibleDates}
              onChange={(e) => setFlexibleDates(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
            />
            <span>Datas flexíveis</span>
          </label>
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={directOnly}
              onChange={(e) => setDirectOnly(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
            />
            <span>Somente voos diretos</span>
          </label>
          <label className="inline-flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={baggageIncluded}
              onChange={(e) => setBaggageIncluded(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
            />
            <span>Incluir bagagem despachada</span>
          </label>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleCreateFlightAlert}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Bell className="h-3.5 w-3.5" aria-hidden="true" />
            Salvar alerta de preço ({origin} → {destination} até R$ {maxBudgetBrl})
          </button>

          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#1E40AF] disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Search className="h-4 w-4" aria-hidden="true" />
            {loading ? "Consultando..." : "Buscar passagens"}
          </button>
        </div>
      </form>

      {errorMsg && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-[#B91C1C]">
          {errorMsg}
        </div>
      )}

      {/* Search Result / Official Links */}
      {searchResult && (
        <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Resultado da Pesquisa ({origin} → {destination})
              </h3>
              <p className="mt-1 text-xs text-slate-500">
                Fonte: {searchResult.sourceLabel} · Consultado em{" "}
                <span className="font-mono">
                  {new Date(searchResult.searchedAt).toLocaleString("pt-BR")}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5 rounded-lg bg-slate-50 p-3.5 text-xs text-slate-700">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-slate-500" aria-hidden="true" />
            <p>{searchResult.notice}</p>
          </div>

          {searchResult.offers.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    <th className="py-2 pr-4 font-medium">Cia</th>
                    <th className="py-2 pr-4 font-medium">Ida / Volta</th>
                    <th className="py-2 pr-4 font-medium">Escalas</th>
                    <th className="py-2 pr-4 font-medium">Bagagem & Condições</th>
                    <th className="py-2 pr-4 font-medium text-right">Taxas est.</th>
                    <th className="py-2 text-right font-medium">Total (BRL)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {searchResult.offers.map((o) => (
                    <tr key={o.id} className="hover:bg-slate-50/70">
                      <td className="py-3 pr-4 font-semibold text-slate-900">{o.airline}</td>
                      <td className="py-3 pr-4 font-mono text-slate-700 tabular-nums">
                        {o.outboundDeparture.slice(0, 16).replace("T", " ")}
                        {o.inboundDeparture ? ` · Volta ${o.inboundDeparture.slice(0, 10)}` : ""}
                      </td>
                      <td className="py-3 pr-4 text-slate-700">
                        {o.stops === 0 ? "Direto" : `${o.stops} escala(s)`}
                      </td>
                      <td className="py-3 pr-4 text-slate-600">
                        {o.baggageInfo} · {o.fareConditions}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono text-slate-600 tabular-nums">
                        {o.taxesEstimatedBrl ? `R$ ${o.taxesEstimatedBrl.toFixed(2)}` : "--"}
                      </td>
                      <td className="py-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                        R$ {o.priceTotalBrl.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-slate-900">
              Links diretos para consulta em fontes confiáveis
            </h4>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {searchResult.externalLinks.map((link) => (
                <a
                  key={link.provider}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start justify-between gap-3 rounded-lg border border-slate-200 p-3.5 transition-colors hover:border-[#1D4ED8] hover:bg-slate-50"
                >
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{link.provider}</p>
                    <p className="mt-0.5 text-xs text-slate-600">{link.description}</p>
                  </div>
                  <ExternalLink className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Manual Fare Comparator + Historical Price Tracking */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="border-b border-slate-200 pb-3">
          <h3 className="text-base font-semibold text-slate-900">
            Comparativo de Tarifas Observadas (Histórico Pessoal)
          </h3>
          <p className="mt-1 text-xs text-slate-600">
            Registre cotações reais encontradas nos sites das companhias para comparar preço total,
            taxas, bagagem, escalas e variação frente ao seu histórico.
          </p>
        </div>

        <form onSubmit={handleAddManualQuote} className="grid grid-cols-1 gap-3 sm:grid-cols-3 lg:grid-cols-4 items-end">
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Companhia aérea</span>
            <input
              type="text"
              value={manualAirline}
              onChange={(e) => setManualAirline(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Preço total (R$)</span>
            <input
              type="number"
              min="100"
              step="10"
              value={manualTotalBrl}
              onChange={(e) => setManualTotalBrl(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Taxas incluídas (R$)</span>
            <input
              type="number"
              min="0"
              step="10"
              value={manualTaxesBrl}
              onChange={(e) => setManualTaxesBrl(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Bagagem</span>
            <input
              type="text"
              value={manualBaggage}
              onChange={(e) => setManualBaggage(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Escalas</span>
            <input
              type="number"
              min="0"
              max="3"
              value={manualStops}
              onChange={(e) => setManualStops(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Horários</span>
            <input
              type="text"
              value={manualSchedule}
              onChange={(e) => setManualSchedule(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Condições & Fonte</span>
            <input
              type="text"
              value={`${manualConditions} (${manualPortal})`}
              onChange={(e) => {
                setManualConditions(e.target.value);
                setManualPortal("Portal verificado");
              }}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-sm text-slate-900"
            />
          </label>
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            Adicionar ao comparativo
          </button>
        </form>

        {manualFlights.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 pr-3 font-medium">Data obs.</th>
                  <th className="py-2 pr-3 font-medium">Cia / Rota</th>
                  <th className="py-2 pr-3 font-medium">Horários / Escalas</th>
                  <th className="py-2 pr-3 font-medium">Bagagem & Condições</th>
                  <th className="py-2 pr-3 font-medium text-right">Taxas</th>
                  <th className="py-2 pr-3 font-medium text-right">Total</th>
                  <th className="py-2 pr-3 font-medium text-right">vs. Média</th>
                  <th className="py-2 text-right font-medium">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {manualFlights.map((q) => {
                  const diffPct =
                    avgManualPrice && avgManualPrice > 0
                      ? ((q.totalBrl - avgManualPrice) / avgManualPrice) * 100
                      : 0;
                  return (
                    <tr key={q.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 pr-3 font-mono text-slate-500">{q.observedDate}</td>
                      <td className="py-2.5 pr-3 font-medium text-slate-900">
                        {q.airline} · <span className="font-mono">{q.route}</span>
                      </td>
                      <td className="py-2.5 pr-3 text-slate-700">
                        <span className="font-mono">{q.schedule}</span> ·{" "}
                        {q.stops === 0 ? "Direto" : `${q.stops} esc.`}
                      </td>
                      <td className="py-2.5 pr-3 text-slate-600">
                        {q.baggage} · {q.conditions}
                      </td>
                      <td className="py-2.5 pr-3 text-right font-mono text-slate-600 tabular-nums">
                        R$ {q.taxesBrl.toFixed(2)}
                      </td>
                      <td className="py-2.5 pr-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                        R$ {q.totalBrl.toFixed(2)}
                      </td>
                      <td
                        className={`py-2.5 pr-3 text-right font-mono tabular-nums ${
                          diffPct <= 0 ? "text-[#15803D]" : "text-[#B91C1C]"
                        }`}
                      >
                        {diffPct > 0 ? "+" : ""}
                        {diffPct.toFixed(1)}%
                      </td>
                      <td className="py-2.5 text-right">
                        <button
                          type="button"
                          aria-label="Remover tarifa"
                          onClick={() =>
                            onSaveManualFlights(manualFlights.filter((m) => m.id !== q.id))
                          }
                          className="text-slate-400 hover:text-[#B91C1C] cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Saved Flight Price Alerts */}
        {flightAlerts.length > 0 && (
          <div className="border-t border-slate-200 pt-4 space-y-2">
            <h4 className="text-xs font-semibold text-slate-700">Alertas de orçamento configurados</h4>
            <div className="space-y-2">
              {flightAlerts.map((fa) => (
                <div
                  key={fa.id}
                  className="flex items-center justify-between rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs"
                >
                  <div className="flex items-center gap-2 text-slate-800">
                    <Plane className="h-3.5 w-3.5 text-[#1D4ED8]" aria-hidden="true" />
                    <span className="font-mono font-semibold">
                      {fa.origin} → {fa.destination}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">
                      {fa.departureDate}
                      {fa.returnDate ? ` até ${fa.returnDate}` : ""}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">Alvo até R$ {fa.maxBudgetBrl.toFixed(0)}</span>
                  </div>
                  <button
                    type="button"
                    aria-label="Excluir alerta de voo"
                    onClick={() => onSaveFlightAlerts(flightAlerts.filter((x) => x.id !== fa.id))}
                    className="text-slate-400 hover:text-[#B91C1C] cursor-pointer"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
