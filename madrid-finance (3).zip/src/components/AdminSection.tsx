import { useState } from "react";
import { CheckCircle2, KeyRound, Lock, RefreshCw, ShieldAlert } from "lucide-react";

interface AdminOverviewData {
  config: {
    skillsEnabled: Record<string, boolean>;
    sourcesEnabled: {
      frankfurter: boolean;
      bcbPtax: boolean;
      bcbIndicators: boolean;
      amadeus: boolean;
    };
    limits: {
      aiRequestsPerHourPerVisitor: number;
      aiRequestsPerDayGlobal: number;
      maxConversationMessages: number;
      maxMessageChars: number;
      fxRequestsPerHourPerVisitor: number;
      flightRequestsPerDayGlobal: number;
      fxCacheTtlMinutes: number;
      flightCacheTtlMinutes: number;
    };
    agentInstructions: string;
    amadeus: {
      clientId: string;
      clientSecret: string;
      environment: "test" | "production";
      configured: boolean;
    };
    geminiConfigured: boolean;
  };
  usage: {
    aiCallsTotal: number;
    aiCallsToday: number;
    aiQuotaDate: string;
    fxCallsTotal: number;
    fxCacheHits: number;
    flightCallsTotal: number;
    flightCallsToday: number;
    rateLimitRejections: number;
  };
  errors: Array<{
    id: string;
    timestamp: string;
    scope: string;
    message: string;
  }>;
}

const SKILL_LABELS: Record<string, string> = {
  skill01_fx: "Skill 01 — Monitoramento Cambial",
  skill02_economics: "Skill 02 — Inteligência Econômica",
  skill03_radar: "Skill 03 — Radar de Oportunidades",
  skill04_wise: "Skill 04 — Calculadora Wise",
  skill05_strategy: "Skill 05 — Estratégia de Compras",
  skill06_alerts: "Skill 06 — Alertas Cambiais",
  skill07_reports: "Skill 07 — Relatório Financeiro",
  skill08_flights: "Skill 08 — Monitoramento de Passagens",
};

interface AdminSectionProps {
  onConfigUpdated: () => void;
}

export function AdminSection({ onConfigUpdated }: AdminSectionProps) {
  const [passcode, setPasscode] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  const [amadeusIdInput, setAmadeusIdInput] = useState("");
  const [amadeusSecretInput, setAmadeusSecretInput] = useState("");

  const fetchOverview = async (authToken: string) => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/overview", {
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (!res.ok) {
        setToken(null);
        setData(null);
        setAuthError("Sessão administrativa expirada.");
        return;
      }
      const json = (await res.json()) as AdminOverviewData;
      setData(json);
      setAmadeusIdInput(json.config.amadeus.clientId);
      setAmadeusSecretInput(json.config.amadeus.clientSecret);
    } catch {
      setAuthError("Erro ao carregar painel administrativo.");
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passcode }),
      });
      const json = await res.json();
      if (!res.ok || !json.token) {
        setAuthError(json.error || "Código inválido.");
      } else {
        setToken(json.token);
        setPasscode("");
        await fetchOverview(json.token);
      }
    } catch {
      setAuthError("Erro de conexão ao autenticar.");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !data) return;
    setLoading(true);
    setSaveFeedback(null);
    try {
      const res = await fetch("/api/admin/config", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          skillsEnabled: data.config.skillsEnabled,
          sourcesEnabled: data.config.sourcesEnabled,
          limits: data.config.limits,
          agentInstructions: data.config.agentInstructions,
          amadeus: {
            clientId: amadeusIdInput,
            clientSecret: amadeusSecretInput,
            environment: data.config.amadeus.environment,
          },
        }),
      });
      if (res.ok) {
        setSaveFeedback("Configurações salvas com segurança no servidor.");
        await fetchOverview(token);
        onConfigUpdated();
      }
    } finally {
      setLoading(false);
    }
  };

  const handleClearCache = async () => {
    if (!token) return;
    await fetch("/api/admin/clear-cache", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    setSaveFeedback("Cache cambial e de pesquisas limpo.");
  };

  if (!token || !data) {
    return (
      <div className="mx-auto max-w-md space-y-6 rounded-xl border border-slate-200 bg-white p-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-base font-semibold text-slate-900">
            <Lock className="h-4 w-4 text-[#1D4ED8]" aria-hidden="true" />
            <h2>Área Administrativa Protegida</h2>
          </div>
          <p className="text-xs leading-relaxed text-slate-600">
            Acesso restrito ao administrador para gerenciar fontes, credenciais Amadeus opcionais,
            limites de consumo e instruções do agente. Defina{" "}
            <code className="font-mono text-slate-800">ADMIN_PASSCODE</code> nos Secrets do servidor.
          </p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <label className="block space-y-1 text-xs font-medium text-slate-700">
            <span>Código de acesso administrativo</span>
            <input
              type="password"
              required
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              placeholder="Digite o código administrativo"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          {authError && (
            <p className="text-xs font-medium text-[#B91C1C]">{authError}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-60 cursor-pointer"
          >
            {loading ? "Verificando..." : "Entrar na Administração"}
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-slate-900">
            Administração do Sistema
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Controle de consumo, especialidades ativas, fontes de dados e integridade técnica.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => void handleClearCache()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            Limpar Cache
          </button>
          <button
            type="button"
            onClick={() => {
              setToken(null);
              setData(null);
            }}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            Encerrar sessão
          </button>
        </div>
      </div>

      {/* Consumption Metrics */}
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Consultas IA (Hoje / Total)</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {data.usage.aiCallsToday} / {data.usage.aiCallsTotal}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Gemini API: {data.config.geminiConfigured ? "Configurada no servidor" : "Pendente em Secrets"}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Consultas Câmbio / Cache Hits</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {data.usage.fxCallsTotal} / {data.usage.fxCacheHits}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Consultas Voos (Hoje / Total)</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {data.usage.flightCallsToday} / {data.usage.flightCallsTotal}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Bloqueios por Limite</p>
          <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
            {data.usage.rateLimitRejections}
          </p>
        </div>
      </section>

      <form onSubmit={handleSaveConfig} className="space-y-6">
        {/* Skills & Sources */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
            <h3 className="text-base font-semibold text-slate-900">Especialidades Ativas</h3>
            <div className="space-y-2.5">
              {Object.entries(SKILL_LABELS).map(([key, label]) => (
                <label key={key} className="flex items-center justify-between text-xs text-slate-800 cursor-pointer">
                  <span>{label}</span>
                  <input
                    type="checkbox"
                    checked={Boolean(data.config.skillsEnabled[key])}
                    onChange={(e) =>
                      setData({
                        ...data,
                        config: {
                          ...data.config,
                          skillsEnabled: {
                            ...data.config.skillsEnabled,
                            [key]: e.target.checked,
                          },
                        },
                      })
                    }
                    className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
                  />
                </label>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
            <h3 className="text-base font-semibold text-slate-900">Fontes de Dados & Limites</h3>
            <div className="space-y-2 text-xs">
              {[
                { key: "frankfurter", label: "Frankfurter API (BCE)" },
                { key: "bcbPtax", label: "Banco Central do Brasil (PTAX)" },
                { key: "bcbIndicators", label: "BCB Indicadores (Selic / IPCA)" },
                { key: "amadeus", label: "Amadeus Flight API (Opcional)" },
              ].map((src) => (
                <label key={src.key} className="flex items-center justify-between text-slate-800 cursor-pointer">
                  <span>{src.label}</span>
                  <input
                    type="checkbox"
                    checked={
                      data.config.sourcesEnabled[
                        src.key as keyof typeof data.config.sourcesEnabled
                      ]
                    }
                    onChange={(e) =>
                      setData({
                        ...data,
                        config: {
                          ...data.config,
                          sourcesEnabled: {
                            ...data.config.sourcesEnabled,
                            [src.key]: e.target.checked,
                          },
                        },
                      })
                    }
                    className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
                  />
                </label>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 border-t border-slate-200 pt-3">
              <label className="space-y-1 text-xs font-medium text-slate-700">
                <span>IA / hora por visitante</span>
                <input
                  type="number"
                  min="1"
                  value={data.config.limits.aiRequestsPerHourPerVisitor}
                  onChange={(e) =>
                    setData({
                      ...data,
                      config: {
                        ...data.config,
                        limits: {
                          ...data.config.limits,
                          aiRequestsPerHourPerVisitor: Number(e.target.value),
                        },
                      },
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono text-xs"
                />
              </label>
              <label className="space-y-1 text-xs font-medium text-slate-700">
                <span>IA / dia global</span>
                <input
                  type="number"
                  min="1"
                  value={data.config.limits.aiRequestsPerDayGlobal}
                  onChange={(e) =>
                    setData({
                      ...data,
                      config: {
                        ...data.config,
                        limits: {
                          ...data.config.limits,
                          aiRequestsPerDayGlobal: Number(e.target.value),
                        },
                      },
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono text-xs"
                />
              </label>
              <label className="space-y-1 text-xs font-medium text-slate-700">
                <span>Cache Câmbio (min)</span>
                <input
                  type="number"
                  min="1"
                  value={data.config.limits.fxCacheTtlMinutes}
                  onChange={(e) =>
                    setData({
                      ...data,
                      config: {
                        ...data.config,
                        limits: {
                          ...data.config.limits,
                          fxCacheTtlMinutes: Number(e.target.value),
                        },
                      },
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono text-xs"
                />
              </label>
              <label className="space-y-1 text-xs font-medium text-slate-700">
                <span>Voos / dia global</span>
                <input
                  type="number"
                  min="0"
                  value={data.config.limits.flightRequestsPerDayGlobal}
                  onChange={(e) =>
                    setData({
                      ...data,
                      config: {
                        ...data.config,
                        limits: {
                          ...data.config.limits,
                          flightRequestsPerDayGlobal: Number(e.target.value),
                        },
                      },
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono text-xs"
                />
              </label>
            </div>
          </div>
        </section>

        {/* Optional Amadeus Credentials (Server-side only) */}
        <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
          <div className="flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-[#1D4ED8]" aria-hidden="true" />
            <h3 className="text-base font-semibold text-slate-900">
              Credenciais Opcionais Amadeus (Somente Servidor)
            </h3>
          </div>
          <p className="text-xs text-slate-600">
            Preencha apenas se possuir conta gratuita/autorizada na Amadeus for Developers. Sem
            essas credenciais, o módulo de passagens exibe links oficiais sem custos.
          </p>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Amadeus Client ID</span>
              <input
                type="text"
                value={amadeusIdInput}
                onChange={(e) => setAmadeusIdInput(e.target.value)}
                placeholder="Opcional"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs"
              />
            </label>
            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Amadeus Client Secret</span>
              <input
                type="password"
                value={amadeusSecretInput}
                onChange={(e) => setAmadeusSecretInput(e.target.value)}
                placeholder="Opcional"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-xs"
              />
            </label>
            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Ambiente</span>
              <select
                value={data.config.amadeus.environment}
                onChange={(e) =>
                  setData({
                    ...data,
                    config: {
                      ...data.config,
                      amadeus: {
                        ...data.config.amadeus,
                        environment: e.target.value as "test" | "production",
                      },
                    },
                  })
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs"
              >
                <option value="test">Sandbox / Teste Gratuito</option>
                <option value="production">Produção</option>
              </select>
            </label>
          </div>
        </section>

        {/* Agent Instructions */}
        <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
          <h3 className="text-base font-semibold text-slate-900">
            Instruções Adicionais do Agente de IA
          </h3>
          <textarea
            rows={3}
            value={data.config.agentInstructions}
            onChange={(e) =>
              setData({
                ...data,
                config: { ...data.config, agentInstructions: e.target.value },
              })
            }
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
          />

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            {saveFeedback ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#15803D]">
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                {saveFeedback}
              </span>
            ) : (
              <span className="text-xs text-slate-500">Alterações aplicadas imediatamente no servidor.</span>
            )}
            <button
              type="submit"
              disabled={loading}
              className="rounded-lg bg-[#1D4ED8] px-5 py-2 text-sm font-medium text-white hover:bg-[#1E40AF] cursor-pointer"
            >
              Salvar configurações administrativas
            </button>
          </div>
        </section>
      </form>

      {/* Technical Error Log */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 text-slate-600" aria-hidden="true" />
          <h3 className="text-base font-semibold text-slate-900">
            Registro Técnico de Falhas (sem dados pessoais)
          </h3>
        </div>
        {data.errors.length === 0 ? (
          <p className="text-xs text-slate-500">Nenhuma falha técnica registrada nesta execução.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 pr-4 font-medium">Data/Hora</th>
                  <th className="py-2 pr-4 font-medium">Módulo</th>
                  <th className="py-2 font-medium">Detalhe Técnico</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.errors.map((err) => (
                  <tr key={err.id}>
                    <td className="py-2 pr-4 font-mono text-slate-500">
                      {new Date(err.timestamp).toLocaleString("pt-BR")}
                    </td>
                    <td className="py-2 pr-4 font-mono text-slate-800">{err.scope}</td>
                    <td className="py-2 text-slate-600">{err.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
