import { useState } from "react";
import { Lock, MessageSquare, Send, Shield, Trash2 } from "lucide-react";
import type { ChatMessage, FxOverview, PurchaseEntry, UserProfile } from "../types/madrid";
import { buildFinancialReport } from "../utils/calculations";
import { getOrCreateVisitorId } from "../utils/storage";

interface AssistantSectionProps {
  profile: UserProfile;
  purchases: PurchaseEntry[];
  fx: FxOverview | null;
  chatHistory: ChatMessage[];
  onUpdateChatHistory: (next: ChatMessage[]) => void;
  aiConsent: boolean;
  onUpdateAiConsent: (consented: boolean) => void;
  maxChars: number;
}

const EXAMPLE_PROMPTS = [
  "O euro caiu hoje?",
  "Vale a pena comprar euros agora?",
  "Quanto preciso economizar por mês?",
  "Quanto vou gastar para comprar €500 pela Wise?",
  "Encontre passagens de São Paulo para Madrid.",
  "Qual foi a melhor cotação dos últimos 30 dias?",
  "Faça meu relatório financeiro da semana.",
];

export function AssistantSection({
  profile,
  purchases,
  fx,
  chatHistory,
  onUpdateChatHistory,
  aiConsent,
  onUpdateAiConsent,
  maxChars,
}: AssistantSectionProps) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [consentDecisionMade, setConsentDecisionMade] = useState<boolean>(aiConsent);
  const [quotaInfo, setQuotaInfo] = useState<string | null>(null);

  const report = buildFinancialReport(profile, purchases, fx);

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || loading) return;

    setErrorMsg(null);
    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      text: trimmed.slice(0, maxChars),
      timestamp: new Date().toISOString(),
    };

    const updatedWithUser = [...chatHistory, userMsg];
    onUpdateChatHistory(updatedWithUser);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-visitor-id": getOrCreateVisitorId(),
        },
        body: JSON.stringify({
          message: userMsg.text,
          history: chatHistory.slice(-10).map((m) => ({ role: m.role, text: m.text })),
          userContext: aiConsent
            ? {
                consented: true,
                nickname: profile.nickname,
                originCurrency: profile.originCurrency,
                destinationCountry: profile.destinationCountry,
                tripDate: profile.tripDate,
                returnDate: profile.returnDate || "",
                totalBudgetBrl: profile.totalBudgetBrl,
                alreadySavedBrl: profile.alreadySavedBrl,
                alreadyAccumulatedEur: profile.alreadyAccumulatedEur,
                emergencyReserveBrl: profile.emergencyReserveBrl,
                targetRate: profile.targetRate,
                monthlyAvailableBrl: profile.monthlyAvailableBrl,
                purchasesCount: purchases.length,
                averageEurCostBrl: report.weightedAverageEurCost,
              }
            : { consented: false },
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "Não foi possível obter resposta do assistente.");
      } else {
        const assistantMsg: ChatMessage = {
          id: crypto.randomUUID(),
          role: "assistant",
          text: data.text,
          timestamp: data.updatedAt || new Date().toISOString(),
          skillsUsed: data.skillsUsed || [],
          sourcesCited: data.sourcesCited || [],
        };
        onUpdateChatHistory([...updatedWithUser, assistantMsg]);
        if (typeof data.visitorRateLimitRemaining === "number") {
          setQuotaInfo(`Consultas restantes nesta hora: ${data.visitorRateLimitRemaining}`);
        }
      }
    } catch {
      setErrorMsg("Falha de conexão ao consultar o assistente no servidor.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void sendMessage(input);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-slate-900">
            Assistente Financeiro Inteligente
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Pergunte em linguagem natural sobre câmbio, economia, cálculos na Wise, metas ou
            passagens.
          </p>
        </div>

        {chatHistory.length > 0 && (
          <button
            type="button"
            onClick={() => onUpdateChatHistory([])}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
            Limpar conversa local
          </button>
        )}
      </div>

      {/* Explicit Privacy & AI Data Processing Consent Card */}
      <section className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl space-y-1.5">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Shield className="h-4 w-4 text-[#1D4ED8]" aria-hidden="true" />
              <span>Privacidade e Processamento no Modelo de IA</span>
            </div>
            <p className="text-xs leading-relaxed text-slate-600">
              Antes de enviar seu planejamento ao modelo Gemini (executado com chave segura apenas
              no servidor), escolha se deseja incluir seus parâmetros de meta e orçamento. Nenhuma
              chave, conta bancária ou dado sensível desnecessário é enviado ou gravado em logs.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onUpdateAiConsent(true);
                setConsentDecisionMade(true);
              }}
              className={`rounded-lg px-3.5 py-2 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
                aiConsent
                  ? "bg-[#1D4ED8] text-white"
                  : "border border-slate-300 bg-white text-slate-800 hover:bg-slate-50"
              }`}
            >
              {aiConsent ? "Contexto de metas autorizado" : "Autorizar contexto de metas"}
            </button>
            <button
              type="button"
              onClick={() => {
                onUpdateAiConsent(false);
                setConsentDecisionMade(true);
              }}
              className={`rounded-lg px-3.5 py-2 text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer ${
                consentDecisionMade && !aiConsent
                  ? "bg-slate-900 text-white"
                  : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
              }`}
            >
              Usar sem dados pessoais
            </button>
          </div>
        </div>
      </section>

      {/* Main Chat Container */}
      <section className="flex flex-col rounded-xl border border-slate-200 bg-white">
        {/* Quick Prompt Examples */}
        <div className="border-b border-slate-200 p-4">
          <p className="mb-2.5 text-xs font-medium text-slate-500">Sugestões rápidas</p>
          <div className="flex flex-wrap gap-2">
            {EXAMPLE_PROMPTS.map((q) => (
              <button
                key={q}
                type="button"
                disabled={loading}
                onClick={() => {
                  if (!consentDecisionMade) setConsentDecisionMade(true);
                  void sendMessage(q);
                }}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 transition-colors hover:border-[#1D4ED8] hover:bg-white hover:text-[#1D4ED8] disabled:opacity-50 cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Messages Feed */}
        <div className="min-h-80 max-h-[520px] space-y-4 overflow-y-auto p-5">
          {chatHistory.length === 0 ? (
            <div className="flex h-64 flex-col items-center justify-center text-center">
              <MessageSquare className="h-8 w-8 text-slate-300" aria-hidden="true" />
              <p className="mt-3 text-sm font-medium text-slate-700">
                Pronto para ajudar com suas finanças de viagem
              </p>
              <p className="mt-1 max-w-md text-xs text-slate-500">
                Escolha uma das sugestões acima ou digite sua pergunta abaixo. As respostas
                identificam a fonte e a data de atualização dos dados consultados.
              </p>
            </div>
          ) : (
            chatHistory.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === "user" ? "items-end" : "items-start"
                }`}
              >
                <div
                  className={`max-w-3xl rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-[#1D4ED8] text-white"
                      : "border border-slate-200 bg-slate-50 text-slate-900"
                  }`}
                >
                  {msg.text}
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                  <span className="font-mono">
                    {new Date(msg.timestamp).toLocaleTimeString("pt-BR", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                  {msg.skillsUsed && msg.skillsUsed.length > 0 && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>Especialidades: {msg.skillsUsed.join(", ")}</span>
                    </>
                  )}
                  {msg.sourcesCited && msg.sourcesCited.length > 0 && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>Fontes: {msg.sourcesCited.join(" / ")}</span>
                    </>
                  )}
                </div>
              </div>
            ))
          )}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-[#1D4ED8]" />
              <span>Consultando dados reais e formulando resposta...</span>
            </div>
          )}
        </div>

        {errorMsg && (
          <div className="mx-5 mb-3 rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-xs text-[#B91C1C]">
            {errorMsg}
          </div>
        )}

        {/* Composer */}
        <form onSubmit={handleSubmit} className="border-t border-slate-200 p-4">
          <div className="flex flex-col gap-2 sm:flex-row">
            <input
              type="text"
              value={input}
              maxLength={maxChars}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Pergunte sobre câmbio, Wise, metas mensais ou passagens..."
              className="flex-1 rounded-lg border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#1E40AF] disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Send className="h-4 w-4" aria-hidden="true" />
              Enviar
            </button>
          </div>
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
            <span className="inline-flex items-center gap-1">
              <Lock className="h-3 w-3" aria-hidden="true" />
              Processamento informativo via servidor; não substitui aconselhamento financeiro
              profissional.
            </span>
            <span className="font-mono tabular-nums">
              {quotaInfo || `${input.length}/${maxChars} caracteres`}
            </span>
          </div>
        </form>
      </section>
    </div>
  );
}
