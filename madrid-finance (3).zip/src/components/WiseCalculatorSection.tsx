import { useMemo, useState } from "react";
import { Calculator, CheckCircle2, Info, PlusCircle } from "lucide-react";
import type { FxOverview, PurchaseEntry } from "../types/madrid";
import { computeWiseLocal } from "../utils/calculations";

interface WiseCalculatorSectionProps {
  fx: FxOverview | null;
  onAddPurchase: (entry: PurchaseEntry) => void;
}

export function WiseCalculatorSection({ fx, onAddPurchase }: WiseCalculatorSectionProps) {
  const referenceRate = fx?.latestRate || 6.15;
  const [operationType, setOperationType] = useState<"simulation" | "actual">("simulation");
  const [mode, setMode] = useState<"buy_target" | "spend_source">("buy_target");
  const [amount, setAmount] = useState<number>(500);
  const [useCustomRate, setUseCustomRate] = useState<boolean>(false);
  const [customRate, setCustomRate] = useState<number>(Number(referenceRate.toFixed(4)));
  const [platformFeePercent, setPlatformFeePercent] = useState<number>(1.15);
  const [fixedFeeBrl, setFixedFeeBrl] = useState<number>(0);
  const [iofPercent, setIofPercent] = useState<number>(1.1);
  const [platformName, setPlatformName] = useState<string>("Wise");
  const [operationDate, setOperationDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [operationNote, setOperationNote] = useState<string>("");
  const [savedFeedback, setSavedFeedback] = useState<string | null>(null);

  const effectiveInputRate = useCustomRate ? customRate : referenceRate;

  const result = useMemo(
    () =>
      computeWiseLocal({
        mode,
        amount,
        exchangeRate: effectiveInputRate,
        platformFeePercent,
        fixedFeeBrl,
        iofPercent,
      }),
    [mode, amount, effectiveInputRate, platformFeePercent, fixedFeeBrl, iofPercent]
  );

  const handleSaveRealOperation = (e: React.FormEvent) => {
    e.preventDefault();
    if (result.eurReceived <= 0 || result.brlDebited <= 0) return;

    const entry: PurchaseEntry = {
      id: crypto.randomUUID(),
      date: operationDate,
      eurBought: Number(result.eurReceived.toFixed(2)),
      brlSpent: Number(result.brlDebited.toFixed(2)),
      exchangeRate: Number(result.exchangeRateUsed.toFixed(4)),
      feesAndIofBrl: Number(result.totalFeesBrl.toFixed(2)),
      effectiveCostPerEur: Number(result.effectiveCostPerEur.toFixed(4)),
      platform: platformName.trim() || "Wise",
      note: operationNote.trim() || "Operação registrada manualmente",
    };

    onAddPurchase(entry);
    setOperationNote("");
    setSavedFeedback(
      `Operação real registrada no relatório: € ${entry.eurBought.toFixed(2)} por R$ ${entry.brlSpent.toFixed(2)} (custo efetivo R$ ${entry.effectiveCostPerEur.toFixed(4)}/EUR).`
    );
    setTimeout(() => setSavedFeedback(null), 6000);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-slate-900">
            Calculadora Wise & Conversão
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Simule o custo efetivo por euro com taxa de serviço e IOF, ou registre uma operação real
            já realizada.
          </p>
        </div>

        <div className="inline-flex items-center gap-1 rounded-lg bg-slate-100 p-1" role="group" aria-label="Tipo de cálculo">
          <button
            type="button"
            onClick={() => setOperationType("simulation")}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              operationType === "simulation"
                ? "bg-white text-slate-900 shadow-xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Simulação Estimada
          </button>
          <button
            type="button"
            onClick={() => {
              setOperationType("actual");
              setUseCustomRate(true);
            }}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              operationType === "actual"
                ? "bg-white text-slate-900 shadow-xs"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Operação Realizada
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Input Form */}
        <form
          onSubmit={handleSaveRealOperation}
          className="space-y-5 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-7"
        >
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Calculator className="h-4 w-4 text-[#1D4ED8]" aria-hidden="true" />
              <span>
                {operationType === "simulation"
                  ? "Parâmetros da Simulação"
                  : "Dados da Operação Realizada"}
              </span>
            </div>
            <span className="text-xs text-slate-500">
              {operationType === "simulation" ? "Apenas simulação" : "Registro manual no navegador"}
            </span>
          </div>

          <div className="inline-flex items-center gap-1 rounded-lg bg-slate-100 p-1">
            <button
              type="button"
              onClick={() => {
                setMode("buy_target");
                if (amount > 2000) setAmount(500);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 cursor-pointer ${
                mode === "buy_target" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600"
              }`}
            >
              Quero receber em Euros (€)
            </button>
            <button
              type="button"
              onClick={() => {
                setMode("spend_source");
                if (amount < 1000) setAmount(3000);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 cursor-pointer ${
                mode === "spend_source" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600"
              }`}
            >
              Quero gastar em Reais (R$)
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>{mode === "buy_target" ? "Valor desejado (€ EUR)" : "Valor total a debitar (R$ BRL)"}</span>
              <input
                type="number"
                min="1"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <div className="space-y-1 text-xs font-medium text-slate-700">
              <div className="flex items-center justify-between">
                <span>Taxa de câmbio (EUR/BRL)</span>
                <button
                  type="button"
                  onClick={() => {
                    const next = !useCustomRate;
                    setUseCustomRate(next);
                    if (next) setCustomRate(Number(referenceRate.toFixed(4)));
                  }}
                  className="text-[11px] font-medium text-[#1D4ED8] hover:underline cursor-pointer"
                >
                  {useCustomRate ? "Usar referência atual" : "Inserir cotação manual"}
                </button>
              </div>
              <input
                type="number"
                min="0.1"
                step="0.0001"
                disabled={!useCustomRate}
                value={useCustomRate ? customRate : Number(referenceRate.toFixed(4))}
                onChange={(e) => setCustomRate(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 disabled:bg-slate-50 disabled:text-slate-600 focus:border-[#1D4ED8] focus:outline-none"
              />
            </div>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Taxa estimada da plataforma (%)</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={platformFeePercent}
                onChange={(e) => setPlatformFeePercent(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Tarifa fixa adicional (R$)</span>
              <input
                type="number"
                min="0"
                step="0.01"
                value={fixedFeeBrl}
                onChange={(e) => setFixedFeeBrl(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <div className="space-y-1 text-xs font-medium text-slate-700 sm:col-span-2">
              <span>IOF informado (%)</span>
              <div className="flex flex-wrap items-center gap-2">
                {[
                  { label: "1,1% (Mesma titularidade / Conta global)", val: 1.1 },
                  { label: "0,38% (Outra titularidade)", val: 0.38 },
                  { label: "4,38% (Cartão internacional)", val: 4.38 },
                ].map((preset) => (
                  <button
                    key={preset.val}
                    type="button"
                    onClick={() => setIofPercent(preset.val)}
                    className={`rounded-lg border px-2.5 py-1.5 text-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      iofPercent === preset.val
                        ? "border-[#1D4ED8] bg-[#1D4ED8]/5 font-semibold text-[#1D4ED8]"
                        : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  aria-label="IOF personalizado em porcentagem"
                  value={iofPercent}
                  onChange={(e) => setIofPercent(Number(e.target.value))}
                  className="w-24 rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
                />
              </div>
            </div>

            {operationType === "actual" && (
              <>
                <label className="space-y-1 text-xs font-medium text-slate-700">
                  <span>Plataforma utilizada</span>
                  <input
                    type="text"
                    value={platformName}
                    onChange={(e) => setPlatformName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
                  />
                </label>

                <label className="space-y-1 text-xs font-medium text-slate-700">
                  <span>Data da operação</span>
                  <input
                    type="date"
                    value={operationDate}
                    onChange={(e) => setOperationDate(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
                  />
                </label>

                <label className="space-y-1 text-xs font-medium text-slate-700 sm:col-span-2">
                  <span>Observação (opcional)</span>
                  <input
                    type="text"
                    value={operationNote}
                    onChange={(e) => setOperationNote(e.target.value)}
                    placeholder="Ex: Aporte mensal de novembro via Pix"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
                  />
                </label>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4">
            <p className="text-xs text-slate-500">
              {useCustomRate
                ? "Usando cotação inserida manualmente."
                : `Usando referência Frankfurter/BCE (${fx?.observationDate || "atual"}).`}
            </p>
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-medium text-white hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
            >
              <PlusCircle className="h-4 w-4" aria-hidden="true" />
              {operationType === "actual"
                ? "Salvar operação real no relatório"
                : "Registrar esta conversão como compra realizada"}
            </button>
          </div>

          {savedFeedback && (
            <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-xs font-medium text-[#15803D]">
              <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>{savedFeedback}</span>
            </div>
          )}
        </form>

        {/* Results Summary Panel */}
        <aside className="flex flex-col justify-between space-y-5 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-5">
          <div className="space-y-5">
            <div className="border-b border-slate-200 pb-3">
              <p className="text-xs font-medium text-slate-500">
                {operationType === "simulation" ? "Resultado da Simulação" : "Resumo da Operação Real"}
              </p>
              <p className="mt-1 font-mono text-3xl font-semibold text-slate-900 tabular-nums">
                R$ {result.effectiveCostPerEur.toFixed(4)}
                <span className="ml-1.5 text-sm font-normal text-slate-500">/ EUR efetivo</span>
              </p>
            </div>

            <dl className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">Valor recebido em euros</dt>
                <dd className="font-mono font-semibold text-slate-900 tabular-nums">
                  € {result.eurReceived.toFixed(2)}
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">Taxa de câmbio aplicada</dt>
                <dd className="font-mono text-slate-900 tabular-nums">
                  R$ {result.exchangeRateUsed.toFixed(4)}
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">Taxa da plataforma ({platformFeePercent}%)</dt>
                <dd className="font-mono text-slate-900 tabular-nums">
                  R$ {result.platformFeeBrl.toFixed(2)}
                </dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-slate-600">IOF informado ({iofPercent}%)</dt>
                <dd className="font-mono text-slate-900 tabular-nums">
                  R$ {result.iofBrl.toFixed(2)}
                </dd>
              </div>
              <div className="flex items-center justify-between border-t border-slate-200 pt-3">
                <dt className="font-semibold text-slate-900">Custo total debitado em reais</dt>
                <dd className="font-mono text-lg font-semibold text-[#1D4ED8] tabular-nums">
                  R$ {result.brlDebited.toFixed(2)}
                </dd>
              </div>
            </dl>

            <div className="rounded-lg bg-slate-50 p-3.5 text-xs text-slate-700 space-y-1.5">
              <p className="font-semibold text-slate-900">Memória de cálculo</p>
              <p className="font-mono text-[11px] leading-relaxed tabular-nums">
                Custo efetivo = R$ {result.brlDebited.toFixed(2)} ÷ € {result.eurReceived.toFixed(2)} ={" "}
                <strong>R$ {result.effectiveCostPerEur.toFixed(4)}</strong> (+{result.spreadPct.toFixed(2)}%
                sobre a taxa pura).
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2 rounded-lg border border-slate-200 bg-slate-50/70 p-3 text-xs text-slate-600">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-slate-500" aria-hidden="true" />
            <span>
              Simulação independente. O Madrid Finance não possui acesso à sua conta Wise e não
              executa transações financeiras.
            </span>
          </div>
        </aside>
      </div>
    </div>
  );
}
