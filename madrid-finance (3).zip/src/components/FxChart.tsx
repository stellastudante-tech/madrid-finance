import { useMemo, useState } from "react";
import type { FxPoint } from "../types/madrid";

interface FxChartProps {
  points: FxPoint[];
  base: string;
  target: string;
  targetRate: number | null;
}

export function FxChart({ points, base, target, targetRate }: FxChartProps) {
  const [range, setRange] = useState<7 | 30 | 90>(30);
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const sliced = useMemo(() => {
    if (!points.length) return [];
    const cutoff = new Date(Date.now() - range * 86400_000).toISOString().slice(0, 10);
    const filtered = points.filter((p) => p.date >= cutoff);
    return filtered.length >= 2 ? filtered : points.slice(-Math.min(points.length, range));
  }, [points, range]);

  const { minVal, maxVal, avgVal, pathD, areaD, coords, targetY } = useMemo(() => {
    if (!sliced.length) {
      return {
        minVal: 0,
        maxVal: 0,
        avgVal: 0,
        pathD: "",
        areaD: "",
        coords: [] as Array<{ x: number; y: number; point: FxPoint }>,
        targetY: null as number | null,
      };
    }

    const rates = sliced.map((p) => p.rate);
    const min = Math.min(...rates);
    const max = Math.max(...rates);
    const avg = rates.reduce((a, b) => a + b, 0) / rates.length;

    const padMin = targetRate && targetRate > 0 ? Math.min(min, targetRate) : min;
    const padMax = targetRate && targetRate > 0 ? Math.max(max, targetRate) : max;
    const span = Math.max(0.01, padMax - padMin);
    const yMin = padMin - span * 0.12;
    const yMax = padMax + span * 0.12;

    const width = 680;
    const height = 220;
    const padX = 12;
    const padY = 16;

    const mapX = (idx: number) =>
      sliced.length === 1
        ? width / 2
        : padX + (idx / (sliced.length - 1)) * (width - padX * 2);
    const mapY = (val: number) =>
      height - padY - ((val - yMin) / Math.max(0.0001, yMax - yMin)) * (height - padY * 2);

    const mapped = sliced.map((point, idx) => ({
      x: mapX(idx),
      y: mapY(point.rate),
      point,
    }));

    const d = mapped
      .map((c, idx) => `${idx === 0 ? "M" : "L"} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
      .join(" ");

    const area =
      mapped.length > 0
        ? `${d} L ${mapped[mapped.length - 1].x.toFixed(1)} ${height - padY} L ${mapped[0].x.toFixed(
            1
          )} ${height - padY} Z`
        : "";

    const tY =
      targetRate && targetRate > 0 && targetRate >= yMin && targetRate <= yMax
        ? mapY(targetRate)
        : null;

    return {
      minVal: min,
      maxVal: max,
      avgVal: avg,
      pathD: d,
      areaD: area,
      coords: mapped,
      targetY: tY,
    };
  }, [sliced, targetRate]);

  const activePoint =
    hoverIdx !== null && coords[hoverIdx] ? coords[hoverIdx] : coords[coords.length - 1] || null;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
          {activePoint ? (
            <>
              <span className="font-mono font-semibold text-slate-900 tabular-nums">
                1 {base} = {activePoint.point.rate.toFixed(4)} {target}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{activePoint.point.date}</span>
            </>
          ) : (
            <span>Sem série histórica disponível</span>
          )}
        </div>

        <div className="inline-flex items-center gap-1 rounded-lg bg-slate-100 p-1" role="group" aria-label="Período do gráfico">
          {([7, 30, 90] as const).map((days) => (
            <button
              key={days}
              type="button"
              onClick={() => setRange(days)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                range === days
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {days} dias
            </button>
          ))}
        </div>
      </div>

      {coords.length < 2 ? (
        <div className="flex h-56 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-sm text-slate-500">
          Histórico insuficiente para traçar gráfico neste momento.
        </div>
      ) : (
        <div className="relative rounded-lg border border-slate-200 bg-slate-50/60 p-3">
          <svg
            viewBox="0 0 680 220"
            className="h-56 w-full overflow-visible"
            role="img"
            aria-label={`Gráfico histórico de ${base}/${target} nos últimos ${range} dias`}
            onMouseLeave={() => setHoverIdx(null)}
          >
            <defs>
              <linearGradient id="fxAreaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1D4ED8" stopOpacity="0.16" />
                <stop offset="100%" stopColor="#1D4ED8" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Horizontal subtle grid lines */}
            {[40, 110, 180].map((yLine) => (
              <line
                key={yLine}
                x1="12"
                y1={yLine}
                x2="668"
                y2={yLine}
                stroke="#E2E8F0"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
            ))}

            {/* Target Rate line */}
            {targetY !== null && targetRate && (
              <g>
                <line
                  x1="12"
                  y1={targetY}
                  x2="668"
                  y2={targetY}
                  stroke="#15803D"
                  strokeDasharray="5 4"
                  strokeWidth="1.5"
                />
                <text
                  x="664"
                  y={targetY - 6}
                  textAnchor="end"
                  className="fill-[#15803D] text-[10px] font-mono"
                >
                  Meta: {targetRate.toFixed(4)}
                </text>
              </g>
            )}

            <path d={areaD} fill="url(#fxAreaGrad)" />
            <path d={pathD} fill="none" stroke="#1D4ED8" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />

            {activePoint && (
              <g>
                <line
                  x1={activePoint.x}
                  y1="16"
                  x2={activePoint.x}
                  y2="204"
                  stroke="#94A3B8"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <circle
                  cx={activePoint.x}
                  cy={activePoint.y}
                  r="4.5"
                  fill="#1D4ED8"
                  stroke="#FFFFFF"
                  strokeWidth="2"
                />
              </g>
            )}

            {/* Interactive hit strips */}
            {coords.map((c, idx) => {
              const stripWidth = 656 / coords.length;
              return (
                <rect
                  key={c.point.date}
                  x={c.x - stripWidth / 2}
                  y="0"
                  width={Math.max(6, stripWidth)}
                  height="220"
                  fill="transparent"
                  onMouseEnter={() => setHoverIdx(idx)}
                  onClick={() => setHoverIdx(idx)}
                />
              );
            })}
          </svg>

          <div className="mt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-2.5 text-xs text-slate-600">
            <div className="flex flex-wrap items-center gap-4">
              <span>
                Mínima ({range}d):{" "}
                <strong className="font-mono font-semibold text-slate-900 tabular-nums">
                  {minVal.toFixed(4)}
                </strong>
              </span>
              <span>
                Média ({range}d):{" "}
                <strong className="font-mono font-semibold text-slate-900 tabular-nums">
                  {avgVal.toFixed(4)}
                </strong>
              </span>
              <span>
                Máxima ({range}d):{" "}
                <strong className="font-mono font-semibold text-slate-900 tabular-nums">
                  {maxVal.toFixed(4)}
                </strong>
              </span>
            </div>
            <span className="text-slate-500">Passe o cursor ou toque no gráfico para inspecionar</span>
          </div>
        </div>
      )}
    </div>
  );
}
