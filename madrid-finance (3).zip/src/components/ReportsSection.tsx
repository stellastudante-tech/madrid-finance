import { Download, FileSpreadsheet, Trash2 } from "lucide-react";
import type { FxOverview, PurchaseEntry, UserProfile } from "../types/madrid";
import { buildFinancialReport, exportReportToCsv } from "../utils/calculations";

interface ReportsSectionProps {
  profile: UserProfile;
  purchases: PurchaseEntry[];
  onDeletePurchase: (id: string) => void;
  fx: FxOverview | null;
}

export function ReportsSection({
  profile,
  purchases,
  onDeletePurchase,
  fx,
}: ReportsSectionProps) {
  const report = buildFinancialReport(profile, purchases, fx);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-slate-900">
            Relatório Financeiro Individual
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Consolidado da sua evolução cambial, histórico de compras, custo médio e meta da viagem.
          </p>
        </div>

        <button
          type="button"
          onClick={() => exportReportToCsv(profile, purchases, report, fx)}
          className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2 text-sm font-medium text-white hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="h-4 w-4" aria-hidden="true" />
          Exportar CSV
        </button>
      </div>

      {/* Report KPI Grid */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Euros acumulados</p>
          <p className="mt-1 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            € {report.totalAccumulatedEur.toFixed(2)}
          </p>
          <p className="mt-1.5 text-xs text-slate-500 tabular-nums">
            Saldo inicial € {profile.alreadyAccumulatedEur.toFixed(2)} + € {report.totalEurFromPurchases.toFixed(2)} comprados
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Custo médio ponderado</p>
          <p className="mt-1 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {report.weightedAverageEurCost
              ? `R$ ${report.weightedAverageEurCost.toFixed(4)}`
              : "--"}
          </p>
          <p className="mt-1.5 text-xs text-slate-500">
            Inclui taxas e IOF das compras registradas
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Meta estimada / Falta</p>
          <p className="mt-1 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            € {report.remainingEurNeeded.toFixed(2)}
          </p>
          <p className="mt-1.5 text-xs text-slate-500 tabular-nums">
            Meta total € {report.estimatedGoalEur.toFixed(2)} (≈ R$ {report.remainingBrlEstimated.toFixed(2)} restantes)
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Evolução percentual</p>
          <p className="mt-1 font-mono text-2xl font-semibold text-[#15803D] tabular-nums">
            {report.progressPercent.toFixed(1)}%
          </p>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full bg-[#1D4ED8] transition-all"
              style={{ width: `${Math.min(100, report.progressPercent)}%` }}
            />
          </div>
        </div>
      </section>

      {/* Trip Timeline Strip */}
      {report.timeline.hasDepartureDate && (
        <section className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
            <h3 className="text-sm font-semibold text-slate-900">
              Cronograma da Viagem e Progresso Temporal
            </h3>
            <span className="font-mono text-xs text-slate-500">
              Ida: {profile.tripDate || "--"}
              {profile.returnDate ? ` · Volta: ${profile.returnDate}` : " · Volta não informada"}
            </span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div>
              <p className="text-xs text-slate-500">Duração total</p>
              <p className="mt-1 font-mono text-base font-semibold text-slate-900 tabular-nums">
                {report.timeline.hasReturnDate && report.timeline.isValidRange && report.timeline.durationDays !== null
                  ? `${report.timeline.durationDays}d (${report.timeline.durationMonths}m)`
                  : "Não informada"}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Dias até a ida</p>
              <p className="mt-1 font-mono text-base font-semibold text-slate-900 tabular-nums">
                {report.timeline.daysUntilDeparture !== null
                  ? report.timeline.daysUntilDeparture >= 0
                    ? `${report.timeline.daysUntilDeparture} dia(s)`
                    : "Já iniciada"
                  : "--"}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Dias até o retorno</p>
              <p className="mt-1 font-mono text-base font-semibold text-slate-900 tabular-nums">
                {report.timeline.hasReturnDate && report.timeline.isValidRange && report.timeline.daysUntilReturn !== null
                  ? report.timeline.daysUntilReturn >= 0
                    ? `${report.timeline.daysUntilReturn} dia(s)`
                    : "Concluída"
                  : "Não informada"}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Progresso temporal</p>
              <p className="mt-1 font-mono text-base font-semibold text-[#1D4ED8] tabular-nums">
                {report.timeline.temporalProgressPercent !== null
                  ? `${report.timeline.temporalProgressPercent.toFixed(1)}%`
                  : "Aguardando volta"}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* FX Context & Recommendations */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-5">
          <h3 className="text-base font-semibold text-slate-900">Evolução Cambial de Referência</h3>
          <dl className="space-y-2.5 text-xs">
            <div className="flex justify-between border-b border-slate-100 pb-2">
              <dt className="text-slate-600">Cotação atual ({fx?.base || "EUR"}/{fx?.target || "BRL"})</dt>
              <dd className="font-mono font-semibold text-slate-900 tabular-nums">
                {fx?.latestRate ? fx.latestRate.toFixed(4) : "Indisponível"}
              </dd>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-2">
              <dt className="text-slate-600">Média 7 dias</dt>
              <dd className="font-mono text-slate-900 tabular-nums">
                {fx?.stats.avg7d ? fx.stats.avg7d.toFixed(4) : "--"}
              </dd>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-2">
              <dt className="text-slate-600">Média 30 dias</dt>
              <dd className="font-mono text-slate-900 tabular-nums">
                {fx?.stats.avg30d ? fx.stats.avg30d.toFixed(4) : "--"}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-600">Fonte & Data</dt>
              <dd className="font-mono text-slate-700">
                Frankfurter · {fx?.observationDate || "--"}
              </dd>
            </div>
          </dl>
        </div>

        <div className="space-y-3 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-7">
          <h3 className="text-base font-semibold text-slate-900">
            Recomendações para o Período Seguinte
          </h3>
          <ul className="space-y-2.5 text-sm leading-relaxed text-slate-700">
            {report.recommendations.map((rec, idx) => (
              <li key={idx} className="rounded-lg bg-slate-50 px-4 py-2.5 text-xs">
                {rec}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Purchase Ledger Table */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4 text-[#1D4ED8]" aria-hidden="true" />
            <h3 className="text-base font-semibold text-slate-900">
              Histórico de Compras de Moeda
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            Registros salvos apenas no seu navegador
          </span>
        </div>

        {purchases.length === 0 ? (
          <div className="rounded-lg border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">
            Você ainda não registrou compras reais. Use a <strong>Calculadora Wise</strong> e clique
            em <em>"Salvar operação real no relatório"</em> para acompanhar seu custo médio.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 pr-4 font-medium">Data</th>
                  <th className="py-2 pr-4 font-medium">Plataforma</th>
                  <th className="py-2 pr-4 font-medium text-right">EUR recebidos</th>
                  <th className="py-2 pr-4 font-medium text-right">Taxa câmbio</th>
                  <th className="py-2 pr-4 font-medium text-right">Taxas + IOF</th>
                  <th className="py-2 pr-4 font-medium text-right">Total debitado</th>
                  <th className="py-2 pr-4 font-medium text-right">Custo efetivo/EUR</th>
                  <th className="py-2 pr-4 font-medium">Observação</th>
                  <th className="py-2 text-right font-medium">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {purchases.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 pr-4 font-mono text-slate-600">{p.date}</td>
                    <td className="py-2.5 pr-4 font-medium text-slate-900">{p.platform}</td>
                    <td className="py-2.5 pr-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      € {p.eurBought.toFixed(2)}
                    </td>
                    <td className="py-2.5 pr-4 text-right font-mono text-slate-700 tabular-nums">
                      {p.exchangeRate.toFixed(4)}
                    </td>
                    <td className="py-2.5 pr-4 text-right font-mono text-slate-600 tabular-nums">
                      R$ {p.feesAndIofBrl.toFixed(2)}
                    </td>
                    <td className="py-2.5 pr-4 text-right font-mono text-slate-900 tabular-nums">
                      R$ {p.brlSpent.toFixed(2)}
                    </td>
                    <td className="py-2.5 pr-4 text-right font-mono font-semibold text-[#1D4ED8] tabular-nums">
                      R$ {p.effectiveCostPerEur.toFixed(4)}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-600">{p.note}</td>
                    <td className="py-2.5 text-right">
                      <button
                        type="button"
                        aria-label="Excluir compra"
                        onClick={() => onDeletePurchase(p.id)}
                        className="text-slate-400 hover:text-[#B91C1C] cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
