import { useState } from "react";
import { AlertCircle, CheckCircle2, Info, RefreshCw, TrendingDown, TrendingUp } from "lucide-react";
import type {
  EconomicIntelligenceResponse,
  FxOverview,
  OpportunityAnalysis,
  UserProfile,
} from "../types/madrid";
import { FxChart } from "./FxChart";

interface FxDashboardSectionProps {
  profile: UserProfile;
  onUpdateProfile: (next: UserProfile) => void;
  fx: FxOverview | null;
  fxLoading: boolean;
  radar: OpportunityAnalysis | null;
  economics: EconomicIntelligenceResponse | null;
  onRefreshFx: (base: string, target: string, targetRate: number | null) => void;
}

export function FxDashboardSection({
  profile,
  onUpdateProfile,
  fx,
  fxLoading,
  radar,
  economics,
  onRefreshFx,
}: FxDashboardSectionProps) {
  const [base, setBase] = useState(profile.trackedPairBase || "EUR");
  const [target, setTarget] = useState(profile.trackedPairTarget || "BRL");
  const [targetRateInput, setTargetRateInput] = useState(
    profile.targetRate ? String(profile.targetRate) : ""
  );

  const handlePairChange = (nextBase: string, nextTarget: string) => {
    setBase(nextBase);
    setTarget(nextTarget);
    const parsedTarget = targetRateInput ? Number(targetRateInput) : null;
    onUpdateProfile({
      ...profile,
      trackedPairBase: nextBase,
      trackedPairTarget: nextTarget,
    });
    onRefreshFx(nextBase, nextTarget, parsedTarget);
  };

  const handleApplyTarget = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = targetRateInput ? Number(targetRateInput) : null;
    const valid = parsed && Number.isFinite(parsed) && parsed > 0 ? parsed : null;
    onUpdateProfile({ ...profile, targetRate: valid });
    onRefreshFx(base, target, valid);
  };

  const classificationStyle = (c?: OpportunityAnalysis["classification"]) => {
    switch (c) {
      case "Excelente oportunidade":
        return { text: "text-[#15803D]", bg: "bg-emerald-50 border-emerald-200", icon: CheckCircle2 };
      case "Boa oportunidade":
        return { text: "text-[#15803D]", bg: "bg-emerald-50/60 border-emerald-200", icon: CheckCircle2 };
      case "Oportunidade neutra":
        return { text: "text-[#B45309]", bg: "bg-amber-50 border-amber-200", icon: Info };
      case "Momento desfavorável":
        return { text: "text-[#B91C1C]", bg: "bg-red-50 border-red-200", icon: AlertCircle };
      default:
        return { text: "text-slate-700", bg: "bg-slate-50 border-slate-200", icon: Info };
    }
  };

  const radarUi = classificationStyle(radar?.classification);
  const RadarIcon = radarUi.icon;

  return (
    <div className="space-y-8">
      {/* Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-semibold text-slate-900">
            Monitoramento Cambial & Radar
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Acompanhe cotações de referência, histórico de até 90 dias e sinais de oportunidade.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Moeda acompanhada"
            value={base}
            onChange={(e) => handlePairChange(e.target.value, target)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
          >
            <option value="EUR">EUR (Euro)</option>
            <option value="USD">USD (Dólar)</option>
            <option value="GBP">GBP (Libra)</option>
            <option value="CHF">CHF (Franco Suíço)</option>
          </select>
          <span className="text-xs text-slate-500">para</span>
          <select
            aria-label="Moeda de origem"
            value={target}
            onChange={(e) => handlePairChange(base, e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
          >
            <option value="BRL">BRL (Real)</option>
            <option value="USD">USD (Dólar)</option>
            <option value="EUR">EUR (Euro)</option>
          </select>

          <button
            type="button"
            disabled={fxLoading}
            onClick={() => onRefreshFx(base, target, profile.targetRate)}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className={`h-4 w-4 ${fxLoading ? "animate-spin" : ""}`} aria-hidden="true" />
            Atualizar
          </button>
        </div>
      </div>

      {/* Explicit Stale / Unavailable Warning if needed */}
      {fx?.errorMessage && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          {fx.errorMessage}
        </div>
      )}

      {/* Main Chart + Live Quote */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5">
          <div className="space-y-1">
            <p className="text-xs font-medium text-slate-500">
              Cotação de referência ({fx?.base || base}/{fx?.target || target})
            </p>
            <div className="flex flex-wrap items-baseline gap-3">
              <span className="font-mono text-3xl font-semibold text-slate-900 tabular-nums">
                {fx?.latestRate !== null && fx?.latestRate !== undefined
                  ? fx.latestRate.toFixed(4)
                  : "--"}
              </span>
              {fx?.absoluteChange !== null &&
                fx?.absoluteChange !== undefined &&
                fx?.percentChange !== null &&
                fx?.percentChange !== undefined && (
                  <span
                    className={`inline-flex items-center gap-1 text-sm font-medium tabular-nums ${
                      fx.percentChange < 0 ? "text-[#15803D]" : "text-[#B91C1C]"
                    }`}
                  >
                    {fx.percentChange < 0 ? (
                      <TrendingDown className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <TrendingUp className="h-4 w-4" aria-hidden="true" />
                    )}
                    {fx.absoluteChange > 0 ? "+" : ""}
                    {fx.absoluteChange.toFixed(4)} ({fx.percentChange > 0 ? "+" : ""}
                    {fx.percentChange.toFixed(2)}% vs. observação anterior)
                  </span>
                )}
            </div>
            <p className="text-xs text-slate-500">
              Fonte: {fx?.source || "Frankfurter / BCE"} · Data da observação:{" "}
              <span className="font-mono">{fx?.observationDate || "--"}</span> · Consulta em{" "}
              <span className="font-mono">
                {fx?.fetchedAt ? new Date(fx.fetchedAt).toLocaleString("pt-BR") : "--"}
              </span>
              {fx?.stale ? " · Registro em cache" : ""}
            </p>
          </div>

          {fx?.bcbPtax?.available && (
            <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-xs">
              <p className="font-semibold text-slate-800">{fx.bcbPtax.source}</p>
              <p className="mt-1 font-mono text-slate-700 tabular-nums">
                Compra: {fx.bcbPtax.buyRate?.toFixed(4)} · Venda: {fx.bcbPtax.sellRate?.toFixed(4)}
              </p>
              <p className="mt-0.5 text-slate-500 font-mono">{fx.bcbPtax.timestamp}</p>
            </div>
          )}
        </div>

        <FxChart
          points={fx?.history90d || []}
          base={fx?.base || base}
          target={fx?.target || target}
          targetRate={profile.targetRate}
        />

        {/* Period Averages Table */}
        <div className="grid grid-cols-1 gap-4 border-t border-slate-200 pt-5 sm:grid-cols-3">
          <div>
            <p className="text-xs text-slate-500">Média 7 dias</p>
            <p className="mt-1 font-mono text-lg font-semibold text-slate-900 tabular-nums">
              {fx?.stats.avg7d ? fx.stats.avg7d.toFixed(4) : "--"}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Média 30 dias (Melhor: {fx?.stats.best30dDate || "--"})</p>
            <p className="mt-1 font-mono text-lg font-semibold text-slate-900 tabular-nums">
              {fx?.stats.avg30d ? fx.stats.avg30d.toFixed(4) : "--"}
            </p>
            <p className="text-xs text-slate-500 font-mono tabular-nums">
              Mín: {fx?.stats.min30d?.toFixed(4) || "--"} · Máx: {fx?.stats.max30d?.toFixed(4) || "--"}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Média 90 dias</p>
            <p className="mt-1 font-mono text-lg font-semibold text-slate-900 tabular-nums">
              {fx?.stats.avg90d ? fx.stats.avg90d.toFixed(4) : "--"}
            </p>
            <p className="text-xs text-slate-500 font-mono tabular-nums">
              Mín: {fx?.stats.min90d?.toFixed(4) || "--"} · Máx: {fx?.stats.max90d?.toFixed(4) || "--"}
            </p>
          </div>
        </div>

        <p className="rounded-lg bg-slate-50 px-4 py-3 text-xs text-slate-600">
          <strong>Transparência cambial:</strong> {fx?.disclaimer}
        </p>
      </section>

      {/* Skill 03: Opportunity Radar */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">
              Radar de Oportunidades Cambiais
            </h3>
            <p className="mt-1 text-sm text-slate-600">
              Classificação objetiva comparando a cotação atual com médias de 7, 30 e 90 dias e sua
              meta pessoal.
            </p>
          </div>

          <form onSubmit={handleApplyTarget} className="flex items-center gap-2">
            <label className="text-xs font-medium text-slate-600" htmlFor="target-rate-input">
              Meta ({base}/{target}):
            </label>
            <input
              id="target-rate-input"
              type="number"
              step="0.01"
              min="0.1"
              placeholder="Ex: 6.10"
              value={targetRateInput}
              onChange={(e) => setTargetRateInput(e.target.value)}
              className="w-28 rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
            <button
              type="submit"
              className="rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Aplicar meta
            </button>
          </form>
        </div>

        <div className={`rounded-lg border p-4 ${radarUi.bg}`}>
          <div className="flex items-center gap-2">
            <RadarIcon className={`h-5 w-5 ${radarUi.text}`} aria-hidden="true" />
            <span className={`text-base font-semibold ${radarUi.text}`}>
              {radar?.classification || "Dados indisponíveis"}
            </span>
          </div>
          <p className="mt-1.5 text-sm text-slate-700">{radar?.summary}</p>
          {radar?.reasons && radar.reasons.length > 0 && (
            <ul className="mt-3 list-disc space-y-1 pl-5 text-xs text-slate-700">
              {radar.reasons.map((r, i) => (
                <li key={i}>{r}</li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {/* Skill 02: Economic Intelligence */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
        <div className="border-b border-slate-200 pb-4">
          <h3 className="text-lg font-semibold text-slate-900">
            Inteligência Econômica
          </h3>
          <p className="mt-1 text-sm text-slate-600">
            Fatores macroeconômicos de Brasil, Zona do Euro e EUA com separação clara entre fatos
            verificados, expectativas e hipóteses.
          </p>
        </div>

        {economics?.indicators && economics.indicators.length > 0 && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {economics.indicators.map((ind) => (
              <div key={ind.id} className="rounded-lg border border-slate-200 bg-slate-50/70 p-4">
                <p className="text-xs font-medium text-slate-600">{ind.label}</p>
                <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
                  {ind.value}
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  {ind.source} · Ref.: {ind.referenceDate}
                </p>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-900">Fatos verificados</h4>
            <ul className="space-y-2 text-xs leading-relaxed text-slate-600">
              {(economics?.facts || []).map((f, i) => (
                <li key={i} className="border-b border-slate-100 pb-2 last:border-b-0">
                  {f}
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-900">Expectativas de mercado</h4>
            <ul className="space-y-2 text-xs leading-relaxed text-slate-600">
              {(economics?.expectations || []).map((ex, i) => (
                <li key={i} className="border-b border-slate-100 pb-2 last:border-b-0">
                  {ex}
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-900">Hipóteses de cenário (não são certezas)</h4>
            <ul className="space-y-2 text-xs leading-relaxed text-slate-600">
              {(economics?.hypotheses || []).map((h, i) => (
                <li key={i} className="border-b border-slate-100 pb-2 last:border-b-0">
                  {h}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <p className="text-xs text-slate-500">{economics?.methodologyNote}</p>
      </section>
    </div>
  );
}
