import { useMemo, useState } from "react";
import { AlertTriangle, Bell, CheckCircle2, Plus, ShieldCheck, Trash2 } from "lucide-react";
import type { FxAlertRule, FxOverview, TriggeredAlert, UserProfile } from "../types/madrid";
import { computeTripTimeline } from "../utils/calculations";

interface PlanningAlertsSectionProps {
  profile: UserProfile;
  onUpdateProfile: (next: UserProfile) => void;
  fx: FxOverview | null;
  fxAlerts: FxAlertRule[];
  onSaveFxAlerts: (next: FxAlertRule[]) => void;
  triggeredAlerts: TriggeredAlert[];
}

export function PlanningAlertsSection({
  profile,
  onUpdateProfile,
  fx,
  fxAlerts,
  onSaveFxAlerts,
  triggeredAlerts,
}: PlanningAlertsSectionProps) {
  const rate = fx?.latestRate || 6.15;

  // Strategy inputs synced with profile
  const [totalBudgetBrl, setTotalBudgetBrl] = useState(profile.totalBudgetBrl);
  const [alreadySavedBrl, setAlreadySavedBrl] = useState(profile.alreadySavedBrl);
  const [alreadyAccumulatedEur, setAlreadyAccumulatedEur] = useState(profile.alreadyAccumulatedEur);
  const [emergencyReserveBrl, setEmergencyReserveBrl] = useState(profile.emergencyReserveBrl);
  const [monthlyAvailableBrl, setMonthlyAvailableBrl] = useState(profile.monthlyAvailableBrl);
  const [expectedDestinationExpensesEur, setExpectedDestinationExpensesEur] = useState(
    profile.expectedDestinationExpensesEur
  );
  const [tripDate, setTripDate] = useState(profile.tripDate);
  const [returnDate, setReturnDate] = useState(profile.returnDate || "");
  const [profileSavedMsg, setProfileSavedMsg] = useState(false);

  // Alert creation form
  const [alertType, setAlertType] = useState<FxAlertRule["type"]>("target_below");
  const [threshold, setThreshold] = useState<number>(6.0);
  const [frequency, setFrequency] = useState<FxAlertRule["frequency"]>("diaria");
  const [browserNotif, setBrowserNotif] = useState<boolean>(false);
  const [notifPermissionMsg, setNotifPermissionMsg] = useState<string | null>(null);

  const timeline = useMemo(
    () => computeTripTimeline(tripDate, returnDate),
    [tripDate, returnDate]
  );

  const strategy = useMemo(() => {
    const now = new Date();
    const target = tripDate ? new Date(tripDate) : new Date(now.getTime() + 180 * 86400_000);
    const diffDays = Math.max(15, Math.ceil((target.getTime() - now.getTime()) / 86400_000));
    const monthsUntilTrip = Math.max(1, Number((diffDays / 30).toFixed(1)));

    const totalEurFromBrl = totalBudgetBrl > 0 ? totalBudgetBrl / rate : 0;
    const totalEurNeeded = Math.max(totalEurFromBrl, expectedDestinationExpensesEur || 0);
    const currentEurEquivalent = alreadyAccumulatedEur + alreadySavedBrl / rate;
    const remainingEur = Math.max(0, totalEurNeeded - currentEurEquivalent);
    const remainingBrl = remainingEur * rate;
    const requiredMonthlyBrl = remainingBrl / monthsUntilTrip;

    const tranchesCount = Math.max(2, Math.min(12, Math.round(monthsUntilTrip * 2)));
    const trancheEur = remainingEur > 0 ? remainingEur / tranchesCount : 0;

    const exceedsMonthly = monthlyAvailableBrl > 0 && requiredMonthlyBrl > monthlyAvailableBrl;
    const missingEmergency = emergencyReserveBrl <= 0;
    const dailyBudgetEur =
      timeline.hasReturnDate && timeline.isValidRange && timeline.durationDays
        ? totalEurNeeded / timeline.durationDays
        : null;

    return {
      monthsUntilTrip,
      totalEurNeeded,
      remainingEur,
      remainingBrl,
      requiredMonthlyBrl,
      tranchesCount,
      trancheEur,
      exceedsMonthly,
      missingEmergency,
      dailyBudgetEur,
    };
  }, [
    totalBudgetBrl,
    alreadySavedBrl,
    alreadyAccumulatedEur,
    emergencyReserveBrl,
    monthlyAvailableBrl,
    expectedDestinationExpensesEur,
    tripDate,
    rate,
    timeline,
  ]);

  const handleSaveStrategyProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...profile,
      totalBudgetBrl,
      alreadySavedBrl,
      alreadyAccumulatedEur,
      emergencyReserveBrl,
      monthlyAvailableBrl,
      expectedDestinationExpensesEur,
      tripDate,
      returnDate,
    });
    setProfileSavedMsg(true);
    setTimeout(() => setProfileSavedMsg(false), 4000);
  };

  const handleToggleBrowserNotif = async (checked: boolean) => {
    if (!checked) {
      setBrowserNotif(false);
      setNotifPermissionMsg(null);
      return;
    }
    if (typeof window === "undefined" || !("Notification" in window)) {
      setNotifPermissionMsg("Este navegador não suporta notificações do sistema.");
      setBrowserNotif(false);
      return;
    }
    if (Notification.permission === "granted") {
      setBrowserNotif(true);
      setNotifPermissionMsg("Permissão concedida (dispara somente enquanto o aplicativo estiver aberto).");
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm === "granted") {
      setBrowserNotif(true);
      setNotifPermissionMsg("Permissão concedida (dispara somente enquanto o aplicativo estiver aberto).");
    } else {
      setBrowserNotif(false);
      setNotifPermissionMsg("Permissão não concedida; o alerta continuará visível dentro do aplicativo.");
    }
  };

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    const rule: FxAlertRule = {
      id: crypto.randomUUID(),
      pair: `${fx?.base || profile.trackedPairBase}/${fx?.target || profile.trackedPairTarget}`,
      type: alertType,
      threshold,
      frequency,
      browserNotification: browserNotif,
      active: true,
      createdAt: new Date().toISOString(),
    };
    onSaveFxAlerts([rule, ...fxAlerts]);
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl font-semibold text-slate-900">
          Estratégia de Compras & Alertas
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Organize compras graduais de moeda protegendo sua liquidez e configure alertas cambiais.
        </p>
      </div>

      {/* Skill 05: Purchase Strategy */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <form
          onSubmit={handleSaveStrategyProfile}
          className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-6"
        >
          <div className="border-b border-slate-200 pb-3">
            <h3 className="text-base font-semibold text-slate-900">
              Parâmetros Financeiros da Viagem
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Seus saldos permanecem exclusivamente no seu navegador.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Orçamento total (R$)</span>
              <input
                type="number"
                min="0"
                step="100"
                value={totalBudgetBrl}
                onChange={(e) => setTotalBudgetBrl(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Despesas previstas no destino (€)</span>
              <input
                type="number"
                min="0"
                step="50"
                value={expectedDestinationExpensesEur}
                onChange={(e) => setExpectedDestinationExpensesEur(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Já economizado em reais (R$)</span>
              <input
                type="number"
                min="0"
                step="50"
                value={alreadySavedBrl}
                onChange={(e) => setAlreadySavedBrl(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Euros já acumulados (€)</span>
              <input
                type="number"
                min="0"
                step="10"
                value={alreadyAccumulatedEur}
                onChange={(e) => setAlreadyAccumulatedEur(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Reserva de emergência protegida (R$)</span>
              <input
                type="number"
                min="0"
                step="100"
                value={emergencyReserveBrl}
                onChange={(e) => setEmergencyReserveBrl(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Aporte mensal confortável (R$)</span>
              <input
                type="number"
                min="0"
                step="50"
                value={monthlyAvailableBrl}
                onChange={(e) => setMonthlyAvailableBrl(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Data prevista da viagem (ida)</span>
              <input
                type="date"
                value={tripDate}
                onChange={(e) => setTripDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Data de volta da viagem (opcional)</span>
              <input
                type="date"
                min={tripDate || undefined}
                value={returnDate}
                onChange={(e) => setReturnDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>
          </div>

          <div className="flex items-center justify-between pt-2">
            {profileSavedMsg ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#15803D]">
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                Planejamento atualizado
              </span>
            ) : (
              <span className="text-xs text-slate-500">Cálculo instantâneo com referência {rate.toFixed(4)}</span>
            )}
            <button
              type="submit"
              className="rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-medium text-white hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
            >
              Salvar planejamento
            </button>
          </div>
        </form>

        {/* Strategy Output */}
        <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-6">
          <div className="border-b border-slate-200 pb-3">
            <h3 className="text-base font-semibold text-slate-900">
              Plano Recomendado de Compras Graduais
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Prazo estimado: <strong className="font-mono">{strategy.monthsUntilTrip} meses</strong> até a viagem
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-lg bg-slate-50 p-3.5">
              <p className="text-xs text-slate-500">Falta acumular (estimado)</p>
              <p className="mt-1 font-mono text-xl font-semibold text-slate-900 tabular-nums">
                € {strategy.remainingEur.toFixed(2)}
              </p>
              <p className="mt-0.5 font-mono text-xs text-slate-500 tabular-nums">
                ≈ R$ {strategy.remainingBrl.toFixed(2)}
              </p>
            </div>
            <div className="rounded-lg bg-slate-50 p-3.5">
              <p className="text-xs text-slate-500">Ritmo mensal necessário</p>
              <p className="mt-1 font-mono text-xl font-semibold text-[#1D4ED8] tabular-nums">
                R$ {strategy.requiredMonthlyBrl.toFixed(2)}
              </p>
              <p className="mt-0.5 font-mono text-xs text-slate-500 tabular-nums">
                {strategy.tranchesCount} aportes de ~€ {strategy.trancheEur.toFixed(0)}
              </p>
            </div>
          </div>

          {/* Trip Timeline Summary (when departure/return dates are provided) */}
          {timeline.hasDepartureDate && (
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3.5 text-xs space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-semibold text-slate-900">Cronograma da Viagem</span>
                {timeline.hasReturnDate && !timeline.isValidRange && (
                  <span className="font-medium text-[#B91C1C]">
                    A data de volta está anterior à data de ida.
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div>
                  <p className="text-slate-500">Dias até a ida</p>
                  <p className="font-mono font-semibold text-slate-900 tabular-nums">
                    {timeline.daysUntilDeparture !== null
                      ? timeline.daysUntilDeparture >= 0
                        ? `${timeline.daysUntilDeparture} dia(s)`
                        : "Já iniciada"
                      : "--"}
                  </p>
                </div>
                {timeline.hasReturnDate && timeline.isValidRange && (
                  <>
                    <div>
                      <p className="text-slate-500">Duração total</p>
                      <p className="font-mono font-semibold text-slate-900 tabular-nums">
                        {timeline.durationDays} dia(s) ({timeline.durationMonths} mês/es)
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Dias até o retorno</p>
                      <p className="font-mono font-semibold text-slate-900 tabular-nums">
                        {timeline.daysUntilReturn !== null
                          ? timeline.daysUntilReturn >= 0
                            ? `${timeline.daysUntilReturn} dia(s)`
                            : "Retorno concluído"
                          : "--"}
                      </p>
                    </div>
                  </>
                )}
              </div>
              {timeline.tripStatus === "in_progress" && timeline.temporalProgressPercent !== null && (
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between text-[11px] text-slate-600">
                    <span>Progresso temporal da viagem</span>
                    <span className="font-mono font-semibold tabular-nums">
                      {timeline.temporalProgressPercent.toFixed(1)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
                    <div
                      className="h-full bg-[#1D4ED8]"
                      style={{ width: `${timeline.temporalProgressPercent}%` }}
                    />
                  </div>
                </div>
              )}
              {strategy.dailyBudgetEur !== null && (
                <p className="text-[11px] text-slate-600">
                  Média planejada no destino:{" "}
                  <strong className="font-mono text-slate-900">
                    € {strategy.dailyBudgetEur.toFixed(2)}/dia
                  </strong>{" "}
                  ao longo dos {timeline.durationDays} dias.
                </p>
              )}
            </div>
          )}

          {(strategy.exceedsMonthly || strategy.missingEmergency) && (
            <div className="flex items-start gap-2.5 rounded-lg border border-amber-200 bg-amber-50 p-3.5 text-xs text-amber-900">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              <div className="space-y-1">
                {strategy.exceedsMonthly && (
                  <p>
                    O ritmo mensal necessário (R$ {strategy.requiredMonthlyBrl.toFixed(2)}) ultrapassa
                    sua folga mensal (R$ {monthlyAvailableBrl.toFixed(2)}). Não comprometa despesas
                    essenciais nem sua reserva de emergência.
                  </p>
                )}
                {strategy.missingEmergency && (
                  <p>
                    Defina uma reserva de emergência acima de R$ 0 para manter sua liquidez protegida
                    antes de converter moeda estrangeira.
                  </p>
                )}
              </div>
            </div>
          )}

          <div className="space-y-2.5 text-xs text-slate-700">
            <div className="flex items-start gap-2">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#15803D]" aria-hidden="true" />
              <p>
                <strong>Liquidez preservada:</strong> Sua reserva de emergência de{" "}
                <span className="font-mono">R$ {emergencyReserveBrl.toFixed(2)}</span> permanece intacta e
                fora do orçamento da viagem.
              </p>
            </div>
            <p className="leading-relaxed text-slate-600">
              Sugestão de execução: realize <strong>{strategy.tranchesCount} compras quinzenais</strong>{" "}
              de aproximadamente <strong className="font-mono">€ {strategy.trancheEur.toFixed(2)}</strong>{" "}
              para formar um preço médio equilibrado, mantendo ~30% da disponibilidade para eventuais
              oportunidades no Radar Cambial.
            </p>
          </div>
        </div>
      </section>

      {/* Skill 06: FX Alerts */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-6">
        <div className="border-b border-slate-200 pb-4">
          <h3 className="text-lg font-semibold text-slate-900">Alertas Cambiais</h3>
          <p className="mt-1 text-sm text-slate-600">
            Configure metas de cotação e variações percentuais. Os alertas são avaliados dentro do
            aplicativo sempre que uma nova cotação é consultada.
          </p>
        </div>

        <form onSubmit={handleCreateAlert} className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5 items-end">
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Condição do alerta</span>
            <select
              value={alertType}
              onChange={(e) => {
                const next = e.target.value as FxAlertRule["type"];
                setAlertType(next);
                setThreshold(next === "target_below" ? 6.0 : 1.5);
              }}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            >
              <option value="target_below">Cotação atingir ou cair abaixo de</option>
              <option value="drop_percent">Queda diária igual ou maior que (%)</option>
              <option value="rise_percent">Alta diária igual ou maior que (%)</option>
            </select>
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>{alertType === "target_below" ? "Valor alvo" : "Variação (%)"}</span>
            <input
              type="number"
              step="0.01"
              min="0.1"
              value={threshold}
              onChange={(e) => setThreshold(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            />
          </label>

          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Frequência desejada</span>
            <select
              value={frequency}
              onChange={(e) => setFrequency(e.target.value as FxAlertRule["frequency"])}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
            >
              <option value="diaria">Diária</option>
              <option value="semanal">Semanal</option>
            </select>
          </label>

          <label className="flex items-center gap-2 py-2 text-xs text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={browserNotif}
              onChange={(e) => void handleToggleBrowserNotif(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
            />
            <span>Notificação no navegador (com aba aberta)</span>
          </label>

          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            Adicionar alerta
          </button>
        </form>

        {notifPermissionMsg && (
          <p className="text-xs text-slate-600">{notifPermissionMsg}</p>
        )}

        <p className="text-xs text-slate-500">
          <strong>Transparência técnica:</strong> Este aplicativo não utiliza servidor de push em
          segundo plano. Alertas visuais funcionam no painel e notificações do navegador disparam
          apenas enquanto o aplicativo estiver aberto.
        </p>

        {/* Active Triggered List */}
        {triggeredAlerts.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-700">Alertas disparados na cotação atual</h4>
            <div className="space-y-2">
              {triggeredAlerts.map((t) => (
                <div
                  key={t.ruleId}
                  className="flex items-center justify-between gap-3 rounded-lg border border-emerald-200 bg-emerald-50/70 px-4 py-3 text-xs text-emerald-950"
                >
                  <div>
                    <p className="font-semibold">{t.title}</p>
                    <p className="mt-0.5 text-emerald-900">{t.description}</p>
                  </div>
                  <span className="font-mono text-[11px] text-emerald-800 shrink-0">{t.triggeredAt}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Saved Rules Table */}
        {fxAlerts.length === 0 ? (
          <div className="rounded-lg border border-dashed border-slate-300 p-6 text-center text-xs text-slate-500">
            Nenhum alerta cambial configurado ainda. Adicione uma meta acima para acompanhar quedas
            ou altas relevantes.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 pr-4 font-medium">Par</th>
                  <th className="py-2 pr-4 font-medium">Regra</th>
                  <th className="py-2 pr-4 font-medium text-right">Alvo</th>
                  <th className="py-2 pr-4 font-medium">Frequência</th>
                  <th className="py-2 pr-4 font-medium">Status</th>
                  <th className="py-2 text-right font-medium">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {fxAlerts.map((rule) => (
                  <tr key={rule.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 pr-4 font-mono font-medium text-slate-900">{rule.pair}</td>
                    <td className="py-2.5 pr-4 text-slate-700">
                      {rule.type === "target_below"
                        ? "Cotação abaixo ou igual"
                        : rule.type === "drop_percent"
                        ? "Queda diária %"
                        : "Alta diária %"}
                    </td>
                    <td className="py-2.5 pr-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      {rule.type === "target_below"
                        ? rule.threshold.toFixed(4)
                        : `${rule.threshold.toFixed(2)}%`}
                    </td>
                    <td className="py-2.5 pr-4 text-slate-600">{rule.frequency}</td>
                    <td className="py-2.5 pr-4">
                      <button
                        type="button"
                        onClick={() =>
                          onSaveFxAlerts(
                            fxAlerts.map((a) => (a.id === rule.id ? { ...a, active: !a.active } : a))
                          )
                        }
                        className={`inline-flex items-center gap-1 font-medium cursor-pointer ${
                          rule.active ? "text-[#15803D]" : "text-slate-500"
                        }`}
                      >
                        <Bell className="h-3.5 w-3.5" aria-hidden="true" />
                        {rule.active ? "Ativo" : "Pausado"}
                      </button>
                    </td>
                    <td className="py-2.5 text-right">
                      <button
                        type="button"
                        aria-label="Excluir alerta"
                        onClick={() => onSaveFxAlerts(fxAlerts.filter((a) => a.id !== rule.id))}
                        className="inline-flex items-center text-slate-400 hover:text-[#B91C1C] cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
