import { useState } from "react";
import { AlertTriangle, CheckCircle2, Shield, Trash2 } from "lucide-react";
import type { UserProfile } from "../types/madrid";

interface SettingsPrivacySectionProps {
  profile: UserProfile;
  onUpdateProfile: (next: UserProfile) => void;
  aiConsent: boolean;
  onUpdateAiConsent: (consented: boolean) => void;
  onClearAllData: () => void;
}

export function SettingsPrivacySection({
  profile,
  onUpdateProfile,
  aiConsent,
  onUpdateAiConsent,
  onClearAllData,
}: SettingsPrivacySectionProps) {
  const [form, setForm] = useState<UserProfile>(profile);
  const [savedMsg, setSavedMsg] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [clearedMsg, setClearedMsg] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({ ...form, onboardingCompleted: true });
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 4000);
  };

  const handleConfirmClear = () => {
    onClearAllData();
    setConfirmClear(false);
    setClearedMsg(true);
    setTimeout(() => setClearedMsg(false), 5000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl font-semibold text-slate-900">
          Configurações Pessoais & Privacidade
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Gerencie suas metas individuais, consentimento de IA e dados armazenados localmente no
          navegador.
        </p>
      </div>

      {/* Personalization Form */}
      <form onSubmit={handleSave} className="space-y-5 rounded-xl border border-slate-200 bg-white p-6">
        <div className="border-b border-slate-200 pb-3">
          <h3 className="text-base font-semibold text-slate-900">Perfil e Metas da Viagem</h3>
          <p className="mt-0.5 text-xs text-slate-500">
            Dados isolados no LocalStorage deste navegador. Não são compartilhados entre visitantes.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Nome ou apelido</span>
            <input
              type="text"
              value={form.nickname}
              onChange={(e) => setForm({ ...form, nickname: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>País de origem</span>
            <input
              type="text"
              value={form.originCountry}
              onChange={(e) => setForm({ ...form, originCountry: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Moeda de origem</span>
            <select
              value={form.originCurrency}
              onChange={(e) => setForm({ ...form, originCurrency: e.target.value })}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900"
            >
              <option value="BRL">BRL (Real Brasileiro)</option>
              <option value="USD">USD (Dólar Americano)</option>
              <option value="GBP">GBP (Libra Esterlina)</option>
            </select>
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Destino</span>
            <input
              type="text"
              value={form.destinationCountry}
              onChange={(e) => setForm({ ...form, destinationCountry: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Data prevista da viagem (ida)</span>
            <input
              type="date"
              value={form.tripDate}
              onChange={(e) => setForm({ ...form, tripDate: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Data de volta da viagem (opcional)</span>
            <input
              type="date"
              min={form.tripDate || undefined}
              value={form.returnDate || ""}
              onChange={(e) => setForm({ ...form, returnDate: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700">
            <span>Meta de cotação ({form.trackedPairBase}/{form.trackedPairTarget})</span>
            <input
              type="number"
              step="0.01"
              value={form.targetRate ?? ""}
              onChange={(e) =>
                setForm({
                  ...form,
                  targetRate: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900"
            />
          </label>
          <label className="space-y-1 text-xs font-medium text-slate-700 sm:col-span-2 lg:col-span-3">
            <span>Objetivo financeiro</span>
            <input
              type="text"
              value={form.financialGoal}
              onChange={(e) => setForm({ ...form, financialGoal: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
            />
          </label>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4">
          {savedMsg ? (
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#15803D]">
              <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
              Preferências salvas localmente
            </span>
          ) : (
            <span className="text-xs text-slate-500">
              Aviso: a limpeza dos dados do navegador pode apagar seu histórico local.
            </span>
          )}
          <button
            type="submit"
            className="rounded-lg bg-[#1D4ED8] px-5 py-2 text-sm font-medium text-white hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
          >
            Salvar alterações
          </button>
        </div>
      </form>

      {/* Privacy Policy & Consent */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
          <Shield className="h-4 w-4 text-[#1D4ED8]" aria-hidden="true" />
          <h3 className="text-base font-semibold text-slate-900">
            Política de Privacidade & Transparência
          </h3>
        </div>

        <div className="space-y-3 text-xs leading-relaxed text-slate-600">
          <p>
            <strong>1. Isolamento de Dados (LocalStorage):</strong> Suas metas, orçamentos, compras
            registradas, alertas e conversas são armazenados exclusivamente no armazenamento local
            do seu navegador. Nenhum visitante tem acesso aos dados de outro visitante.
          </p>
          <p>
            <strong>2. Uso de Inteligência Artificial:</strong> Quando você utiliza o Assistente de
            IA, sua pergunta (e opcionalmente o resumo do seu planejamento, somente se você
            autorizar abaixo) é enviada de forma segura ao servidor do Madrid Finance para consulta
            ao modelo Gemini. Chaves de API ficam exclusivamente no servidor.
          </p>
          <p>
            <strong>3. Sem Transações Financeiras:</strong> O Madrid Finance não executa compras de
            moedas, transferências, emissão de passagens ou acesso a contas externas como Wise ou
            bancos.
          </p>
          <p>
            <strong>4. Isenção de Responsabilidade:</strong> Todas as análises cambiais, econômicas e
            estratégias têm caráter estritamente informativo e educacional e não constituem
            aconselhamento financeiro, jurídico ou recomendação de investimento profissional.
          </p>
        </div>

        <label className="flex items-center gap-2.5 rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-xs text-slate-800 cursor-pointer">
          <input
            type="checkbox"
            checked={aiConsent}
            onChange={(e) => onUpdateAiConsent(e.target.checked)}
            className="h-4 w-4 rounded border-slate-300 text-[#1D4ED8]"
          />
          <span>
            Autorizo enviar apenas o resumo necessário das minhas metas locais ao Assistente de IA
            para personalizar as respostas.
          </span>
        </label>

        {/* Wipe Local Data (Two-Step UI Confirmation, no window.alert/confirm) */}
        <div className="border-t border-slate-200 pt-4">
          {!confirmClear ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-sm font-medium text-slate-900">Apagar dados locais</p>
                <p className="text-xs text-slate-500">
                  Remove perfil, histórico de compras, alertas e conversas salvas neste navegador.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-red-300 bg-white px-4 py-2 text-xs font-medium text-[#B91C1C] hover:bg-red-50 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                Apagar todos os dados locais
              </button>
            </div>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-red-200 bg-red-50 p-4">
              <div className="flex items-center gap-2 text-xs font-medium text-[#B91C1C]">
                <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Confirma a exclusão permanente dos seus dados locais neste navegador?</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmClear}
                  className="rounded-lg bg-[#B91C1C] px-3 py-1.5 text-xs font-medium text-white hover:bg-red-800 cursor-pointer"
                >
                  Confirmar exclusão
                </button>
              </div>
            </div>
          )}

          {clearedMsg && (
            <p className="mt-2 text-xs font-medium text-[#15803D]">
              Todos os dados locais deste navegador foram apagados e restaurados ao padrão.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
