import { useState } from "react";
import {
  ArrowRight,
  Bell,
  Calculator,
  Compass,
  FileSpreadsheet,
  MessageSquare,
  Plane,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import type {
  FxOverview,
  NavSection,
  OpportunityAnalysis,
  PurchaseEntry,
  TriggeredAlert,
  UserProfile,
} from "../types/madrid";
import { buildFinancialReport } from "../utils/calculations";

interface OverviewSectionProps {
  profile: UserProfile;
  onUpdateProfile: (next: UserProfile) => void;
  fx: FxOverview | null;
  fxLoading: boolean;
  radar: OpportunityAnalysis | null;
  purchases: PurchaseEntry[];
  triggeredAlerts: TriggeredAlert[];
  onNavigate: (section: NavSection) => void;
}

export function OverviewSection({
  profile,
  onUpdateProfile,
  fx,
  fxLoading,
  radar,
  purchases,
  triggeredAlerts,
  onNavigate,
}: OverviewSectionProps) {
  const [showOnboardingForm, setShowOnboardingForm] = useState(!profile.onboardingCompleted);
  const [draft, setDraft] = useState<UserProfile>(profile);
  const report = buildFinancialReport(profile, purchases, fx);

  const handleSaveOnboarding = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({ ...draft, onboardingCompleted: true });
    setShowOnboardingForm(false);
  };

  const handleSkipOnboarding = () => {
    onUpdateProfile({ ...profile, onboardingCompleted: true });
    setShowOnboardingForm(false);
  };

  const isRateDrop = fx?.percentChange !== null && fx?.percentChange !== undefined && fx.percentChange < 0;

  return (
    <div className="space-y-8">
      {/* Editorial Hero Split */}
      <section className="grid grid-cols-1 items-stretch gap-6 rounded-xl border border-slate-200 bg-white p-6 lg:grid-cols-12 lg:p-8">
        <div className="flex flex-col justify-between space-y-6 lg:col-span-7">
          <div className="space-y-3">
            <p className="text-xs font-medium text-slate-500">
              Planejamento Cambial e Financeiro Internacional · {profile.destinationCountry || "Espanha (Madrid)"}
            </p>
            <h1 className="font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl [text-wrap:balance]">
              Madrid Finance
            </h1>
            <p className="text-lg font-medium text-slate-800 [text-wrap:balance]">
              Seu assistente inteligente para planejar, economizar e viajar melhor.
            </p>
            <p className="max-w-2xl text-sm leading-relaxed text-slate-600 sm:text-base">
              Organize seu dinheiro, acompanhe o câmbio, encontre oportunidades e planeje sua
              próxima viagem com inteligência.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate("assistant")}
              className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
            >
              <MessageSquare className="h-4 w-4" aria-hidden="true" />
              Conversar com o Assistente
            </button>
            <button
              type="button"
              onClick={() => onNavigate("wise")}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-800 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Calculator className="h-4 w-4" aria-hidden="true" />
              Simular Compra na Wise
            </button>
          </div>
        </div>

        {/* Bespoke Madrid Architectural SVG Panel (Zero-Broken-Image resilient visual) */}
        <div className="relative flex min-h-56 flex-col justify-between overflow-hidden rounded-lg border border-slate-200 bg-[#F3F5F8] p-6 lg:col-span-5">
          <div className="relative z-10 flex items-center justify-between text-xs text-slate-600">
            <span className="font-medium text-slate-800">Rota de Planejamento</span>
            <span className="font-mono tabular-nums">
              {profile.originCurrency} → {profile.trackedPairBase}
            </span>
          </div>

          {/* Architectural Puerta de Alcalá / Cibeles geometric line art */}
          <svg
            viewBox="0 0 360 170"
            className="my-2 h-36 w-full text-slate-800"
            aria-hidden="true"
          >
            <line x1="16" y1="152" x2="344" y2="152" stroke="#CBD5E1" strokeWidth="1.5" />
            {/* Three classical Madrid arches */}
            <path
              d="M68 152 V96 A26 26 0 0 1 120 96 V152"
              fill="none"
              stroke="#94A3B8"
              strokeWidth="1.4"
            />
            <path
              d="M144 152 V78 A36 36 0 0 1 216 78 V152"
              fill="none"
              stroke="#0F172A"
              strokeWidth="1.8"
            />
            <path
              d="M240 152 V96 A26 26 0 0 1 292 96 V152"
              fill="none"
              stroke="#94A3B8"
              strokeWidth="1.4"
            />
            {/* Cornice & pediment */}
            <rect x="52" y="42" width="256" height="10" fill="none" stroke="#64748B" strokeWidth="1.2" />
            <path d="M136 42 L180 18 L224 42" fill="none" stroke="#1D4ED8" strokeWidth="1.8" />
            {/* Subtle FX trend overlay */}
            <path
              d="M24 128 Q92 108 150 116 T252 84 T336 66"
              fill="none"
              stroke="#1D4ED8"
              strokeWidth="2"
              strokeDasharray="4 4"
            />
            <circle cx="336" cy="66" r="4" fill="#1D4ED8" />
          </svg>

          <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 pt-3 text-xs text-slate-600">
            <span>
              {profile.nickname ? `Viajante: ${profile.nickname}` : "Uso público sem cadastro"}
            </span>
            <span className="font-mono tabular-nums">
              Ida: {profile.tripDate || "A definir"}
              {profile.returnDate ? ` · Volta: ${profile.returnDate}` : ""}
              {report.timeline.hasReturnDate &&
              report.timeline.isValidRange &&
              report.timeline.durationDays !== null
                ? ` (${report.timeline.durationDays}d)`
                : ""}
            </span>
          </div>
        </div>
      </section>

      {/* Triggered Alerts Strip (when active) */}
      {triggeredAlerts.length > 0 && (
        <section className="rounded-xl border border-amber-200 bg-amber-50/70 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm font-semibold text-amber-900">
                <Bell className="h-4 w-4" aria-hidden="true" />
                <span>{triggeredAlerts.length} alerta(s) cambial(is) ativo(s) no momento</span>
              </div>
              <p className="text-xs text-amber-800">
                {triggeredAlerts[0].title}: {triggeredAlerts[0].description}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate("planning")}
              className="rounded-lg border border-amber-300 bg-white px-3 py-1.5 text-xs font-medium text-amber-900 hover:bg-amber-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Gerenciar alertas
            </button>
          </div>
        </section>
      )}

      {/* 4-Column KPI Strip */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">
            Referência {fx?.base || "EUR"}/{fx?.target || "BRL"}
          </p>
          {fxLoading && !fx ? (
            <div className="mt-2 h-8 w-28 animate-pulse rounded bg-slate-100" />
          ) : fx?.available && fx.latestRate !== null ? (
            <>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="font-mono text-2xl font-semibold text-slate-900 tabular-nums">
                  {fx.latestRate.toFixed(4)}
                </span>
                {fx.percentChange !== null && (
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-medium tabular-nums ${
                      isRateDrop ? "text-[#15803D]" : "text-[#B91C1C]"
                    }`}
                  >
                    {isRateDrop ? (
                      <TrendingDown className="h-3.5 w-3.5" aria-hidden="true" />
                    ) : (
                      <TrendingUp className="h-3.5 w-3.5" aria-hidden="true" />
                    )}
                    {fx.percentChange > 0 ? "+" : ""}
                    {fx.percentChange.toFixed(2)}%
                  </span>
                )}
              </div>
              <p className="mt-2 text-xs text-slate-500">
                Frankfurter/BCE · {fx.observationDate}
              </p>
            </>
          ) : (
            <p className="mt-2 text-sm text-slate-600">Cotação indisponível no momento</p>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Radar de Oportunidades</p>
          <p className="mt-1 text-lg font-semibold text-slate-900">
            {radar?.available ? radar.classification : "Aguardando dados"}
          </p>
          <p className="mt-2 text-xs text-slate-500 line-clamp-2">
            {radar?.available
              ? `Meta definida: ${profile.targetRate ? profile.targetRate.toFixed(4) : "Não configurada"}`
              : "Consulte o painel cambial para detalhes"}
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Progresso da Viagem</p>
          <p className="mt-1 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {report.progressPercent.toFixed(1)}%
          </p>
          <p className="mt-2 text-xs text-slate-500 tabular-nums">
            € {report.totalAccumulatedEur.toFixed(0)} acumulados · Meta € {report.estimatedGoalEur.toFixed(0)}
          </p>
          {report.timeline.hasDepartureDate && report.timeline.daysUntilDeparture !== null && (
            <p className="mt-1 text-[11px] text-slate-500 tabular-nums">
              {report.timeline.tripStatus === "in_progress" &&
              report.timeline.temporalProgressPercent !== null
                ? `Em andamento (${report.timeline.temporalProgressPercent.toFixed(0)}% do período · ${report.timeline.daysUntilReturn}d p/ volta)`
                : report.timeline.tripStatus === "completed"
                ? "Período da viagem concluído"
                : report.timeline.daysUntilDeparture >= 0
                ? `${report.timeline.daysUntilDeparture}d até a ida${
                    report.timeline.durationDays ? ` · ${report.timeline.durationDays}d de duração` : ""
                  }`
                : ""}
            </p>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Custo Médio Registrado</p>
          <p className="mt-1 font-mono text-2xl font-semibold text-slate-900 tabular-nums">
            {report.weightedAverageEurCost ? `R$ ${report.weightedAverageEurCost.toFixed(4)}` : "Sem registros"}
          </p>
          <p className="mt-2 text-xs text-slate-500">
            {purchases.length} operação(ões) salva(s) no navegador
          </p>
        </div>
      </section>

      {/* Optional First-Access Personalization Inline Section */}
      {showOnboardingForm && (
        <section className="rounded-xl border border-slate-200 bg-white p-6">
          <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">
                Configuração Inicial Opcional
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Personalize suas metas de viagem. Os dados ficam salvos apenas neste navegador
                (sem necessidade de cadastro ou login).
              </p>
            </div>
            <button
              type="button"
              onClick={handleSkipOnboarding}
              className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Pular por agora
            </button>
          </div>

          <form onSubmit={handleSaveOnboarding} className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Nome ou apelido</span>
              <input
                type="text"
                value={draft.nickname}
                onChange={(e) => setDraft({ ...draft, nickname: e.target.value })}
                placeholder="Ex: Ana"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>País e moeda de origem</span>
              <select
                value={draft.originCurrency}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    originCurrency: e.target.value,
                    trackedPairTarget: e.target.value,
                  })
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              >
                <option value="BRL">Brasil (BRL)</option>
                <option value="USD">Estados Unidos (USD)</option>
                <option value="GBP">Reino Unido (GBP)</option>
              </select>
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>País / Cidade de destino</span>
              <input
                type="text"
                value={draft.destinationCountry}
                onChange={(e) => setDraft({ ...draft, destinationCountry: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Data prevista da viagem (ida)</span>
              <input
                type="date"
                value={draft.tripDate}
                onChange={(e) => setDraft({ ...draft, tripDate: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Data de volta da viagem (opcional)</span>
              <input
                type="date"
                min={draft.tripDate || undefined}
                value={draft.returnDate || ""}
                onChange={(e) => setDraft({ ...draft, returnDate: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Orçamento total estimado (R$)</span>
              <input
                type="number"
                min="0"
                step="100"
                value={draft.totalBudgetBrl}
                onChange={(e) => setDraft({ ...draft, totalBudgetBrl: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Já economizado em reais (R$)</span>
              <input
                type="number"
                min="0"
                step="50"
                value={draft.alreadySavedBrl}
                onChange={(e) => setDraft({ ...draft, alreadySavedBrl: Number(e.target.value) })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Moeda que deseja acompanhar</span>
              <select
                value={draft.trackedPairBase}
                onChange={(e) => setDraft({ ...draft, trackedPairBase: e.target.value })}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              >
                <option value="EUR">Euro (EUR)</option>
                <option value="USD">Dólar (USD)</option>
                <option value="GBP">Libra Esterlina (GBP)</option>
              </select>
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Frequência de acompanhamento</span>
              <select
                value={draft.checkFrequency}
                onChange={(e) =>
                  setDraft({
                    ...draft,
                    checkFrequency: e.target.value as UserProfile["checkFrequency"],
                  })
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              >
                <option value="diaria">Diária</option>
                <option value="semanal">Semanal</option>
                <option value="tempo_real">Sempre que abrir o painel</option>
              </select>
            </label>

            <label className="space-y-1 text-xs font-medium text-slate-700">
              <span>Objetivo financeiro</span>
              <input
                type="text"
                value={draft.financialGoal}
                onChange={(e) => setDraft({ ...draft, financialGoal: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-[#1D4ED8] focus:outline-none"
              />
            </label>

            <div className="flex items-end sm:col-span-2 lg:col-span-3">
              <button
                type="submit"
                className="rounded-lg bg-[#1D4ED8] px-5 py-2.5 text-sm font-medium text-white hover:bg-[#1E40AF] whitespace-nowrap shrink-0 cursor-pointer"
              >
                Salvar preferências locais
              </button>
            </div>
          </form>
        </section>
      )}

      {/* Quick Access Grid to Core Capabilities */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Especialidades do Planejamento</h2>
          <span className="text-xs text-slate-500">8 módulos integrados</span>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[
            {
              id: "fx" as NavSection,
              icon: Compass,
              title: "Câmbio, Radar & Economia",
              desc: "Séries de 7, 30 e 90 dias (Frankfurter/BCE e BCB PTAX), radar de oportunidades e contexto Selic, BCE e Fed.",
            },
            {
              id: "wise" as NavSection,
              icon: Calculator,
              title: "Calculadora Wise",
              desc: "Simule IOF, taxa da plataforma e custo efetivo por euro, ou registre operações reais realizadas.",
            },
            {
              id: "planning" as NavSection,
              icon: Bell,
              title: "Estratégia & Alertas",
              desc: "Plano de compras graduais preservando sua reserva de emergência, além de alertas de queda ou meta.",
            },
            {
              id: "flights" as NavSection,
              icon: Plane,
              title: "Monitoramento de Passagens",
              desc: "Pesquisa com API autorizada (quando configurada), comparativo manual de tarifas e links oficiais.",
            },
            {
              id: "reports" as NavSection,
              icon: FileSpreadsheet,
              title: "Relatório Financeiro & CSV",
              desc: "Acompanhe custo médio, evolução percentual da meta e exporte seu histórico em CSV.",
            },
            {
              id: "assistant" as NavSection,
              icon: MessageSquare,
              title: "Assistente de IA Central",
              desc: "Tire dúvidas em linguagem natural combinando todas as especialidades com fontes e datas.",
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className="group flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 text-left transition-colors hover:border-slate-300 hover:bg-slate-50/70 cursor-pointer"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Icon className="h-5 w-5 text-[#1D4ED8]" aria-hidden="true" />
                    <ArrowRight
                      className="h-4 w-4 text-slate-400 transition-transform group-hover:translate-x-0.5 group-hover:text-slate-700"
                      aria-hidden="true"
                    />
                  </div>
                  <h3 className="text-base font-semibold text-slate-900">{item.title}</h3>
                  <p className="text-xs leading-relaxed text-slate-600">{item.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
